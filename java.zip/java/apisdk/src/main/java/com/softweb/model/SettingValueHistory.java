/**
 * 
 */
package com.softweb.model;

import java.util.Date;

/**
 * @author mayuri.mojidra
 *
 */
public class SettingValueHistory {
	
	private String guid;
	private TemplateSetting templateSetting;
	private Device device;
	private Company company;
	private String attributeValue;
	private Date createdDate;
	private Date sdkDate;
	private Date gatewayDate;
	private Date deviceDate;
	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}
	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}
	/**
	 * @return the templateSetting
	 */
	public TemplateSetting getTemplateSetting() {
		return templateSetting;
	}
	/**
	 * @param templateSetting the templateSetting to set
	 */
	public void setTemplateSetting(TemplateSetting templateSetting) {
		this.templateSetting = templateSetting;
	}
	/**
	 * @return the device
	 */
	public Device getDevice() {
		return device;
	}
	/**
	 * @param device the device to set
	 */
	public void setDevice(Device device) {
		this.device = device;
	}
	/**
	 * @return the company
	 */
	public Company getCompany() {
		return company;
	}
	/**
	 * @param company the company to set
	 */
	public void setCompany(Company company) {
		this.company = company;
	}
	/**
	 * @return the attributeValue
	 */
	public String getAttributeValue() {
		return attributeValue;
	}
	/**
	 * @param attributeValue the attributeValue to set
	 */
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the sdkDate
	 */
	public Date getSdkDate() {
		return sdkDate;
	}
	/**
	 * @param sdkDate the sdkDate to set
	 */
	public void setSdkDate(Date sdkDate) {
		this.sdkDate = sdkDate;
	}
	/**
	 * @return the gatewayDate
	 */
	public Date getGatewayDate() {
		return gatewayDate;
	}
	/**
	 * @param gatewayDate the gatewayDate to set
	 */
	public void setGatewayDate(Date gatewayDate) {
		this.gatewayDate = gatewayDate;
	}
	/**
	 * @return the deviceDate
	 */
	public Date getDeviceDate() {
		return deviceDate;
	}
	/**
	 * @param deviceDate the deviceDate to set
	 */
	public void setDeviceDate(Date deviceDate) {
		this.deviceDate = deviceDate;
	}
	
	

}
