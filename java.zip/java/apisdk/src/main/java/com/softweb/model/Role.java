package com.softweb.model;

import java.sql.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author shreya.hedau
 *
 */
//@JsonIgnoreProperties(ignoreUnknown = true)
public class Role {

	@JsonAlias({ "roleGuid", "guid" })
	private String guid;
	private Company companyGuid;
	private List<Solution> solutionGuid;
	@JsonAlias({ "roleName", "name" })
	private String name;

	@JsonAlias({ "roleDescription", "description" })
	private String description;
	private Boolean isActive;
	private Boolean isDeleted;
	private Date createdDate;
	private String createdBy;
	private Date updatedDate;
	private String updatedBy;

	private Boolean roleStatus;
	private String updatedByName;
	private Object modules;

	public Role() {
		super();
	}

	/**
	 * @return the roleStatus
	 */
	public Boolean getRoleStatus() {
		return roleStatus;
	}

	/**
	 * @param roleStatus the roleStatus to set
	 */
	public void setRoleStatus(Boolean roleStatus) {
		this.roleStatus = roleStatus;
	}

	/**
	 * @return the updatedByName
	 */
	public String getUpdatedByName() {
		return updatedByName;
	}

	/**
	 * @param updatedByName the updatedByName to set
	 */
	public void setUpdatedByName(String updatedByName) {
		this.updatedByName = updatedByName;
	}

	/**
	 * @return the modules
	 */
	public Object getModules() {
		return modules;
	}

	/**
	 * @param modules the modules to set
	 */
	public void setModules(Object modules) {
		this.modules = modules;
	}

	/**
	 * @return the guid
	 */

	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the companyGuid
	 */
	public Company getCompanyGuid() {
		return companyGuid;
	}

	/**
	 * @param companyGuid the companyGuid to set
	 */
	public void setCompanyGuid(Company companyGuid) {
		this.companyGuid = companyGuid;
	}

	/**
	 * @return the solutionGuid
	 */
	@JsonProperty("solutions")
	public List<Solution> getSolutionGuid() {
		return solutionGuid;
	}

	/**
	 * @param solutionGuid the solutionGuid to set
	 */
	public void setSolutionGuid(List<Solution> solutionGuid) {
		this.solutionGuid = solutionGuid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

}
