package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class EntityInfo {

	private String guid;
	private String entityGuid;
	private String propertyGuid;
	private String feature;
	private String count;
	private String countDate;
	private String createdDate;
	private String updatedDate;

	/**
	 * 
	 */
	public EntityInfo() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the entityGuid
	 */
	public String getEntityGuid() {
		return entityGuid;
	}

	/**
	 * @param entityGuid the entityGuid to set
	 */
	public void setEntityGuid(String entityGuid) {
		this.entityGuid = entityGuid;
	}

	/**
	 * @return the propertyGuid
	 */
	public String getPropertyGuid() {
		return propertyGuid;
	}

	/**
	 * @param propertyGuid the propertyGuid to set
	 */
	public void setPropertyGuid(String propertyGuid) {
		this.propertyGuid = propertyGuid;
	}

	/**
	 * @return the feature
	 */
	public String getFeature() {
		return feature;
	}

	/**
	 * @param feature the feature to set
	 */
	public void setFeature(String feature) {
		this.feature = feature;
	}

	/**
	 * @return the count
	 */
	public String getCount() {
		return count;
	}

	/**
	 * @param count the count to set
	 */
	public void setCount(String count) {
		this.count = count;
	}

	/**
	 * @return the countDate
	 */
	public String getCountDate() {
		return countDate;
	}

	/**
	 * @param countDate the countDate to set
	 */
	public void setCountDate(String countDate) {
		this.countDate = countDate;
	}

	/**
	 * @return the createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the updatedDate
	 */
	public String getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

}
