package com.softweb.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author shreya.hedau
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Rule {

	private String guid;
	private String companyGuid;
	private String templateGuid;
	private ArrayList<String> attributeGuid;
	private Integer ruleType;
	private String parentAttributeGuid;
	private String name;
	private String conditionText;
	private Boolean ignorePreference;
	private String entityGuid;
	private Integer applyTo;
	private Boolean isActive;
	private String eventSubscriptionGuid;

//	private EventSubscription eventSubscription;
	private String solutionGuid;
	private String refGuid;

//	private User createdBy;
//	private Date createdDate;
//	private User updatedBy;
//	private Date updatedDate;
//	private Boolean isDeleted;

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the companyGuid
	 */
	public String getCompanyGuid() {
		return companyGuid;
	}

	/**
	 * @param companyGuid the companyGuid to set
	 */
	public void setCompanyGuid(String companyGuid) {
		this.companyGuid = companyGuid;
	}

	/**
	 * @return the templateGuid
	 */
	public String getTemplateGuid() {
		return templateGuid;
	}

	/**
	 * @param templateGuid the templateGuid to set
	 */
	public void setTemplateGuid(String templateGuid) {
		this.templateGuid = templateGuid;
	}

	/**
	 * @return the attributeGuid
	 */
	public ArrayList<String> getAttributeGuid() {
		return attributeGuid;
	}

	/**
	 * @param attributeGuid the attributeGuid to set
	 */
	public void setAttributeGuid(ArrayList<String> attributeGuid) {
		this.attributeGuid = attributeGuid;
	}

	/**
	 * @return the ruleType
	 */
	public Integer getRuleType() {
		return ruleType;
	}

	/**
	 * @param ruleType the ruleType to set
	 */
	public void setRuleType(Integer ruleType) {
		this.ruleType = ruleType;
	}

	/**
	 * @return the parentAttributeGuid
	 */
	public String getParentAttributeGuid() {
		return parentAttributeGuid;
	}

	/**
	 * @param parentAttributeGuid the parentAttributeGuid to set
	 */
	public void setParentAttributeGuid(String parentAttributeGuid) {
		this.parentAttributeGuid = parentAttributeGuid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the conditionText
	 */
	public String getConditionText() {
		return conditionText;
	}

	/**
	 * @param conditionText the conditionText to set
	 */
	public void setConditionText(String conditionText) {
		this.conditionText = conditionText;
	}

	/**
	 * @return the ignorePreference
	 */
	public Boolean getIgnorePreference() {
		return ignorePreference;
	}

	/**
	 * @param ignorePreference the ignorePreference to set
	 */
	public void setIgnorePreference(Boolean ignorePreference) {
		this.ignorePreference = ignorePreference;
	}

	/**
	 * @return the entityGuid
	 */
	public String getEntityGuid() {
		return entityGuid;
	}

	/**
	 * @param entityGuid the entityGuid to set
	 */
	public void setEntityGuid(String entityGuid) {
		this.entityGuid = entityGuid;
	}

	/**
	 * @return the applyTo
	 */
	public Integer getApplyTo() {
		return applyTo;
	}

	/**
	 * @param applyTo the applyTo to set
	 */
	public void setApplyTo(Integer applyTo) {
		this.applyTo = applyTo;
	}

	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the eventSubscriptionGuid
	 */
	public String getEventSubscriptionGuid() {
		return eventSubscriptionGuid;
	}

	/**
	 * @param eventSubscriptionGuid the eventSubscriptionGuid to set
	 */
	public void setEventSubscriptionGuid(String eventSubscriptionGuid) {
		this.eventSubscriptionGuid = eventSubscriptionGuid;
	}

//	/**
//	 * @return the eventSubscription
//	 */
//	public EventSubscription getEventSubscription() {
//		return eventSubscription;
//	}
//
//	/**
//	 * @param eventSubscription the eventSubscription to set
//	 */
//	public void setEventSubscription(EventSubscription eventSubscription) {
//		this.eventSubscription = eventSubscription;
//	}

	/**
	 * @return the solutionGuid
	 */
	public String getSolutionGuid() {
		return solutionGuid;
	}

	/**
	 * @param solutionGuid the solutionGuid to set
	 */
	public void setSolutionGuid(String solutionGuid) {
		this.solutionGuid = solutionGuid;
	}

	/**
	 * @return the refGuid
	 */
	public String getRefGuid() {
		return refGuid;
	}

	/**
	 * @param refGuid the refGuid to set
	 */
	public void setRefGuid(String refGuid) {
		this.refGuid = refGuid;
	}

}
