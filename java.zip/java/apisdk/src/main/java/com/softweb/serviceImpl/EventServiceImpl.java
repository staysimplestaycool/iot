package com.softweb.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.softweb.common.HttpUtil;
import com.softweb.model.ApiResponse;
import com.softweb.model.DeliveryMethod;
import com.softweb.model.IoTConnect;
import com.softweb.service.EventService;

/**
 * @author shreya.hedau
 *
 */
public class EventServiceImpl implements EventService {

	private IoTConnect ioTConnect;

	/**
	 * 
	 */
	public EventServiceImpl() {
		super();
		ioTConnect = IoTConnect.getInstance();
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.EventService#sendEmail(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> sendEmail(Map<String, String> headers, String from, String to, String subject,
			String message) throws IOException {
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("from", from);
		data.put("subject", subject);
		data.put("emailMessage", message);
		data.put("to",to);
		
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPost(
				ioTConnect.EVENT_BASE_URL + "/event/send-email", data, headers,
				ApiResponse.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.EventService#getNotificationDeliveryMethods(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<DeliveryMethod>> getNotificationDeliveryMethods(Map<String, String> headers, String eventGuid) throws IOException {
		
		return (ApiResponse<ArrayList<DeliveryMethod>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.EVENT_BASE_URL + "/event/" + eventGuid + "/delivery-method", null, headers,
				DeliveryMethod.class, true, true);
		
		
	}

}
