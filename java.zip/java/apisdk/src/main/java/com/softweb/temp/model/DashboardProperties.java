package com.softweb.temp.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author shreya.hedau
 *
 */
public class DashboardProperties {

	private Object x;
	private Object y;
	private String w;
	private String h;
	private Object i;
	private Object minW;
	private Object minH;
	private Object maxH;
	private Object maxW;
	private Boolean moved;
	private Boolean widgetStatic;
	private String className;
	
	
	
	/**
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @param i
	 * @param minW
	 * @param minH
	 * @param maxH
	 * @param maxW
	 * @param moved
	 * @param widgetStatic
	 * @param className
	 */
	public DashboardProperties(Object x, Object y, String w, String h, Object i, Object minW, Object minH, Object maxH,
			Object maxW, Boolean moved, String className, Boolean widgetStatic) {
		super();
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.i = i;
		this.minW = minW;
		this.minH = minH;
		this.maxH = maxH;
		this.maxW = maxW;
		this.moved = moved;
		this.widgetStatic = widgetStatic;
		this.className = className;
	}
	/**
	 * 
	 */
	public DashboardProperties() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the x
	 */
	public Object getX() {
		return x;
	}
	/**
	 * @param x the x to set
	 */
	public void setX(Object x) {
		this.x = x;
	}
	/**
	 * @return the y
	 */
	public Object getY() {
		return y;
	}
	/**
	 * @param y the y to set
	 */
	public void setY(Object y) {
		this.y = y;
	}
	/**
	 * @return the w
	 */
	public String getW() {
		return w;
	}
	/**
	 * @param w the w to set
	 */
	public void setW(String w) {
		this.w = w;
	}
	/**
	 * @return the h
	 */
	public String getH() {
		return h;
	}
	/**
	 * @param h the h to set
	 */
	public void setH(String h) {
		this.h = h;
	}
	/**
	 * @return the i
	 */
	public Object getI() {
		return i;
	}
	/**
	 * @param i the i to set
	 */
	public void setI(Object i) {
		this.i = i;
	}
	/**
	 * @return the minW
	 */
	public Object getMinW() {
		return minW;
	}
	/**
	 * @param minW the minW to set
	 */
	public void setMinW(Object minW) {
		this.minW = minW;
	}
	/**
	 * @return the minH
	 */
	public Object getMinH() {
		return minH;
	}
	/**
	 * @param minH the minH to set
	 */
	public void setMinH(Object minH) {
		this.minH = minH;
	}
	/**
	 * @return the maxH
	 */
	public Object getMaxH() {
		return maxH;
	}
	/**
	 * @param maxH the maxH to set
	 */
	public void setMaxH(Object maxH) {
		this.maxH = maxH;
	}
	/**
	 * @return the maxW
	 */
	public Object getMaxW() {
		return maxW;
	}
	/**
	 * @param maxW the maxW to set
	 */
	public void setMaxW(Object maxW) {
		this.maxW = maxW;
	}
	/**
	 * @return the moved
	 */
	public Boolean getMoved() {
		return moved;
	}
	/**
	 * @param moved the moved to set
	 */
	public void setMoved(Boolean moved) {
		this.moved = moved;
	}
	/**
	 * @return the widgetStatic
	 */
	@JsonProperty("static")
	public Boolean getWidgetStatic() {
		return widgetStatic;
	}
	/**
	 * @param widgetStatic the widgetStatic to set
	 */
	public void setWidgetStatic(Boolean widgetStatic) {
		this.widgetStatic = widgetStatic;
	}
	/**
	 * @return the className
	 */
	public String getClassName() {
		return className;
	}
	/**
	 * @param className the className to set
	 */
	public void setClassName(String className) {
		this.className = className;
	}

	
	

}
