package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
//@JsonIgnoreProperties(ignoreUnknown = true)
public class Module {

	private String guid;
	private String name;
	private String solutionGuid;

	private String categoryName;
	private Object permission;

	/**
	 * 
	 */
	public Module() {
		super();
	}

	/**
	 * @return the categoryName
	 */
	public String getCategoryName() {
		return categoryName;
	}

	/**
	 * @param categoryName the categoryName to set
	 */
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	/**
	 * @return the permission
	 */
	public Object getPermission() {
		return permission;
	}

	/**
	 * @param permission the permission to set
	 */
	public void setPermission(Object permission) {
		this.permission = permission;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the solutionGuid
	 */
	public String getSolutionGuid() {
		return solutionGuid;
	}

	/**
	 * @param solutionGuid the solutionGuid to set
	 */
	public void setSolutionGuid(String solutionGuid) {
		this.solutionGuid = solutionGuid;
	}

}
