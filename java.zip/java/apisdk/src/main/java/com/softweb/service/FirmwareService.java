package com.softweb.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.softweb.model.ApiResponse;
import com.softweb.model.Firmware;
import com.softweb.model.FirmwareUpgrade;
import com.softweb.model.OTAUpdate;
import com.softweb.model.OTAUpdateItem;
import com.softweb.temp.model.AddEntity;

/**
 * @author shreya.hedau
 *
 */
public interface FirmwareService {
	
	// Firmware
	// Get Firmware List
	ApiResponse<List<Firmware>> getFirmwareList(Map<String, String> headers, Integer pageNumber, Integer pageSize, String searchText,
			String sortBy) throws IOException;

	// Get FirmwareDetail
	ApiResponse<List<Firmware>> getFirmwareDetail(Map<String, String> headers, String firmwareGuid) throws IOException;

	// Add Firmware
	ApiResponse<ArrayList<AddEntity>> addFirmware(Map<String, String> headers, File file,
			String firmwareName, String firmwareDescription, String software, String hardware) throws IOException;

	// Update Firmware
	ApiResponse<Void> updateFirmware(Map<String, String> headers, String firmwareGuid, String firmwareName, String hardware,String status) throws IOException;

	// Add Firmware Validate
	ApiResponse<ArrayList<AddEntity>> addFirmwareValidate(Map<String, String> headers, ArrayList<Firmware> firmware) throws IOException;

	// Get Minor Firmware Detail
	ApiResponse<List<FirmwareUpgrade>> getMinorFirmwareDetail(Map<String, String> headers, String firmwareGuid) throws IOException;

	// Update Firmware Upgrade
	ApiResponse<Void> updateFirmwareUpgrade(Map<String, String> headers, File file, String firmwareUpgradeGuid, String firmwareGuid,
			String firmwareDescription, String software) throws IOException;

	// Add Firmware Upgrade
	ApiResponse<ArrayList<AddEntity>> addFirmwareUpgrade(Map<String, String> headers, File file, String firmwareDescription, String firmwareGuid,
			String software) throws IOException;

	// Firmware Upgrade List
	ApiResponse<List<FirmwareUpgrade>> firmwareUpgradeList(Map<String, String> headers, String firmwareGuid, String type, Integer pageNumber,
			Integer pageSize, String searchText, String sortBy)  throws IOException;

	// Firmware Lookup By FirmwareGuid
	ApiResponse<List<Firmware>> lookupFirmware(Map<String, String> headers, String firmwareGuid) throws IOException;

	// Publish Firmware
	ApiResponse<List<FirmwareUpgrade>> publishFirmware(Map<String, String> headers, String firmwareUpgradeGuid) throws IOException;

	// Firmware Lookup
	ApiResponse<List<Firmware>> lookupFirmware(Map<String,String> headers) throws IOException;
	
	ApiResponse<Void> deleteFirmwareUpgrade(Map<String, String> headers, String firmwareUpgradeGuid) throws IOException;

	// OTA Update

	// Get OTA Update
	ApiResponse<List<OTAUpdate>> getOTAUpdate(Map<String, String> headers, Integer pageNumber, Integer pageSize, String searchText,
			String sortBy) throws IOException;

	// Get OTA Update By Device Guid
	ApiResponse<List<OTAUpdate>> getOTAUpdateByDeviceGuid(Map<String, String> headers, String deviceGuid) throws IOException;

	// Send OTA Update
	ApiResponse<OTAUpdateItem> sendOTAUpdate(Map<String, String> headers, String firmwareUpgradeGuid, Integer isForceUpdate,
			String entityGuid, String scheduledOn, Integer isRecursive) throws IOException;

	// get OTA Update Details
	ApiResponse<List<OTAUpdate>> getOTAUpdateDetails(Map<String, String> headers, String otaUpdateGuid) throws IOException;

	// Get OTA Update Status List
	ApiResponse<List<OTAUpdate>> getOTAUpdateStatusList(Map<String, String> headers, String id, String status, Integer pageNumber,
			Integer pageSize, String searchText, String sortBy) throws IOException;

	// Get recent OTA update Statistics
	ApiResponse<List<OTAUpdate>> getRecentOTAUpdateStatistics(Map<String, String> headers, Integer count, String status) throws IOException;

}
