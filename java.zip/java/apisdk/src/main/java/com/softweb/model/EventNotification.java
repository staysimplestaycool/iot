package com.softweb.model;

import java.sql.Date;

/**
 * @author shreya.hedau
 *
 */
public class EventNotification {

	private String guid;
	private String eventTriggedGuid;
	private Integer deliveryMethod;
	private String userGuid;
	private Date createdDate;

	/**
	 * 
	 */
	public EventNotification() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the eventTriggedGuid
	 */
	public String getEventTriggedGuid() {
		return eventTriggedGuid;
	}

	/**
	 * @param eventTriggedGuid the eventTriggedGuid to set
	 */
	public void setEventTriggedGuid(String eventTriggedGuid) {
		this.eventTriggedGuid = eventTriggedGuid;
	}

	/**
	 * @return the deliveryMethod
	 */
	public Integer getDeliveryMethod() {
		return deliveryMethod;
	}

	/**
	 * @param deliveryMethod the deliveryMethod to set
	 */
	public void setDeliveryMethod(Integer deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	/**
	 * @return the userGuid
	 */
	public String getUserGuid() {
		return userGuid;
	}

	/**
	 * @param userGuid the userGuid to set
	 */
	public void setUserGuid(String userGuid) {
		this.userGuid = userGuid;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
