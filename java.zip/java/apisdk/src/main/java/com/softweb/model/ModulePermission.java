package com.softweb.model;

import java.sql.Date;

/**
 * @author shreya.hedau
 *
 */
public class ModulePermission {

	private String guid;
	private String roleGuid;
	private String modulePermissionGuid;
	private String companyGuid; // to discard or to keep
	private Date createdDate;
	private User createdBy;

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the roleGuid
	 */
	public String getRoleGuid() {
		return roleGuid;
	}

	/**
	 * @param roleGuid the roleGuid to set
	 */
	public void setRoleGuid(String roleGuid) {
		this.roleGuid = roleGuid;
	}

	/**
	 * @return the modulePermissionGuid
	 */
	public String getModulePermissionGuid() {
		return modulePermissionGuid;
	}

	/**
	 * @param modulePermissionGuid the modulePermissionGuid to set
	 */
	public void setModulePermissionGuid(String modulePermissionGuid) {
		this.modulePermissionGuid = modulePermissionGuid;
	}

	/**
	 * @return the companyGuid
	 */
	public String getCompanyGuid() {
		return companyGuid;
	}

	/**
	 * @param companyGuid the companyGuid to set
	 */
	public void setCompanyGuid(String companyGuid) {
		this.companyGuid = companyGuid;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

}
