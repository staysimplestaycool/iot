package com.softweb.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.softweb.model.ApiResponse;
import com.softweb.model.Module;
import com.softweb.model.Role;

/**
 * @author shreya.hedau
 *
 */
public interface AuthorizeService {

	// get module list
	ApiResponse<ArrayList<Module>> getModuleList(Map<String,String> headers, Boolean isPermission) throws IOException;

	// get role permission
	ApiResponse<Role> getRolePermission(Map<String,String> headers, String roleGuid) throws IOException;

	// get user role module permission
	ApiResponse<ArrayList<Role>> getUserRoleModulePermission(Map<String,String> headers) throws IOException;
	
	//  get role module permission
	ApiResponse<Void> assignRoleModulePermission(Map<String,String> headers, String roleGuid, String roleName, String roleDescription,
			ArrayNode modules) throws IOException;

}
