package com.softweb.model;

import java.sql.Date;

/**
 * @author shreya.hedau
 *
 */
public class OTAUpdateItem {

	private String guid;
	private OTAUpdate otaUpdateGuid;
	private Device deviceGuid;
	private Company companyGuid;
	private Date availableDate;
	private Boolean isForceUpdate;
	private Boolean isDeleted;
	private String status;
	private Date updatedDate;

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the otaUpdateGuid
	 */
	public OTAUpdate getOtaUpdateGuid() {
		return otaUpdateGuid;
	}

	/**
	 * @param otaUpdateGuid the otaUpdateGuid to set
	 */
	public void setOtaUpdateGuid(OTAUpdate otaUpdateGuid) {
		this.otaUpdateGuid = otaUpdateGuid;
	}

	/**
	 * @return the deviceGuid
	 */
	public Device getDeviceGuid() {
		return deviceGuid;
	}

	/**
	 * @param deviceGuid the deviceGuid to set
	 */
	public void setDeviceGuid(Device deviceGuid) {
		this.deviceGuid = deviceGuid;
	}

	/**
	 * @return the companyGuid
	 */
	public Company getCompanyGuid() {
		return companyGuid;
	}

	/**
	 * @param companyGuid the companyGuid to set
	 */
	public void setCompanyGuid(Company companyGuid) {
		this.companyGuid = companyGuid;
	}

	/**
	 * @return the availableDate
	 */
	public Date getAvailableDate() {
		return availableDate;
	}

	/**
	 * @param availableDate the availableDate to set
	 */
	public void setAvailableDate(Date availableDate) {
		this.availableDate = availableDate;
	}

	/**
	 * @return the isForceUpdate
	 */
	public Boolean getIsForceUpdate() {
		return isForceUpdate;
	}

	/**
	 * @param isForceUpdate the isForceUpdate to set
	 */
	public void setIsForceUpdate(Boolean isForceUpdate) {
		this.isForceUpdate = isForceUpdate;
	}

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

}
