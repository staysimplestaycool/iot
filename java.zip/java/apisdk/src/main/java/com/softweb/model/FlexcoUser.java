package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class FlexcoUser {

	private String guid;
	private Boolean acceptedTC;
	private String acceptedTCDate;
	private String accountExpiry;
	private String createdBy;
	private String firstName;
	private String lastName;
	private String email;
	private String companyguid;
	private String roleguid;
	private Boolean isdeleted;
	private Boolean isTemp;

	/**
	 * 
	 */
	public FlexcoUser() {
		super();
	}

	/**
	 * @return
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return
	 */
	public Boolean getAcceptedTC() {
		return acceptedTC;
	}

	/**
	 * @param acceptedTC
	 */
	public void setAcceptedTC(Boolean acceptedTC) {
		this.acceptedTC = acceptedTC;
	}

	/**
	 * @return
	 */
	public String getAcceptedTCDate() {
		return acceptedTCDate;
	}

	/**
	 * @param acceptedTCDate
	 */
	public void setAcceptedTCDate(String acceptedTCDate) {
		this.acceptedTCDate = acceptedTCDate;
	}

	/**
	 * @return
	 */
	public String getAccountExpiry() {
		return accountExpiry;
	}

	/**
	 * @param accountExpiry
	 */
	public void setAccountExpiry(String accountExpiry) {
		this.accountExpiry = accountExpiry;
	}

	/**
	 * @return
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return
	 */
	public String getCompanyguid() {
		return companyguid;
	}

	/**
	 * @param companyguid
	 */
	public void setCompanyguid(String companyguid) {
		this.companyguid = companyguid;
	}

	/**
	 * @return
	 */
	public String getRoleguid() {
		return roleguid;
	}

	/**
	 * @param roleguid
	 */
	public void setRoleguid(String roleguid) {
		this.roleguid = roleguid;
	}

	/**
	 * @return
	 */
	public Boolean getIsdeleted() {
		return isdeleted;
	}

	/**
	 * @param isdeleted
	 */
	public void setIsdeleted(Boolean isdeleted) {
		this.isdeleted = isdeleted;
	}

	/**
	 * @return
	 */
	public Boolean getIsTemp() {
		return isTemp;
	}

	/**
	 * @param isTemp
	 */
	public void setIsTemp(Boolean isTemp) {
		this.isTemp = isTemp;
	}
}
