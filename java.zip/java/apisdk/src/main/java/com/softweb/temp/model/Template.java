package com.softweb.temp.model;

import java.sql.Date;

/**
 * @author shreya.hedau
 *
 */
public class Template {

	private String guid;
	private String code;
	private String name;
	private String description;
	private String firmwareGuid;
	private Date createdDate;
	private Date updatedDate;
	private Integer attributeCount;
	private Integer settingCount;
	private Integer commandCount;
	private Integer deviceCount;

	public Template() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the firmwareGuid
	 */
	public String getFirmwareGuid() {
		return firmwareGuid;
	}

	/**
	 * @param firmwareGuid the firmwareGuid to set
	 */
	public void setFirmwareGuid(String firmwareGuid) {
		this.firmwareGuid = firmwareGuid;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the attributeCount
	 */
	public Integer getAttributeCount() {
		return attributeCount;
	}

	/**
	 * @param attributeCount the attributeCount to set
	 */
	public void setAttributeCount(Integer attributeCount) {
		this.attributeCount = attributeCount;
	}

	/**
	 * @return the settingCount
	 */
	public Integer getSettingCount() {
		return settingCount;
	}

	/**
	 * @param settingCount the settingCount to set
	 */
	public void setSettingCount(Integer settingCount) {
		this.settingCount = settingCount;
	}

	/**
	 * @return the commandCount
	 */
	public Integer getCommandCount() {
		return commandCount;
	}

	/**
	 * @param commandCount the commandCount to set
	 */
	public void setCommandCount(Integer commandCount) {
		this.commandCount = commandCount;
	}

	/**
	 * @return the deviceCount
	 */
	public Integer getDeviceCount() {
		return deviceCount;
	}

	/**
	 * @param deviceCount the deviceCount to set
	 */
	public void setDeviceCount(Integer deviceCount) {
		this.deviceCount = deviceCount;
	}
	
	

}
