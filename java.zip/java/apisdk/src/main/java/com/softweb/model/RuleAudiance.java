package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class RuleAudiance {

	private String guid;
	private Rule ruleGuid;
	private Boolean audianceType;
	private String audianceGuid;

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the ruleGuid
	 */
	public Rule getRuleGuid() {
		return ruleGuid;
	}

	/**
	 * @param ruleGuid the ruleGuid to set
	 */
	public void setRuleGuid(Rule ruleGuid) {
		this.ruleGuid = ruleGuid;
	}

	/**
	 * @return the audianceType
	 */
	public Boolean getAudianceType() {
		return audianceType;
	}

	/**
	 * @param audianceType the audianceType to set
	 */
	public void setAudianceType(Boolean audianceType) {
		this.audianceType = audianceType;
	}

	/**
	 * @return the audianceGuid
	 */
	public String getAudianceGuid() {
		return audianceGuid;
	}

	/**
	 * @param audianceGuid the audianceGuid to set
	 */
	public void setAudianceGuid(String audianceGuid) {
		this.audianceGuid = audianceGuid;
	}
}
