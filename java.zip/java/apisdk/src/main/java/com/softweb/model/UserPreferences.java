package com.softweb.model;

import java.util.ArrayList;

/**
 * @author shreya.hedau
 *
 */
//@JsonIgnoreProperties(ignoreUnknown = true)
public class UserPreferences {
   
	private String guid;
	private User userGuid;
	private String emailNotification;
	private String alternateEmailID;
	private Boolean smsNotification;
	private Boolean pushNotification;
	private Double pageSize;
	private String createdDate;
	private String createdBy;
	private String updatedDate;
	private String updatedBy;
	
	private String timeZoneGuid;
	private Boolean emailNotifyOn;
	private ArrayList<UserInfo> userInfo;

	/**
	 * 
	 */
	public UserPreferences() {
		super();
	}

	/**
	 * @return the timeZoneGuid
	 */
	public String getTimeZoneGuid() {
		return timeZoneGuid;
	}

	/**
	 * @param timeZoneGuid the timeZoneGuid to set
	 */
	public void setTimeZoneGuid(String timeZoneGuid) {
		this.timeZoneGuid = timeZoneGuid;
	}

	/**
	 * @return the emailNotifyOn
	 */
	public Boolean getEmailNotifyOn() {
		return emailNotifyOn;
	}

	/**
	 * @param emailNotifyOn the emailNotifyOn to set
	 */
	public void setEmailNotifyOn(Boolean emailNotifyOn) {
		this.emailNotifyOn = emailNotifyOn;
	}

	/**
	 * @return the userInfo
	 */
	public ArrayList<UserInfo> getUserInfo() {
		return userInfo;
	}

	/**
	 * @param userInfo the userInfo to set
	 */
	public void setUserInfo(ArrayList<UserInfo> userInfo) {
		this.userInfo = userInfo;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the userGuid
	 */
	public User getUserGuid() {
		return userGuid;
	}

	/**
	 * @param userGuid the userGuid to set
	 */
	public void setUserGuid(User userGuid) {
		this.userGuid = userGuid;
	}

	/**
	 * @return the emailNotification
	 */
	public String getEmailNotification() {
		return emailNotification;
	}

	/**
	 * @param emailNotification the emailNotification to set
	 */
	public void setEmailNotification(String emailNotification) {
		this.emailNotification = emailNotification;
	}

	/**
	 * @return the alternateEmailID
	 */
	public String getAlternateEmailID() {
		return alternateEmailID;
	}

	/**
	 * @param alternateEmailID the alternateEmailID to set
	 */
	public void setAlternateEmailID(String alternateEmailID) {
		this.alternateEmailID = alternateEmailID;
	}

	/**
	 * @return the smsNotification
	 */
	public Boolean getSmsNotification() {
		return smsNotification;
	}

	/**
	 * @param smsNotification the smsNotification to set
	 */
	public void setSmsNotification(Boolean smsNotification) {
		this.smsNotification = smsNotification;
	}

	/**
	 * @return the pushNotification
	 */
	public Boolean getPushNotification() {
		return pushNotification;
	}

	/**
	 * @param pushNotification the pushNotification to set
	 */
	public void setPushNotification(Boolean pushNotification) {
		this.pushNotification = pushNotification;
	}

	/**
	 * @return the pageSize
	 */
	public Double getPageSize() {
		return pageSize;
	}

	/**
	 * @param pageSize the pageSize to set
	 */
	public void setPageSize(Double pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * @return the createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedDate
	 */
	public String getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
}
