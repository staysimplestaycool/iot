package com.softweb.serviceImpl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.softweb.common.HttpUtil;
import com.softweb.model.ApiResponse;
import com.softweb.model.Device;
import com.softweb.model.ImportBatch;
import com.softweb.model.IoTConnect;
import com.softweb.model.Property;
import com.softweb.service.DeviceService;
import com.softweb.temp.model.AddEntity;

/**
 * @author Uttam Kachhad
 */
public class DeviceServiceImpl implements DeviceService {

	private IoTConnect ioTConnect;

	public DeviceServiceImpl() {
		super();
		ioTConnect = IoTConnect.getInstance();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getUserDeviceList(java.util.Map,
	 * java.lang.Integer, java.lang.Integer, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Device>> getUserDeviceList(Map<String, String> headers, Integer pageNumber,
			Integer pageSize, String searchText)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("searchText", searchText);
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);

		return (ApiResponse<List<Device>>) HttpUtil.getHttpUtil().doGet(ioTConnect.DEVICE_BASE_URL + "/device", data,
				headers, Device.class, true, true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getDeviceCount(java.util.Map,
	 * java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Map<String, Integer>>> getDeviceCount(Map<String, String> headers, String companyguid,
			String status) throws IOException {

		return (ApiResponse<List<Map<String, Integer>>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.DEVICE_BASE_URL + "/device/count", null, headers, Object.class, true, false);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getDeviceInfo(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Device>> getDeviceInfo(Map<String, String> headers, String uniqueId)
			throws IOException {

		return (ApiResponse<List<Device>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.DEVICE_BASE_URL + "/device/" + uniqueId, null, headers, Device.class, true, true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getDeviceInfoByDeviceTemplate(java.
	 * util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Device>> getDeviceInfoByDeviceTemplate(Map<String, String> headers,
			String deviceTemplateGuid) throws IOException {

		return (ApiResponse<List<Device>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.DEVICE_BASE_URL + "/template/" + deviceTemplateGuid + "/device", null, headers, Device.class,
				true, true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getDeviceList(java.util.Map,
	 * java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Device>> getDeviceList(Map<String, String> headers, Integer pageNumber, Integer pageSize,
			String searchText, String sortBy) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("searchText", searchText);
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);
		data.put("sortBy", sortBy);

		return (ApiResponse<List<Device>>) HttpUtil.getHttpUtil().doGet(ioTConnect.DEVICE_BASE_URL + "/device", data,
				headers, Device.class, true, true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getCompanyDeviceList(java.util.Map,
	 * java.lang.String, java.lang.Integer, java.lang.Integer, java.lang.String,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Device>> getCompanyDeviceList(Map<String, String> headers, String companyGuid,
			Integer pageNumber, Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("searchText", searchText);
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);
		data.put("sortBy", sortBy);

		return (ApiResponse<List<Device>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.DEVICE_BASE_URL + "/device-company/" + companyGuid, data, headers, Device.class, true, true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#updateDevice(java.util.Map,
	 * java.lang.String, java.lang.String, java.lang.String, java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateDevice(Map<String, String> headers, String deviceGuid, String displayName,
			String note, ArrayList<Property> properties)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("displayName", displayName);
		data.put("note", note);
		data.putPOJO("properties", ioTConnect.objectMapper.writeValueAsString(properties));

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(ioTConnect.DEVICE_BASE_URL + "/device/" + deviceGuid,
				data, headers, ApiResponse.class, false, false);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.softweb.service.DeviceService#updateDeviceLastActivity(java.util.Map,
	 * java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateDeviceLastActivity(Map<String, String> headers, String deviceGuid,
			String lastActivityDate) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("lastActivityDate", lastActivityDate);
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.DEVICE_BASE_URL + "/device/" + deviceGuid + "/last-activity", data, headers,
				ApiResponse.class, false, false);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getDeviceLookup(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Device>> getDeviceLookup(Map<String, String> headers, String deviceTemplateGuid)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("deviceTemplateGuid", deviceTemplateGuid);

		return (ApiResponse<List<Device>>) HttpUtil.getHttpUtil().doGet(ioTConnect.DEVICE_BASE_URL + "/device/lookup",
				data, headers, Device.class, true, true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getBrokerConnectionStatus(java.util
	 * .Map, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Device>> getBrokerConnectionStatus(Map<String, String> headers, String deviceGuid,
			String uniqueId) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("deviceGuid", deviceGuid);
		data.put("uniqueId", uniqueId);

		return (ApiResponse<List<Device>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.DEVICE_BASE_URL + "/device/broker-connection-status/", data, headers, Device.class, true,
				true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#deleteDevice(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteDevice(Map<String, String> headers, String deviceGuid)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(ioTConnect.DEVICE_BASE_URL + "/device/" + deviceGuid,
				null, headers, ApiResponse.class, false, false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#updateDeviceStatus(java.util.Map,
	 * java.lang.String, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateDeviceStatus(Map<String, String> headers, String deviceGuid, Boolean isActive)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("isActive", isActive);
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.DEVICE_BASE_URL + "/device/" + deviceGuid + "/status", data, headers, ApiResponse.class,
				false, false);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#listOfImportBatch(java.util.Map,
	 * java.lang.Double, java.lang.Double, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<ImportBatch>> listOfImportBatch(Map<String, String> headers, Integer pageNumber,
			Integer pageSize, String sortBy) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);
		data.put("sortBy", sortBy);

		return (ApiResponse<List<ImportBatch>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.DEVICE_BASE_URL + "/import-batch", data, headers, ImportBatch.class, true, true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getPendingDeviceWithPropertyInfo(java
	 * .util.Map, java.lang.String, java.lang.Double, java.lang.Double,
	 * java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<ImportBatch>> getPendingDeviceWithPropertyInfo(Map<String, String> headers,
			String importBatchGuid, Integer pageNumber, Integer pageSize, String sortBy, String searchText)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);
		data.put("sortBy", sortBy);
		data.put("searchText", searchText);

		return (ApiResponse<List<ImportBatch>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.DEVICE_BASE_URL + "/import-batch/" + importBatchGuid, data, headers, ImportBatch.class, true,
				true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#importDeviceInformation(java.util.Map,
	 * java.lang.String, java.io.File)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> importDeviceInformation(Map<String, String> headers, String entityGuid, File file)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPostFile(
				ioTConnect.DEVICE_BASE_URL + "/entity/" + entityGuid + "/import-batch", null, headers, ApiResponse.class,
				false, false, file, "file");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#createSingleDevice(java.util.Map,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<AddEntity>> createSingleDevice(Map<String, String> headers, String displayName,
			String uniqueId, String firmwareUpgradeGuid, String entityGuid, String deviceTemplateGuid, String note,
			ArrayList<Property> properties) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("displayName", displayName);
		data.put("uniqueId", uniqueId);
		data.put("firmwareUpgradeGuid", firmwareUpgradeGuid);
		data.put("entityGuid", entityGuid);
		data.put("deviceTemplateGuid", deviceTemplateGuid);
		data.put("note", note);
		data.putPOJO("properties", ioTConnect.objectMapper.writeValueAsString(properties));

		return (ApiResponse<ArrayList<AddEntity>>) HttpUtil.getHttpUtil().doPost(ioTConnect.DEVICE_BASE_URL + "/device",
				data, headers, AddEntity.class, true, true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#updateDeviceProperties(java.util.Map,
	 * java.lang.String, java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateDeviceProperties(Map<String, String> headers, String deviceGuid,
			ArrayList<Property> properties) throws IOException {

		ObjectNode data = IoTConnect.objectMapper.createObjectNode();
		data.putPOJO("properties", ioTConnect.objectMapper.writeValueAsString(properties));
		
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.DEVICE_BASE_URL + "/device/" + deviceGuid + "/properties", data, headers, ApiResponse.class,
				false, false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#deleteDeviceProperty(java.util.Map,
	 * java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteDeviceProperty(Map<String, String> headers, String deviceGuid,
			String devicePropertyGuid) throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(
				ioTConnect.DEVICE_BASE_URL + "/device/" + deviceGuid + "/property/" + devicePropertyGuid, null,
				headers, ApiResponse.class, false, false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#updateDeviceImage(java.util.Map,
	 * java.lang.String, java.io.File)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> updateDeviceImage(Map<String, String> headers, String deviceGuid,
			File file) throws IOException {
		
		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil().doPutFile(
				ioTConnect.DEVICE_BASE_URL + "/device/" + deviceGuid + "/image", null, headers, Map.class, true, true,
				file, "deviceImageFile");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getAcquireDeviceCount(java.util.Map,
	 * java.lang.Integer)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Map<String, String>>> getAcquireDeviceCount(Map<String, String> headers, Integer count)
			throws IOException {

		return (ApiResponse<List<Map<String, String>>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.DEVICE_BASE_URL + "/device/acquire/" + count, null, headers, Object.class, true, false);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getAcquireDeviceList(java.util.Map,
	 * java.lang.Integer, java.lang.Boolean, java.lang.Boolean, java.lang.Boolean,
	 * java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Device>> getAcquireDeviceList(Map<String, String> headers, Integer count,
			Boolean isConnected, Boolean isAcquired, Boolean isActive, Boolean isOtaupdate)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("count", count);
		data.put("isConnected", isConnected);
		data.put("isAcquired", isAcquired);
		data.put("isActive", isActive);
		data.put("isOtaupdate", isOtaupdate);

		return (ApiResponse<List<Device>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.DEVICE_BASE_URL + "/device/recent-activity", data, headers, Device.class, true, true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#deviceAcquire(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deviceAcquire(Map<String, String> headers, String uniqueId)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.DEVICE_BASE_URL + "/device/" + uniqueId + "/acquire", "null", headers, ApiResponse.class,
				false, false);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#deviceRelease(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deviceRelease(Map<String, String> headers, String uniqueId)
			throws IOException {
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.DEVICE_BASE_URL + "/device/" + uniqueId + "/release", "null", headers, ApiResponse.class,
				false, false);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getDeviceListByEntityGuid(java.util
	 * .Map, java.lang.String, java.lang.Integer, java.lang.Integer,
	 * java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Device>> getDeviceListByEntityGuid(Map<String, String> headers, String entityGuid,
			Integer pageNumber, Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);
		data.put("searchText", searchText);
		data.put("sortBy", sortBy);

		return (ApiResponse<List<Device>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.DEVICE_BASE_URL + "/device/entity/" + entityGuid, data, headers, Device.class, true, true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.DeviceService#getDeviceListByTemplateGuid(java.util
	 * .Map, java.lang.String, java.lang.Integer, java.lang.Integer,
	 * java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Device>> getDeviceListByTemplateGuid(Map<String, String> headers, String templateGuid,
			Integer pageNumber, Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);
		data.put("searchText", searchText);
		data.put("sortBy", sortBy);

		return (ApiResponse<List<Device>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.DEVICE_BASE_URL + "/device/template/" + templateGuid, data, headers, Device.class, true,
				true);

	}

}
