package com.softweb.temp.model;

/**
 * @author shreya.hedau
 *
 */
public class CompanyStatisticData {

	private CompanyStatistic companyStatistic;

	/**
	 * @return the companyStatistic
	 */
	public CompanyStatistic getCompanyStatistic() {
		return companyStatistic;
	}

	/**
	 * @param companyStatistic the companyStatistic to set
	 */
	public void setCompanyStatistic(CompanyStatistic companyStatistic) {
		this.companyStatistic = companyStatistic;
	}
	
	
}
