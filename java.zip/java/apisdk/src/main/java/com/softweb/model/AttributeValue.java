package com.softweb.model;

import java.util.Date;

/**
 * @author mayuri.mojidra
 *
 */
public class AttributeValue {
	private String guid;
	private TemplateAttribute templateAttribute;
	private Device device;
	private String attributeValue;
	private Company company;
	private Date createdDate;
	private Date sdkUpdatedDate;
	private Date gatewayUpdatedDate;
	private Date deviceUpdatedDate;

	/**
	 * 
	 */
	public AttributeValue() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the templateAttribute
	 */
	public TemplateAttribute getTemplateAttribute() {
		return templateAttribute;
	}

	/**
	 * @param templateAttribute the templateAttribute to set
	 */
	public void setTemplateAttribute(TemplateAttribute templateAttribute) {
		this.templateAttribute = templateAttribute;
	}

	/**
	 * @return the device
	 */
	public Device getDevice() {
		return device;
	}

	/**
	 * @param device the device to set
	 */
	public void setDevice(Device device) {
		this.device = device;
	}

	/**
	 * @return the attributeValue
	 */
	public String getAttributeValue() {
		return attributeValue;
	}

	/**
	 * @param attributeValue the attributeValue to set
	 */
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	/**
	 * @return the company
	 */
	public Company getCompany() {
		return company;
	}

	/**
	 * @param company the company to set
	 */
	public void setCompany(Company company) {
		this.company = company;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the sdkUpdatedDate
	 */
	public Date getSdkUpdatedDate() {
		return sdkUpdatedDate;
	}

	/**
	 * @param sdkUpdatedDate the sdkUpdatedDate to set
	 */
	public void setSdkUpdatedDate(Date sdkUpdatedDate) {
		this.sdkUpdatedDate = sdkUpdatedDate;
	}

	/**
	 * @return the gatewayUpdatedDate
	 */
	public Date getGatewayUpdatedDate() {
		return gatewayUpdatedDate;
	}

	/**
	 * @param gatewayUpdatedDate the gatewayUpdatedDate to set
	 */
	public void setGatewayUpdatedDate(Date gatewayUpdatedDate) {
		this.gatewayUpdatedDate = gatewayUpdatedDate;
	}

	/**
	 * @return the deviceUpdatedDate
	 */
	public Date getDeviceUpdatedDate() {
		return deviceUpdatedDate;
	}

	/**
	 * @param deviceUpdatedDate the deviceUpdatedDate to set
	 */
	public void setDeviceUpdatedDate(Date deviceUpdatedDate) {
		this.deviceUpdatedDate = deviceUpdatedDate;
	}

}
