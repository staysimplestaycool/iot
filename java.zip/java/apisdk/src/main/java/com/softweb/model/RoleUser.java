package com.softweb.model;

import java.sql.Date;

/**
 * @author shreya.hedau
 *
 */
public class RoleUser {

	private String guid;
	private Role roleGuid;
	private User userGuid;
	private Date createdDate;
	private User createdBy;

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the roleGuid
	 */
	public Role getRoleGuid() {
		return roleGuid;
	}

	/**
	 * @param roleGuid the roleGuid to set
	 */
	public void setRoleGuid(Role roleGuid) {
		this.roleGuid = roleGuid;
	}

	/**
	 * @return the userGuid
	 */
	public User getUserGuid() {
		return userGuid;
	}

	/**
	 * @param userGuid the userGuid to set
	 */
	public void setUserGuid(User userGuid) {
		this.userGuid = userGuid;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

}
