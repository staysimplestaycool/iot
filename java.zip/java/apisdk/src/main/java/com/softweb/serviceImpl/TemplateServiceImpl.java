package com.softweb.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.softweb.common.HttpUtil;
import com.softweb.model.ApiResponse;
import com.softweb.model.CommandHistory;
import com.softweb.model.DataType;
import com.softweb.model.IoTConnect;
import com.softweb.model.Rule;
import com.softweb.model.TemplateAttribute;
import com.softweb.model.TemplateCommand;
import com.softweb.model.TemplateSetting;
import com.softweb.service.TemplateService;
import com.softweb.temp.model.Attributes;
import com.softweb.temp.model.RuleList;
import com.softweb.temp.model.Template;

public class TemplateServiceImpl implements TemplateService {

	public static final String PAGENUMBER = "pageNumber";
	public static final String PAGESIZE = "pageSize";
	public static final String SEARCHTEXT = "searchText";
	public static final String SORTBY = "sortBy";

	private IoTConnect ioTConnect;

	/**
	 * 
	 */
	public TemplateServiceImpl() {
		super();
		ioTConnect = IoTConnect.getInstance();
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#lookupTemplate(java.util.Map, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<DataType>> lookupTemplate(Map<String, String> headers, Boolean hasAttribute)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("hasAttribute", hasAttribute);

		return (ApiResponse<ArrayList<DataType>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TEMPLATE_BASE_URL + "/device-template/lookup", data, headers, DataType.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#dataType(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<DataType>> dataType(Map<String, String> headers)
			throws IOException {

		return (ApiResponse<ArrayList<DataType>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TEMPLATE_BASE_URL + "/device-template/datatype", null, headers, DataType.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#templateDetail(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Template>> templateDetail(Map<String, String> headers, String templateGuid)
			throws IOException {
		return (ApiResponse<ArrayList<Template>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TEMPLATE_BASE_URL + "/device-template/" + templateGuid, null, headers, Template.class, true,
				true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#templateJsonView(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Object>> templateJsonView(Map<String, String> headers, String templateGuid)
			throws IOException {

		return (ApiResponse<ArrayList<Object>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TEMPLATE_BASE_URL + "/device-template/jsonview/" + templateGuid, null, headers, Object.class,
				true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#templateList(java.util.Map, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Template>> templateList(Map<String, String> headers, Integer pageNumber,
			Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(PAGENUMBER, pageNumber);
		data.put(PAGESIZE, pageSize);
		data.put(SEARCHTEXT, searchText);
		data.put(SORTBY, sortBy);

		return (ApiResponse<ArrayList<Template>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.TEMPLATE_BASE_URL + "/device-template/", data, headers, Template.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#addTemplate(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> addTemplate(Map<String, String> headers, String code,
			String name, String firmwareGuid, String description)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("code", code);
		data.put("name", name);
		data.put("firmwareguid", firmwareGuid);
		data.put("description", description);

		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil()
				.doPost(ioTConnect.TEMPLATE_BASE_URL + "/device-template", data, headers, Map.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#updateTemplate(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateTemplate(Map<String, String> headers, String templateGuid, String name,
			String firmwareGuid, String description)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("firmwareguid", firmwareGuid);
		data.put("description", description);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.TEMPLATE_BASE_URL + "/device-template/" + templateGuid, data, headers,
				ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#deleteTemplate(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteTemplate(Map<String, String> headers, String templateGuid)
			throws IOException {
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(
				ioTConnect.TEMPLATE_BASE_URL + "/device-template/" + templateGuid, null, headers, ApiResponse.class,
				false, false);
	}

	// SETTING
	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#lookupSetting(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<TemplateSetting>> lookupSetting(Map<String, String> headers, String deviceTemplateGuid)
			throws IOException {
		return (ApiResponse<ArrayList<TemplateSetting>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TEMPLATE_SETTING_BASE_URL + "/template-setting/lookup/" + deviceTemplateGuid, null, headers,
				TemplateSetting.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#settingList(java.util.Map, java.lang.String, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<TemplateSetting>> settingList(Map<String, String> headers, String deviceTemplateGuid,
			Integer pageNumber, Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(PAGENUMBER, pageNumber);
		data.put(PAGESIZE, pageSize);
		data.put(SEARCHTEXT, searchText);
		data.put(SORTBY, sortBy);

		return (ApiResponse<ArrayList<TemplateSetting>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TEMPLATE_SETTING_BASE_URL + "/template-setting/" + deviceTemplateGuid, data, headers,
				TemplateSetting.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#addSetting(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> addSetting(Map<String, String> headers, String name,
			String dataTypeGuid, String deviceTemplateGuid, String localName, String defaultValue,
			String dataValidation) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("dataTypeGuid", dataTypeGuid);
		data.put("deviceTemplateGuid", deviceTemplateGuid);
		data.put("localName", localName);
		data.put("defaultValue", defaultValue);
		data.put("dataValidation", dataValidation);

		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil().doPost(
				ioTConnect.TEMPLATE_SETTING_BASE_URL + "/template-setting", data, headers, Map.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#updateSetting(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateSetting(Map<String, String> headers, String settingGuid, String name,
			String dataTypeGuid, String deviceTemplateGuid, String localName, String defaultValue,
			String dataValidation) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("dataTypeGuid", dataTypeGuid);
		data.put("deviceTemplateGuid", deviceTemplateGuid);
		data.put("localName", localName);
		data.put("defaultValue", defaultValue);
		data.put("dataValidation", dataValidation);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.TEMPLATE_SETTING_BASE_URL + "/template-setting/" + settingGuid, data, headers,
				ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#deleteSetting(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteSetting(Map<String, String> headers, String templateGuid)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(
				ioTConnect.TEMPLATE_SETTING_BASE_URL + "/template-setting/" + templateGuid, null, headers,
				ApiResponse.class, false, false);

	}

	// Attribute
	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#lookupAttribute(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<TemplateAttribute>> lookupAttribute(Map<String, String> headers,
			String deviceTemplateGuid) throws IOException {
		return (ApiResponse<ArrayList<TemplateAttribute>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TEMPLATE_ATTRIBUTE_BASE_URL + "/template-attribute/lookup/" + deviceTemplateGuid, null,
				headers, TemplateAttribute.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#attributeList(java.util.Map, java.lang.String, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<TemplateAttribute>> attributeList(Map<String, String> headers,
			String deviceTemplateGuid, Integer pageNumber, Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(PAGENUMBER, pageNumber);
		data.put(PAGESIZE, pageSize);
		data.put(SEARCHTEXT, searchText);
		data.put(SORTBY, sortBy);

		return (ApiResponse<ArrayList<TemplateAttribute>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TEMPLATE_ATTRIBUTE_BASE_URL + "/template-attribute/" + deviceTemplateGuid, data, headers,
				TemplateAttribute.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#addAttribute(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> addAttribute(Map<String, String> headers, String localName,
			String description, String deviceTemplateGuid, String dataTypeGuid, String dataValidation, String unit,
			ArrayList<Attributes> attributes) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("localName", localName);
		data.put("description", description);
		data.put("deviceTemplateGuid", deviceTemplateGuid);
		data.put("dataTypeGuid", dataTypeGuid);
		data.put("dataValidation", dataValidation);
		data.put("unit", unit);
		data.put("attributes", ioTConnect.objectMapper.writeValueAsString(attributes));

		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil().doPost(
				ioTConnect.TEMPLATE_ATTRIBUTE_BASE_URL + "/template-attribute", data, headers, Map.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#updateAttribute(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateAttribute(Map<String, String> headers, String attributeGuid, String localName,
			String description, String deviceTemplateGuid, String dataTypeGuid, String dataValidation, String unit,
			ArrayList<Attributes> attributes) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("localName", localName);
		data.put("description", description);
		data.put("deviceTemplateGuid", deviceTemplateGuid);
		data.put("dataTypeGuid", dataTypeGuid);
		data.put("dataValidation", dataValidation);
		data.put("unit", unit);
		data.put("attributes", ioTConnect.objectMapper.writeValueAsString(attributes));

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.TEMPLATE_ATTRIBUTE_BASE_URL + "/template-attribute/" + attributeGuid, data,
				headers, ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#deleteAttribute(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteAttribute(Map<String, String> headers, String attributeGuid)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(
				ioTConnect.TEMPLATE_ATTRIBUTE_BASE_URL + "/template-attribute/" + attributeGuid, null, headers,
				ApiResponse.class, false, false);

	}

	// COMMAND
	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#commandLookup(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<TemplateCommand>> commandLookup(Map<String, String> headers, String deviceTemplateGuid)
			throws IOException {

		return (ApiResponse<ArrayList<TemplateCommand>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TEMPLATE_COMMAND_BASE_URL + "/template-command/lookup/" + deviceTemplateGuid, null, headers,
				TemplateCommand.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#templateCommandList(java.util.Map, java.lang.String, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<TemplateCommand>> templateCommandList(Map<String, String> headers,
			String deviceTemplateGuid, Integer pageNumber, Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(PAGENUMBER, pageNumber);
		data.put(PAGESIZE, pageSize);
		data.put(SEARCHTEXT, searchText);
		data.put(SORTBY, sortBy);

		return (ApiResponse<ArrayList<TemplateCommand>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TEMPLATE_COMMAND_BASE_URL + "/template-command/" + deviceTemplateGuid, data, headers,
				TemplateCommand.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#addTemplateCommand(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> addTemplateCommand(Map<String, String> headers, String name,
			String command, String deviceTemplateGuid, Boolean requiredParam, Boolean requiredAck)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("command", command);
		data.put("deviceTemplateGuid", deviceTemplateGuid);
		data.put("requiredParam", requiredParam);
		data.put("requiredAck", requiredAck);
//		data = ioTConnect.objectMapper.convertValue(templateCommand, ObjectNode.class);

		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil().doPost(
				ioTConnect.TEMPLATE_COMMAND_BASE_URL + "/template-command", data, headers, Map.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#updateTemplateCommand(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateTemplateCommand(Map<String, String> headers, String commandGuid, String name,
			String command, String deviceTemplateGuid, Boolean requiredParam, Boolean requiredAck)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("command", command);
		data.put("deviceTemplateGuid", deviceTemplateGuid);
		data.put("requiredParam", requiredParam);
		data.put("requiredAck", requiredAck);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.TEMPLATE_COMMAND_BASE_URL + "/template-command/" + commandGuid, data, headers,
				ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#deleteTemplateCommand(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteTemplateCommand(Map<String, String> headers, String commandGuid)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(
				ioTConnect.TEMPLATE_COMMAND_BASE_URL + "/template-command/" + commandGuid, null, headers,
				ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#executeCommandOnMultiDevice(java.util.Map, java.lang.String, java.lang.Integer, java.lang.String, java.lang.Boolean, java.util.ArrayList, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> executeCommandOnMultiDevice(Map<String, String> headers,
			String commandGuid, Integer applyTo, String entityGuid, Boolean isRecursive, ArrayList<String> devices,
			String parameterValue) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("commandGuid", commandGuid);
		data.put("applyTo", applyTo);
		data.put("entityGuid", entityGuid);
		data.put("isRecursive", isRecursive);
		data.putPOJO("devices", ioTConnect.objectMapper.writeValueAsString(devices));
		data.put("parameterValue", parameterValue);
		
		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil().doPost(
				ioTConnect.TEMPLATE_COMMAND_BASE_URL + "/template-command/commandHistory", data, headers, Map.class,
				true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#executeCommandOnSingleDevice(java.util.Map, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> executeCommandOnSingleDevice(Map<String, String> headers,
			String deviceGuid, String commandGuid, String parameterValue)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("deviceGuid", deviceGuid);
		data.put("commandGuid", commandGuid);
		data.put("parameterValue", parameterValue);

		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil().doPost(
				ioTConnect.TEMPLATE_COMMAND_BASE_URL + "/template-command/device/" + deviceGuid, data, headers,
				Map.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#getCommandHistory(java.util.Map, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<CommandHistory>> getCommandHistory(Map<String, String> headers, Integer pageNumber,
			Integer pageSize, String searchText, String sortBy, String deviceGuid)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(PAGENUMBER, pageNumber);
		data.put(PAGESIZE, pageSize);
		data.put(SEARCHTEXT, searchText);
		data.put(SORTBY, sortBy);
		data.put("deviceGuid", deviceGuid);

		return (ApiResponse<ArrayList<CommandHistory>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TEMPLATE_COMMAND_BASE_URL + "/template-command/commandHistory", data, headers,
				CommandHistory.class, true, true);

	}

	// RULE
	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#ruleCountService(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, Integer>>> ruleCountService(Map<String, String> headers)
			throws IOException {

		return (ApiResponse<ArrayList<Map<String, Integer>>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.TEMPLATE_RULE_BASE_URL + "/rule/rule-count", null, headers, Map.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#ruleListService(java.util.Map, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<RuleList>> ruleListService(Map<String, String> headers, Integer pageNumber,
			Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(PAGENUMBER, pageNumber);
		data.put(PAGESIZE, pageSize);
		data.put(SEARCHTEXT, searchText);
		data.put(SORTBY, sortBy);

		return (ApiResponse<ArrayList<RuleList>>) HttpUtil.getHttpUtil().doGet(ioTConnect.TEMPLATE_RULE_BASE_URL + "/rule",
				data, headers, RuleList.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#addRuleService(java.util.Map, java.lang.String, java.lang.Integer, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.String, java.lang.Integer, java.util.ArrayList, java.util.ArrayList, java.util.ArrayList, java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> addRuleService(Map<String, String> headers, String templateGuid, Integer ruleType,
			String name, String conditionText, Boolean ignorePreference, String entityGuid, Integer applyTo,
			ArrayList<String> devices, ArrayList<String> roles, ArrayList<String> users,
			ArrayList<String> deliveryMethod) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("templateGuid", templateGuid);
		data.put("ruleType", ruleType);
		data.put("name", name);
		data.put("conditionText", conditionText);
		data.put("ignorePreference", ignorePreference);
		data.put("entityGuid", entityGuid);
		data.put("applyTo", applyTo);
		data.putPOJO("devices", ioTConnect.objectMapper.writeValueAsString(devices));
		data.putPOJO("roles", ioTConnect.objectMapper.writeValueAsString(roles));
		data.putPOJO("users", ioTConnect.objectMapper.writeValueAsString(users));
		data.putPOJO("deliveryMethod", ioTConnect.objectMapper.writeValueAsString(deliveryMethod));
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPost(ioTConnect.TEMPLATE_RULE_BASE_URL + "/rule", data,
				headers, ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#updateRuleService(java.util.Map, java.lang.String, java.lang.String, java.lang.Integer, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.String, java.lang.Integer, java.lang.Boolean, java.util.ArrayList, java.util.ArrayList, java.util.ArrayList, java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateRuleService(Map<String, String> headers, String ruleGuid, String templateGuid,
			Integer ruleType, String name, String conditionText, Boolean ignorePreference, String entityGuid,
			Integer applyTo, Boolean isActive, ArrayList<String> devices, ArrayList<String> roles,
			ArrayList<String> users, ArrayList<String> deliveryMethod)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("templateGuid", templateGuid);
		data.put("ruleType", ruleType);
		data.put("name", name);
		data.put("conditionText", conditionText);
		data.put("ignorePreference", ignorePreference);
		data.put("entityGuid", entityGuid);
		data.put("applyTo", applyTo);
		data.put("isActive", isActive);
		data.putPOJO("devices", ioTConnect.objectMapper.writeValueAsString(devices));
		data.putPOJO("roles", ioTConnect.objectMapper.writeValueAsString(roles));
		data.putPOJO("users", ioTConnect.objectMapper.writeValueAsString(users));
		data.putPOJO("deliveryMethod", ioTConnect.objectMapper.writeValueAsString(deliveryMethod));

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(ioTConnect.TEMPLATE_RULE_BASE_URL + "/rule/" + ruleGuid,
				data, headers, ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#deleteRuleService(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteRuleService(Map<String, String> headers, String ruleGuid)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(
				ioTConnect.TEMPLATE_RULE_BASE_URL + "/rule/" + ruleGuid, null, headers, ApiResponse.class, false,
				false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#ruleDetailService(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Rule> ruleDetailService(Map<String, String> headers, String ruleGuid)
			throws IOException {

		return (ApiResponse<Rule>) HttpUtil.getHttpUtil().doGet(ioTConnect.TEMPLATE_RULE_BASE_URL + "/rule/" + ruleGuid,
				null, headers, Rule.class, true, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#updateRuleStatusService(java.util.Map, java.lang.String, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateRuleStatusService(Map<String, String> headers, String ruleGuid, Boolean isActive)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("isActive", isActive);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.TEMPLATE_RULE_BASE_URL + "/rule/" + ruleGuid + "/status", data, headers,
				ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TemplateService#verifyRuleService(java.util.Map, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Map<String, Object>> verifyRuleService(Map<String, String> headers, String deviceTemplateGuid, String expression)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("deviceTemplateGuid", deviceTemplateGuid);
		data.put("expression", expression);

		return (ApiResponse<Map<String, Object>>) HttpUtil.getHttpUtil().doPost(ioTConnect.TEMPLATE_RULE_BASE_URL + "/rule/verify", data,
				headers, Object.class, true, false);

	}

}
