package com.softweb.temp.model;

/**
 * @author shreya.hedau
 *
 */
public class UserCount {

	private Integer active;
    private Integer inActive;
    private Integer total;
	/**
	 * @return the active
	 */
	public Integer getActive() {
		return active;
	}
	/**
	 * @param active the active to set
	 */
	public void setActive(Integer active) {
		this.active = active;
	}
	/**
	 * @return the inActive
	 */
	public Integer getInActive() {
		return inActive;
	}
	/**
	 * @param inActive the inActive to set
	 */
	public void setInActive(Integer inActive) {
		this.inActive = inActive;
	}
	/**
	 * @return the total
	 */
	public Integer getTotal() {
		return total;
	}
	/**
	 * @param total the total to set
	 */
	public void setTotal(Integer total) {
		this.total = total;
	}
    
    
}
