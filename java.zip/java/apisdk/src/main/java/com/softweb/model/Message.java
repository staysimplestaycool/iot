package com.softweb.model;

import java.sql.Date;

/**
 * @author shreya.hedau
 *
 */
public class Message {

	private String id;
	private Integer msgType;
	private String companyGuid;
	private String action;
	private String data;
	private Date pubDate;
	private Date deviceRecvDate;
	private Integer deviceProcState;
	private Date firmwareRecvDate;
	private Integer firmwareProcState;
	private Date templateRecvDate;
	private Integer templateProcState;
	private Date telemetryRecvDate;
	private Integer telemetryProcState;
	private Date eventRecvDate;
	private Integer eventProcState;
	private Date jobRecvDate;
	private Integer jobProcState;
	private Integer topic;


	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the msgType
	 */
	public Integer getMsgType() {
		return msgType;
	}

	/**
	 * @param msgType the msgType to set
	 */
	public void setMsgType(Integer msgType) {
		this.msgType = msgType;
	}

	/**
	 * @return the companyGuid
	 */
	public String getCompanyGuid() {
		return companyGuid;
	}

	/**
	 * @param companyGuid the companyGuid to set
	 */
	public void setCompanyGuid(String companyGuid) {
		this.companyGuid = companyGuid;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}

	/**
	 * @return the pubData
	 */
	public Date getPubDate() {
		return pubDate;
	}

	/**
	 * @param pubDate the pubData
	 */
	public void setPubDate(Date pubDate) {
		this.pubDate = pubDate;
	}

	/**
	 * @return the deviceRecvDate
	 */
	public Date getDeviceRecvDate() {
		return deviceRecvDate;
	}

	/**
	 * @param deviceRecvDate the deviceRecvDate to set
	 */
	public void setDeviceRecvDate(Date deviceRecvDate) {
		this.deviceRecvDate = deviceRecvDate;
	}

	/**
	 * @return the deviceProcState
	 */
	public Integer getDeviceProcState() {
		return deviceProcState;
	}

	/**
	 * @param deviceProcState the deviceProcState to set
	 */
	public void setDeviceProcState(Integer deviceProcState) {
		this.deviceProcState = deviceProcState;
	}

	/**
	 * @return the firmwareRecvDate
	 */
	public Date getFirmwareRecvDate() {
		return firmwareRecvDate;
	}

	/**
	 * @param firmwareRecvDate the firmwareRecvDate to set
	 */
	public void setFirmwareRecvDate(Date firmwareRecvDate) {
		this.firmwareRecvDate = firmwareRecvDate;
	}

	/**
	 * @return the firmwareProcState
	 */
	public Integer getFirmwareProcState() {
		return firmwareProcState;
	}

	/**
	 * @param firmwareProcState the firmwareProcState to set
	 */
	public void setFirmwareProcState(Integer firmwareProcState) {
		this.firmwareProcState = firmwareProcState;
	}

	/**
	 * @return the templateRecvDate
	 */
	public Date getTemplateRecvDate() {
		return templateRecvDate;
	}

	/**
	 * @param templateRecvDate the templateRecvDate to set
	 */
	public void setTemplateRecvDate(Date templateRecvDate) {
		this.templateRecvDate = templateRecvDate;
	}

	/**
	 * @return the templateProcState
	 */
	public Integer getTemplateProcState() {
		return templateProcState;
	}

	/**
	 * @param templateProcState the to set
	 */
	public void setTemplateProcState(Integer templateProcState) {
		this.templateProcState = templateProcState;
	}

	/**
	 * @return the telemetryRecvDate
	 */
	public Date getTelemetryRecvDate() {
		return telemetryRecvDate;
	}

	/**
	 * @param telemetryRecvDate the telemetryRecvDate to set
	 */
	public void setTelemetryRecvDate(Date telemetryRecvDate) {
		this.telemetryRecvDate = telemetryRecvDate;
	}

	/**
	 * @return the telemetryProcState
	 */
	public Integer getTelemetryProcState() {
		return telemetryProcState;
	}

	/**
	 * @param telemetryProcState the telemetryProcState to set
	 */
	public void setTelemetryProcState(Integer telemetryProcState) {
		this.telemetryProcState = telemetryProcState;
	}

	/**
	 * @return the eventRecvDate
	 */
	public Date getEventRecvDate() {
		return eventRecvDate;
	}

	/**
	 * @param eventRecvDate the eventRecvDate to set
	 */
	public void setEventRecvDate(Date eventRecvDate) {
		this.eventRecvDate = eventRecvDate;
	}

	/**
	 * @return the eventProcState
	 */
	public Integer getEventProcState() {
		return eventProcState;
	}

	/**
	 * @param eventProcState the eventProcState to set
	 */
	public void setEventProcState(Integer eventProcState) {
		this.eventProcState = eventProcState;
	}

	/**
	 * @return the jobRecvDate
	 */
	public Date getJobRecvDate() {
		return jobRecvDate;
	}

	/**
	 * @param jobRecvDate the jobRecvDate to set
	 */
	public void setJobRecvDate(Date jobRecvDate) {
		this.jobRecvDate = jobRecvDate;
	}

	/**
	 * @return the jobProcState
	 */
	public Integer getJobProcState() {
		return jobProcState;
	}

	/**
	 * @param jobProcState the jobProcState to set
	 */
	public void setJobProcState(Integer jobProcState) {
		this.jobProcState = jobProcState;
	}

	/**
	 * @return the topic
	 */
	public Integer getTopic() {
		return topic;
	}

	/**
	 * @param topic the topic to set
	 */
	public void setTopic(Integer topic) {
		this.topic = topic;
	}

}
