package com.softweb.temp.model;

/**
 * @author shreya.hedau
 *
 */
public class Attributes {

	private String localName;
	private String description;
	private String dataValidation;
	private String dataTypeGuid;
	private Integer sequence;

	/**
	 * 
	 */
	public Attributes() {
		super();
	}

	/**
	 * @param localName
	 * @param description
	 * @param dataValidation
	 * @param dataTypeGuid
	 * @param sequence
	 */
	public Attributes(String localName, String description, String dataValidation, String dataTypeGuid,
			Integer sequence) {
		super();
		this.localName = localName;
		this.description = description;
		this.dataValidation = dataValidation;
		this.dataTypeGuid = dataTypeGuid;
		this.sequence = sequence;
	}

	/**
	 * @return the localName
	 */
	public String getLocalName() {
		return localName;
	}

	/**
	 * @param localName the localName to set
	 */
	public void setLocalName(String localName) {
		this.localName = localName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the dataValidation
	 */
	public String getDataValidation() {
		return dataValidation;
	}

	/**
	 * @param dataValidation the dataValidation to set
	 */
	public void setDataValidation(String dataValidation) {
		this.dataValidation = dataValidation;
	}

	/**
	 * @return the dataTypeGuid
	 */
	public String getDataTypeGuid() {
		return dataTypeGuid;
	}

	/**
	 * @param dataTypeGuid the dataTypeGuid to set
	 */
	public void setDataTypeGuid(String dataTypeGuid) {
		this.dataTypeGuid = dataTypeGuid;
	}

	/**
	 * @return the sequence
	 */
	public Integer getSequence() {
		return sequence;
	}

	/**
	 * @param sequence the sequence to set
	 */
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

}
