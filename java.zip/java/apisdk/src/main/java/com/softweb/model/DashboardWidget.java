package com.softweb.model;

import java.util.List;

import com.softweb.temp.model.DashboardProperties;

/**
 * @author shreya.hedau
 *
 */
public class DashboardWidget {

	private String guid;
	private Dashboard dashboarGuid;
	private Widget widgetGuid;
	private List<DashboardProperties> properties;

	/**
	 * 
	 */
	public DashboardWidget() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the dashboarGuid
	 */
	public Dashboard getDashboarGuid() {
		return dashboarGuid;
	}

	/**
	 * @param dashboarGuid the dashboarGuid to set
	 */
	public void setDashboarGuid(Dashboard dashboarGuid) {
		this.dashboarGuid = dashboarGuid;
	}

	/**
	 * @return the widgetGuid
	 */
	public Widget getWidgetGuid() {
		return widgetGuid;
	}

	/**
	 * @param widgetGuid the widgetGuid to set
	 */
	public void setWidgetGuid(Widget widgetGuid) {
		this.widgetGuid = widgetGuid;
	}

	/**
	 * @return the properties
	 */
	public List<DashboardProperties> getProperties() {
		return properties;
	}

	/**
	 * @param properties the properties to set
	 */
	public void setProperties(List<DashboardProperties> properties) {
		this.properties = properties;
	}

}
