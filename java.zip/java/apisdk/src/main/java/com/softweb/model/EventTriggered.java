package com.softweb.model;

import java.sql.Date;

/**
 * @author shreya.hedau
 *
 */
public class EventTriggered {

	private String guid;
	private String eventGuid;
	private String eventSubscriptionGuid;
	private String refGuid;
	private String dataXml;
	private Date createdDate;

	/**
	 * 
	 */
	public EventTriggered() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the eventGuid
	 */
	public String getEventGuid() {
		return eventGuid;
	}

	/**
	 * @param eventGuid the eventGuid to set
	 */
	public void setEventGuid(String eventGuid) {
		this.eventGuid = eventGuid;
	}

	/**
	 * @return the eventSubscriptionGuid
	 */
	public String getEventSubscriptionGuid() {
		return eventSubscriptionGuid;
	}

	/**
	 * @param eventSubscriptionGuid the eventSubscriptionGuid to set
	 */
	public void setEventSubscriptionGuid(String eventSubscriptionGuid) {
		this.eventSubscriptionGuid = eventSubscriptionGuid;
	}

	/**
	 * @return the refGuid
	 */
	public String getRefGuid() {
		return refGuid;
	}

	/**
	 * @param refGuid the refGuid to set
	 */
	public void setRefGuid(String refGuid) {
		this.refGuid = refGuid;
	}

	/**
	 * @return the dataXml
	 */
	public String getDataXml() {
		return dataXml;
	}

	/**
	 * @param dataXml the dataXml to set
	 */
	public void setDataXml(String dataXml) {
		this.dataXml = dataXml;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
