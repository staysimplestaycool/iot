package com.softweb.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author virendra.mistry
 *
 */
public class SdkUtil {

	
	/**
	 * @param key
	 * @return value
	 */
	public static String getProperty(final String key) {
		Properties prop = new Properties();
		InputStream input = null;
		String val = null;
		try {
										 
			input = new FileInputStream("config.properties");
			// load a properties file
			prop.load(input);

			val = prop.getProperty(key);
			
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return val;
	}
	
}
