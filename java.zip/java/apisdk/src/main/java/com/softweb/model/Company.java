package com.softweb.model;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonAlias;

/**
 * @author shreya.hedau
 *
 */
public class Company {

	private String guid;
	private String name;
	private String cpid;

	@JsonAlias({ "isactive", "isActive" })
	private Boolean isActive;
	private String contactNo;
	private String fax;
	private String address;
	private String city;
	private String stateGuid;
	private String countryGuid;
	private String timezoneGuid;
	private String adminUserGuid;
	@JsonAlias({ "entityguid", "entityGuid" })
	private String entityGuid;
	private String image;

	private String parentGuid;
	private Boolean isDeleted;
	@JsonAlias({ "createddate", "createdDate" })
	private Date createdDate;
	@JsonAlias({ "createdby", "createdBy" })
	private String createdBy;
	@JsonAlias({ "updateddate", "updatedDate" })
	private Date updatedDate;
	@JsonAlias({ "updatedby", "updatedBy" })
	private String updatedBy;

	private String userId;
	private String firstName;
	private String lastName;
	private String fileUrl;

	private Boolean adminUserIsVerified;
	private String entityname;
	private String adminUserName;
	private String adminUserEmail;
	private Integer userCount;
	private Integer deviceCount;
	private String row_num;

	/**
	 * 
	 */
	public Company() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the cpid
	 */
	public String getCpid() {
		return cpid;
	}

	/**
	 * @param cpid the cpid to set
	 */
	public void setCpid(String cpid) {
		this.cpid = cpid;
	}

	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the contactNo
	 */
	public String getContactNo() {
		return contactNo;
	}

	/**
	 * @param contactNo the contactNo to set
	 */
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	/**
	 * @return the fax
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * @param fax the fax to set
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the stateGuid
	 */
	public String getStateGuid() {
		return stateGuid;
	}

	/**
	 * @param stateGuid the stateGuid to set
	 */
	public void setStateGuid(String stateGuid) {
		this.stateGuid = stateGuid;
	}

	/**
	 * @return the countryGuid
	 */
	public String getCountryGuid() {
		return countryGuid;
	}

	/**
	 * @param countryGuid the countryGuid to set
	 */
	public void setCountryGuid(String countryGuid) {
		this.countryGuid = countryGuid;
	}

	/**
	 * @return the timezoneGuid
	 */
	public String getTimezoneGuid() {
		return timezoneGuid;
	}

	/**
	 * @param timezoneGuid the timezoneGuid to set
	 */
	public void setTimezoneGuid(String timezoneGuid) {
		this.timezoneGuid = timezoneGuid;
	}

	/**
	 * @return the adminUserGuid
	 */
	public String getAdminUserGuid() {
		return adminUserGuid;
	}

	/**
	 * @param adminUserGuid the adminUserGuid to set
	 */
	public void setAdminUserGuid(String adminUserGuid) {
		this.adminUserGuid = adminUserGuid;
	}

	/**
	 * @return the entityGuid
	 */
	public String getEntityGuid() {
		return entityGuid;
	}

	/**
	 * @param entityGuid the entityGuid to set
	 */
	public void setEntityGuid(String entityGuid) {
		this.entityGuid = entityGuid;
	}

	/**
	 * @return the image
	 */
	public String getImage() {
		return image;
	}

	/**
	 * @param image the image to set
	 */
	public void setImage(String image) {
		this.image = image;
	}

	/**
	 * @return the parentGuid
	 */
	public String getParentGuid() {
		return parentGuid;
	}

	/**
	 * @param parentGuid the parentGuid to set
	 */
	public void setParentGuid(String parentGuid) {
		this.parentGuid = parentGuid;
	}

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the fileUrl
	 */
	public String getFileUrl() {
		return fileUrl;
	}

	/**
	 * @param fileUrl the fileUrl to set
	 */
	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}

	/**
	 * @return the adminUserIsVerified
	 */
	public Boolean getAdminUserIsVerified() {
		return adminUserIsVerified;
	}

	/**
	 * @param adminUserIsVerified the adminUserIsVerified to set
	 */
	public void setAdminUserIsVerified(Boolean adminUserIsVerified) {
		this.adminUserIsVerified = adminUserIsVerified;
	}

	/**
	 * @return the entityname
	 */
	public String getEntityname() {
		return entityname;
	}

	/**
	 * @param entityname the entityname to set
	 */
	public void setEntityname(String entityname) {
		this.entityname = entityname;
	}

	/**
	 * @return the adminUserName
	 */
	public String getAdminUserName() {
		return adminUserName;
	}

	/**
	 * @param adminUserName the adminUserName to set
	 */
	public void setAdminUserName(String adminUserName) {
		this.adminUserName = adminUserName;
	}

	/**
	 * @return the adminUserEmail
	 */
	public String getAdminUserEmail() {
		return adminUserEmail;
	}

	/**
	 * @param adminUserEmail the adminUserEmail to set
	 */
	public void setAdminUserEmail(String adminUserEmail) {
		this.adminUserEmail = adminUserEmail;
	}

	/**
	 * @return the userCount
	 */
	public Integer getUserCount() {
		return userCount;
	}

	/**
	 * @param userCount the userCount to set
	 */
	public void setUserCount(Integer userCount) {
		this.userCount = userCount;
	}

	/**
	 * @return the deviceCount
	 */
	public Integer getDeviceCount() {
		return deviceCount;
	}

	/**
	 * @param deviceCount the deviceCount to set
	 */
	public void setDeviceCount(Integer deviceCount) {
		this.deviceCount = deviceCount;
	}

	/**
	 * @return the row_num
	 */
	public String getRow_num() {
		return row_num;
	}

	/**
	 * @param row_num the row_num to set
	 */
	public void setRow_num(String row_num) {
		this.row_num = row_num;
	}

}
