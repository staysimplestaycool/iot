package com.softweb.temp.model;

/**
 * @author shreya.hedau
 *
 */
public class EntityCount {

	private Integer total;

	/**
	 * @return the total
	 */
	public Integer getTotal() {
		return total;
	}

	/**
	 * @param total the total to set
	 */
	public void setTotal(Integer total) {
		this.total = total;
	}
	
	
}
