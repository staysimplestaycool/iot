package com.softweb.model;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonAlias;

/**
 * @author shreya.hedau
 *
 */
public class TemplateCommand {

	private String guid;
	private String deviceTemplateGuid;
	private String name;
	private String command;
	private Boolean requiredParam;
	private Boolean requiredAck;
	private Boolean isDeleted;
	private Date createdDate;
	@JsonAlias({ "createdby", "createdBy" })
	private String createdBy;
	private Date updatedDate;

	public TemplateCommand() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the deviceTemplateGuid
	 */
	public String getDeviceTemplateGuid() {
		return deviceTemplateGuid;
	}

	/**
	 * @param deviceTemplateGuid the deviceTemplateGuid to set
	 */
	public void setDeviceTemplateGuid(String deviceTemplateGuid) {
		this.deviceTemplateGuid = deviceTemplateGuid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the command
	 */
	public String getCommand() {
		return command;
	}

	/**
	 * @param command the command to set
	 */
	public void setCommand(String command) {
		this.command = command;
	}

	/**
	 * @return the requiredParam
	 */
	public Boolean getRequiredParam() {
		return requiredParam;
	}

	/**
	 * @param requiredParam the requiredParam to set
	 */
	public void setRequiredParam(Boolean requiredParam) {
		this.requiredParam = requiredParam;
	}

	/**
	 * @return the requiredAck
	 */
	public Boolean getRequiredAck() {
		return requiredAck;
	}

	/**
	 * @param requiredAck the requiredAck to set
	 */
	public void setRequiredAck(Boolean requiredAck) {
		this.requiredAck = requiredAck;
	}

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */

	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

}
