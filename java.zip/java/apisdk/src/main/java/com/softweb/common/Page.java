package com.softweb.common;

public enum Page {

	PAGENUMBER("pageNumber"), PAGESIZE("pageSize"), SEARCHTEXT("searchText"), SORTBY("sortBy"),
	EMAIL("email");

	private String value;

	private Page(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
