package com.softweb.model;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonAlias;

/**
 * @author shreya.hedau
 *
 */
public class TemplateSetting {

	private String guid;
	private String deviceTemplateGuid;
	private String name;
	private String localName;
	private String dataTypeGuid;
	private String defaultValue;
	private String dataValidation;
	private Boolean isDeleted;
	private Date createdDate;
	@JsonAlias({ "createdBy", "createdby" })
	private String createdBy;
	private Date updatedDate;
	private String updatedBy;

	/**
	 * 
	 */
	public TemplateSetting() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the deviceTemplateGuid
	 */
	public String getDeviceTemplateGuid() {
		return deviceTemplateGuid;
	}

	/**
	 * @param deviceTemplateGuid the deviceTemplateGuid to set
	 */
	public void setDeviceTemplateGuid(String deviceTemplateGuid) {
		this.deviceTemplateGuid = deviceTemplateGuid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the localName
	 */
	public String getLocalName() {
		return localName;
	}

	/**
	 * @param localName the localName to set
	 */
	public void setLocalName(String localName) {
		this.localName = localName;
	}

	/**
	 * @return the dataTypeGuid
	 */
	public String getDataTypeGuid() {
		return dataTypeGuid;
	}

	/**
	 * @param dataTypeGuid the dataTypeGuid to set
	 */
	public void setDataTypeGuid(String dataTypeGuid) {
		this.dataTypeGuid = dataTypeGuid;
	}

	/**
	 * @return the defaultValue
	 */
	public String getDefaultValue() {
		return defaultValue;
	}

	/**
	 * @param defaultValue the defaultValue to set
	 */
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	/**
	 * @return the dataValidation
	 */
	public String getDataValidation() {
		return dataValidation;
	}

	/**
	 * @param dataValidation the dataValidation to set
	 */
	public void setDataValidation(String dataValidation) {
		this.dataValidation = dataValidation;
	}

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */

	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
}
