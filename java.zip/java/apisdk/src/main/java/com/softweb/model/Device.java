/**
 * 
 */
package com.softweb.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonAppend;

/**
 * @author mayuri.mojidra
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Device {

	private String guid;
	private String uniqueId;
	private String displayName;
	private Company company;
	private String brokerInfo;
	private DeviceTemplate deviceTemplate;

	@JsonAlias({ "firmwareupgradeGuid", "firmwareUpgrade" })
	private FirmwareUpgrade firmwareUpgrade;
	private Entity entity;
	private Boolean isActive;
	private Product product;
	private Boolean isConnected;
	private Date otaAvailDate;
	private Date lastActivityDate;
	private Byte[] image;
	private String note;
	private Boolean isDeleted;
	private Date createdDate;
	private User createdBy;
	private Date updatedDate;
	private User updatedBy;

	private String lastactivityDate;

	/**
	 * 
	 */
	public Device() {
		super();
	}

	/**
	 * @return the lastactivityDate
	 */
	public String getLastactivityDate() {
		return lastactivityDate;
	}

	/**
	 * @param lastactivityDate the lastactivityDate to set
	 */
	public void setLastactivityDate(String lastactivityDate) {
		this.lastactivityDate = lastactivityDate;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the uniqueId
	 */
	public String getUniqueId() {
		return uniqueId;
	}

	/**
	 * @param uniqueId the uniqueId to set
	 */
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * @return the company
	 */
	public Company getCompany() {
		return company;
	}

	/**
	 * @param company the company to set
	 */
	public void setCompany(Company company) {
		this.company = company;
	}

	/**
	 * @return the brokerInfo
	 */
	public String getBrokerInfo() {
		return brokerInfo;
	}

	/**
	 * @param brokerInfo the brokerInfo to set
	 */
	public void setBrokerInfo(String brokerInfo) {
		this.brokerInfo = brokerInfo;
	}

	/**
	 * @return the deviceTemplate
	 */
	public DeviceTemplate getDeviceTemplate() {
		return deviceTemplate;
	}

	/**
	 * @param deviceTemplate the deviceTemplate to set
	 */
	public void setDeviceTemplate(DeviceTemplate deviceTemplate) {
		this.deviceTemplate = deviceTemplate;
	}

	/**
	 * @return the firmwareUpgrade
	 */
	public FirmwareUpgrade getFirmwareUpgrade() {
		return firmwareUpgrade;
	}

	/**
	 * @param firmwareUpgrade the firmwareUpgrade to set
	 */
	public void setFirmwareUpgrade(FirmwareUpgrade firmwareUpgrade) {
		this.firmwareUpgrade = firmwareUpgrade;
	}

	/**
	 * @return the entity
	 */
	public Entity getEntity() {
		return entity;
	}

	/**
	 * @param entity the entity to set
	 */
	public void setEntity(Entity entity) {
		this.entity = entity;
	}

	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the product
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 * @return the isConnected
	 */
	public Boolean getIsConnected() {
		return isConnected;
	}

	/**
	 * @param isConnected the isConnected to set
	 */
	public void setIsConnected(Boolean isConnected) {
		this.isConnected = isConnected;
	}

	/**
	 * @return the otaAvailDate
	 */
	public Date getOtaAvailDate() {
		return otaAvailDate;
	}

	/**
	 * @param otaAvailDate the otaAvailDate to set
	 */
	public void setOtaAvailDate(Date otaAvailDate) {
		this.otaAvailDate = otaAvailDate;
	}

	/**
	 * @return the lastActivityDate
	 */
	public Date getLastActivityDate() {
		return lastActivityDate;
	}

	/**
	 * @param lastActivityDate the lastActivityDate to set
	 */
	public void setLastActivityDate(Date lastActivityDate) {
		this.lastActivityDate = lastActivityDate;
	}

	/**
	 * @return the image
	 */
	public Byte[] getImage() {
		return image;
	}

	/**
	 * @param image the image to set
	 */
	public void setImage(Byte[] image) {
		this.image = image;
	}

	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}

	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}
}
