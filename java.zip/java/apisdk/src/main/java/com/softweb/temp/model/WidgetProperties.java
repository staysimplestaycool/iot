package com.softweb.temp.model;

/**
 * @author shreya.hedau
 *
 */
public class WidgetProperties {

	private String i;
	private Object background;
	private Object fontColor;
	private Object fontFamily;
	private Object fontSize;
	private String title;

	/**
	 * 
	 */
	public WidgetProperties() {
		super();
	}

	public String getI() {
		return i;
	}

	public void setI(String i) {
		this.i = i;
	}

	/**
	 * @return the background
	 */
	public Object getBackground() {
		return background;
	}

	/**
	 * @param background the background to set
	 */
	public void setBackground(Object background) {
		this.background = background;
	}

	/**
	 * @return the fontColor
	 */
	public Object getFontColor() {
		return fontColor;
	}

	/**
	 * @param fontColor the fontColor to set
	 */
	public void setFontColor(Object fontColor) {
		this.fontColor = fontColor;
	}

	/**
	 * @return the fontFamily
	 */
	public Object getFontFamily() {
		return fontFamily;
	}

	/**
	 * @param fontFamily the fontFamily to set
	 */
	public void setFontFamily(Object fontFamily) {
		this.fontFamily = fontFamily;
	}

	/**
	 * @return the fontSize
	 */
	public Object getFontSize() {
		return fontSize;
	}

	/**
	 * @param fontSize the fontSize to set
	 */
	public void setFontSize(Object fontSize) {
		this.fontSize = fontSize;
	}

	public void setFontSize(String fontSize) {
		this.fontSize = fontSize;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

}
