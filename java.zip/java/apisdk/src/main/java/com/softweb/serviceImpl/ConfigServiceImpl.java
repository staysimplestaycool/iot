package com.softweb.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.softweb.common.HttpUtil;
import com.softweb.model.ApiResponse;
import com.softweb.model.CompanyConfig;
import com.softweb.model.Configuration;
import com.softweb.model.IoTConnect;
import com.softweb.service.ConfigService;
import com.softweb.temp.model.AddEntity;
import com.softweb.temp.model.StompReader;

public class ConfigServiceImpl implements ConfigService {

	private IoTConnect ioTConnect;

	public ConfigServiceImpl() {
		super();
		ioTConnect = IoTConnect.getInstance();
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.ConfigService#getStompReader(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<StompReader> getStompReader(Map<String, String> headers)
			throws IOException {

		return (ApiResponse<StompReader>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.CONFIG_BASE_URL + "/config/stomp-reader", null, headers, StompReader.class, true, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.ConfigService#getConfigByKey(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public Object getConfigByKey(Map<String, String> headers, String key)
			throws IOException {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.ConfigService#getConfigurationList(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Configuration>> getConfigurationList(Map<String, String> headers)
			throws IOException {
		return (ApiResponse<ArrayList<Configuration>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.CONFIG_BASE_URL + "/config", null, headers, Configuration.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.ConfigService#getCompanyConfigList(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<CompanyConfig>> getCompanyConfigList(Map<String, String> headers, String companyId)
			throws IOException {
		return (ApiResponse<ArrayList<CompanyConfig>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.CONFIG_BASE_URL + "/config/company/" + companyId, null, headers, CompanyConfig.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.ConfigService#addCompanyConfiguration(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<AddEntity>> addCompanyConfiguration(Map<String, String> headers, String configKey, String configValue,
			String companyConfigGuid, String configurationGuid, String companyGuid)
			throws IOException {
		
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("configKey", configKey);
		data.put("configValue", configValue);
		data.put("companyConfigGuid", companyConfigGuid);
		data.put("configurationGuid", configurationGuid);
		data.put("companyGuid",companyGuid);
		return (ApiResponse<ArrayList<AddEntity>>) HttpUtil.getHttpUtil().doPost(ioTConnect.CONFIG_BASE_URL + "/config/company", data, headers, AddEntity.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.ConfigService#updateConfigurationData(java.util.Map, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateConfigurationData(Map<String, String> headers, String configurationGuid, String value)
			throws IOException {
		
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("value", value);
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(ioTConnect.CONFIG_BASE_URL + "/config/" + configurationGuid, data, headers, ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.ConfigService#deleteCompanyConfig(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteCompanyConfig(Map<String, String> headers, String companyConfigGuid)
			throws IOException {
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(ioTConnect.CONFIG_BASE_URL + "/config/company/" + companyConfigGuid, null, headers, ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.ConfigService#clearConfigurationCache(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> clearConfigurationCache(Map<String, String> headers, String companyGuid)
			throws IOException {
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("companyGuid", companyGuid);
		
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(ioTConnect.CONFIG_BASE_URL + "/config/cache/", null, headers, ApiResponse.class, false, false);
	}

}
