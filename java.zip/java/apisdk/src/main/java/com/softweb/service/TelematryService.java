package com.softweb.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.softweb.model.ApiResponse;
import com.softweb.model.AttributeValue;
import com.softweb.temp.model.TelemetryResponse;

/**
 * @author shreya.hedau
 *
 */
public interface TelematryService {

	// Get Device Sensors
	ApiResponse<List<AttributeValue>> getDeviceSensors(Map<String, String> headers, String deviceGuid)throws IOException;

	// Get Device Attribute Historical Data By Unqiue Id
	ApiResponse<ArrayList<TelemetryResponse>> getDeviceAttributeHistoricalDataByuniqueId(Map<String, String> headers,String uniqueId, String fromDate, String toDate)
			throws IOException;
	
	// Get Device Attribute Historical Data By Attribute
	ApiResponse<ArrayList<TelemetryResponse>> getDeviceAttributeHistoricalDataByAttribute(Map<String, String> headers,String attributeId,String uniqueId, String fromDate, String toDate)
			throws IOException;
	
	// Get Device Attribute Historical Data By Attribute Guid
	ApiResponse<ArrayList<TelemetryResponse>> getDeviceAttributeHistoricalDataByattributeGuid(Map<String, String> headers,String attributeId,String uniqueId, String fromDate, String toDate)
			throws IOException;

}
