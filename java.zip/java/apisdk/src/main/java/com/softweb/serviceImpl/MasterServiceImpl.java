package com.softweb.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.softweb.common.HttpUtil;
import com.softweb.model.ApiResponse;
import com.softweb.model.Country;
import com.softweb.model.Dashboard;
import com.softweb.model.FAQ;
import com.softweb.model.IoTConnect;
import com.softweb.model.Property;
import com.softweb.model.PropertyFieldType;
import com.softweb.model.PropertyType;
import com.softweb.model.State;
import com.softweb.model.Timezone;
import com.softweb.model.Widget;
import com.softweb.service.MasterService;
import com.softweb.temp.model.DashboardProperties;
import com.softweb.temp.model.WidgetProperties;

/**
 * @author shreya.hedau
 *
 */
public class MasterServiceImpl implements MasterService {

	private IoTConnect ioTConnect;

	/**
	 * 
	 */
	public MasterServiceImpl() {
		super();
		ioTConnect = IoTConnect.getInstance();
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Country>> getCountry()
			throws IOException {
		return (ApiResponse<ArrayList<Country>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.MASTER_BASE_URL + "/master/country", null, null, Country.class, true, true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<State>> getState(String countryGuid)
			throws IOException {
		return (ApiResponse<ArrayList<State>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.MASTER_BASE_URL + "/master/country/" + countryGuid + "/state", null, null, State.class, true,
				true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Timezone>> getTimezone()
			throws IOException {
		return (ApiResponse<ArrayList<Timezone>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.MASTER_BASE_URL + "/master/timezone", null, null, Timezone.class, true, true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<FAQ>> getFAQList(Map<String, String> headers, Integer pageNumber, Integer pageSize,
			String searchText, String sortBy) throws IOException {
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);
		data.put("searchText", searchText);
		data.put("sortBy", sortBy);

		return (ApiResponse<ArrayList<FAQ>>) HttpUtil.getHttpUtil().doGet(ioTConnect.FAQ_BASE_URL + "/faq", data,
				headers, FAQ.class, true, true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<FAQ> getFAQbyGuid(Map<String, String> headers, String faqGuid)
			throws IOException {
		return (ApiResponse<FAQ>) HttpUtil.getHttpUtil().doGet(ioTConnect.FAQ_BASE_URL + "/faq/" + faqGuid, null,
				headers, FAQ.class, true, true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> addFAQ(Map<String, String> headers, String question,
			String answer, Integer sequence) throws IOException {
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("question", question);
		data.put("answer", answer);
		data.put("sequence", sequence);
		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil()
				.doPost(ioTConnect.FAQ_BASE_URL + "/faq", data, headers, Map.class, false, false);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateFAQ(Map<String, String> headers, String faqGuid, String question, String answer,
			Integer sequence) throws IOException {
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("question", question);
		data.put("answer", answer);
		data.put("sequence", sequence);
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(ioTConnect.FAQ_BASE_URL + "/faq/" + faqGuid, data,
				headers, ApiResponse.class, false, false);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteFAQ(Map<String, String> headers, String faqGuid)
			throws IOException {
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(ioTConnect.FAQ_BASE_URL + "/faq/" + faqGuid, null,
				headers, ApiResponse.class, false, false);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateFAQSequence(Map<String, String> headers, Integer newSequence, String faqGuid)
			throws IOException {
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.FAQ_BASE_URL + "/faq/" + faqGuid + "/sequence", data, headers, ApiResponse.class, false,
				false);
	}

	// PROPERTY
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<PropertyType>> getPropertyType(Map<String, String> headers)
			throws IOException {
		return (ApiResponse<ArrayList<PropertyType>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.PROPERTY_BASE_URL + "/property-type", null, headers, PropertyType.class, true, true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<PropertyFieldType>> getPropertyDataType(Map<String, String> headers)
			throws IOException {
		return (ApiResponse<ArrayList<PropertyFieldType>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.PROPERTY_BASE_URL + "/property/field-type", null, headers, PropertyFieldType.class, true,
				true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Property>> getPropertyByPropertyType(Map<String, String> headers,
			String propertyTypeGuid) throws IOException {
		return (ApiResponse<ArrayList<Property>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.PROPERTY_BASE_URL + "/property-type/" + propertyTypeGuid, null, headers, Property.class,
				true, true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Property> getPropertyDetail(Map<String, String> headers, String propertyGuid,
			String propertyTypeGuid) throws IOException {
		return (ApiResponse<Property>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.PROPERTY_BASE_URL + "/property-type/" + propertyTypeGuid + "/property/" + propertyGuid, null,
				headers, Property.class, true, true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> addProperty(Map<String, String> headers, String propertyTypeGuid,
			String name, String fieldType, String options)
			throws IOException {
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("propertyTypeGuid", propertyTypeGuid);
		data.put("name", name);
		data.put("fieldType", fieldType);
		data.put("options", options);
		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil()
				.doPost(ioTConnect.PROPERTY_BASE_URL + "/property", data, headers, Map.class, false, false);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateProperty(Map<String, String> headers, String propertyGuid, String propertyTypeGuid,
			String name, String fieldType, String options)
			throws IOException {
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("propertyTypeGuid", propertyTypeGuid);
		data.put("name", name);
		data.put("fieldType", fieldType);
		data.put("options", options);
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.PROPERTY_BASE_URL + "/property/" + propertyGuid, data, headers, ApiResponse.class, false,
				false);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteProperty(Map<String, String> headers, String propertyGuid, String propertyTypeGuid)
			throws IOException {
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(
				ioTConnect.PROPERTY_BASE_URL + "/property-type/" + propertyTypeGuid + "/property/" + propertyGuid, null,
				headers, ApiResponse.class, false, false);
	}

	// DASHBOARD
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Dashboard>> getDashboardList(Map<String, String> headers)
			throws IOException {
		return (ApiResponse<ArrayList<Dashboard>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.DASHBOARD_BASE_URL + "/dashboard", null, headers, Dashboard.class, true, true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Widget>> getDashboardWidget(Map<String, String> headers)
			throws IOException {
		return (ApiResponse<ArrayList<Widget>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.DASHBOARD_BASE_URL + "/dashboard/widget", null, headers, Widget.class, true, true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Dashboard> getDashboardByGuid(Map<String, String> headers, String dashboardGuid)
			throws IOException {

		return (ApiResponse<Dashboard>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.DASHBOARD_BASE_URL + "/dashboard/" + dashboardGuid, null, headers, Dashboard.class, true,
				true);

	}

	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> addDashboard(Map<String, String> headers, String dashboardName)
			throws IOException {
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", dashboardName);
		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil()
				.doPost(ioTConnect.DASHBOARD_BASE_URL + "/dashboard", data, headers, Map.class, false, false);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> addDashboardWidget(Map<String, String> headers,
			String widgetGuid, String dashboardGuid, DashboardProperties properties, WidgetProperties widgetProperties,
			String dashboardWidgetGuid) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.putPOJO("properties", ioTConnect.objectMapper.writeValueAsString(properties));
		data.putPOJO("widgetProperties", ioTConnect.objectMapper.writeValueAsString(widgetProperties));

		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil().doPost(
				ioTConnect.DASHBOARD_BASE_URL + "/dashboard/widget/" + dashboardGuid + "/" + widgetGuid, data, headers,
				Map.class, true, true);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateDashboardWidget(Map<String, String> headers, String dashboardGuid,
			String dashboardWidgetGuid, String widgetGuid, WidgetProperties widgetProperties)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("dashboardGuid", dashboardGuid);
		data.put("dashboardWidgetGuid", dashboardWidgetGuid);
		data.put("widgetGuid", widgetGuid);
		data.putPOJO("widgetProperties", ioTConnect.objectMapper.writeValueAsString(widgetProperties));

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.DASHBOARD_BASE_URL + "/dashboard/widget/" + widgetGuid, data, headers, ApiResponse.class,
				false, false);

	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateDashboardWidgetPosition(Map<String, String> headers, ArrayNode postData)
			throws IOException {
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.DASHBOARD_BASE_URL + "/dashboard/widget/property-position", postData.toString(), headers,
				ApiResponse.class, false, false);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateDashboard(Map<String, String> headers, String dashboardGuid, Integer isDefault,
			String name) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("isDefault", isDefault);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.DASHBOARD_BASE_URL + "/dashboard/" + dashboardGuid, data, headers, ApiResponse.class, false,
				false);
	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteDashboard(Map<String, String> headers, String dashboardGuid)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(
				ioTConnect.DASHBOARD_BASE_URL + "/dashboard/" + dashboardGuid, null, headers, ApiResponse.class, false,
				false);

	}

	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteDashboardWidget(Map<String, String> headers, String dashboardWidgetGuid)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(
				ioTConnect.DASHBOARD_BASE_URL + "/dashboard/widget/" + dashboardWidgetGuid, null, headers,
				ApiResponse.class, false, false);

	}

}