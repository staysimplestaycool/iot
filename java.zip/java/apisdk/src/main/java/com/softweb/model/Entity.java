package com.softweb.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author shreya.hedau
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Entity {

	private String guid;
	private String name;
	private String parentEntityGuid;
	private String description;
	private String childEntityLable;
	private String companyGuid;
	private String defaultuserGuid;
	private String address;
	private String address2;
	private String city;
	private String stateGuid;
	private String countryGuid;
	private String timezoneGuid;
	private String zipCode;
	private String isDeleted;
	private String createdDate;
	private String createdBy;
	private String updatedDate;
	private String updatedBy;
	

	public Entity() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the parentEntityGuid
	 */
	public String getParentEntityGuid() {
		return parentEntityGuid;
	}

	/**
	 * @param parentEntityGuid the parentEntityGuid to set
	 */
	public void setParentEntityGuid(String parentEntityGuid) {
		this.parentEntityGuid = parentEntityGuid;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the childEntityLable
	 */
	public String getChildEntityLable() {
		return childEntityLable;
	}

	/**
	 * @param childEntityLable the childEntityLable to set
	 */
	public void setChildEntityLable(String childEntityLable) {
		this.childEntityLable = childEntityLable;
	}

	/**
	 * @return the companyGuid
	 */
	public String getCompanyGuid() {
		return companyGuid;
	}

	/**
	 * @param companyGuid the companyGuid to set
	 */
	public void setCompanyGuid(String companyGuid) {
		this.companyGuid = companyGuid;
	}

	/**
	 * @return the defaultuserGuid
	 */
	public String getDefaultuserGuid() {
		return defaultuserGuid;
	}

	/**
	 * @param defaultuserGuid the defaultuserGuid to set
	 */
	public void setDefaultuserGuid(String defaultuserGuid) {
		this.defaultuserGuid = defaultuserGuid;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * @param address2 the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the stateGuid
	 */
	public String getStateGuid() {
		return stateGuid;
	}

	/**
	 * @param stateGuid the stateGuid to set
	 */
	public void setStateGuid(String stateGuid) {
		this.stateGuid = stateGuid;
	}

	/**
	 * @return the countryGuid
	 */
	public String getCountryGuid() {
		return countryGuid;
	}

	/**
	 * @param countryGuid the countryGuid to set
	 */
	public void setCountryGuid(String countryGuid) {
		this.countryGuid = countryGuid;
	}

	/**
	 * @return the timezoneGuid
	 */
	public String getTimezoneGuid() {
		return timezoneGuid;
	}

	/**
	 * @param timezoneGuid the timezoneGuid to set
	 */
	public void setTimezoneGuid(String timezoneGuid) {
		this.timezoneGuid = timezoneGuid;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * @return the isDeleted
	 */
	public String getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedDate
	 */
	public String getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

}
