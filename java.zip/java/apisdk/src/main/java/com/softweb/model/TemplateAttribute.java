package com.softweb.model;

import java.sql.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.softweb.temp.model.Attributes;

/**
 * @author shreya.hedau
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TemplateAttribute {

	private String guid;
	private String parentTemplateAttributeGuid;
	private String deviceTemplateGuid;
	private String localname;
	private String description;
	private String dataTypeGuid;
	private String dataValidation;
	private String unit;
	private Integer sequence; // smallint ??
	private Boolean isDeleted;
	private Date createdDate;
	private User createdBy;
	private Date updatedDate;
	private User updatedBy;
	private Boolean isTemplateAttributeUsed;
	private List<Attributes> attributes;

	public TemplateAttribute() {
		super();
	}

	/**
	 * @return the attributes
	 */
	public List<Attributes> getAttributes() {
		return attributes;
	}

	/**
	 * @param attributes the attributes to set
	 */
	public void setAttributes(List<Attributes> attributes) {
		this.attributes = attributes;
	}

	/**
	 * @return the isTemplateAttributeUsed
	 */
	public Boolean getIsTemplateAttributeUsed() {
		return isTemplateAttributeUsed;
	}

	/**
	 * @param isTemplateAttributeUsed the isTemplateAttributeUsed to set
	 */
	public void setIsTemplateAttributeUsed(Boolean isTemplateAttributeUsed) {
		this.isTemplateAttributeUsed = isTemplateAttributeUsed;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the parentTemplateAttributeGuid
	 */
	public String getParentTemplateAttributeGuid() {
		return parentTemplateAttributeGuid;
	}

	/**
	 * @param parentTemplateAttributeGuid the parentTemplateAttributeGuid
	 */
	public void setParentTemplateAttributeGuid(String parentTemplateAttributeGuid) {
		this.parentTemplateAttributeGuid = parentTemplateAttributeGuid;
	}

	/**
	 * @return the deviceTemplateGuid
	 */
	public String getDeviceTemplateGuid() {
		return deviceTemplateGuid;
	}

	/**
	 * @param deviceTemplateGuid the deviceTemplateGuid to set
	 */
	public void setDeviceTemplateGuid(String deviceTemplateGuid) {
		this.deviceTemplateGuid = deviceTemplateGuid;
	}

	/**
	 * @return the localname
	 */
	public String getLocalname() {
		return localname;
	}

	/**
	 * @param localname the localname to set
	 */
	public void setLocalname(String localname) {
		this.localname = localname;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the dataTypeGuid
	 */
	public String getDataTypeGuid() {
		return dataTypeGuid;
	}

	/**
	 * @param dataTypeGuid the dataTypeGuid to set
	 */
	public void setDataTypeGuid(String dataTypeGuid) {
		this.dataTypeGuid = dataTypeGuid;
	}

	/**
	 * @return the dataValidation
	 */
	public String getDataValidation() {
		return dataValidation;
	}

	/**
	 * @param dataValidation the dataValidation to set
	 */
	public void setDataValidation(String dataValidation) {
		this.dataValidation = dataValidation;
	}

	/**
	 * @return the unit
	 */
	public String getUnit() {
		return unit;
	}

	/**
	 * @param unit the unit to set
	 */
	public void setUnit(String unit) {
		this.unit = unit;
	}

	/**
	 * @return the sequence
	 */
	public Integer getSequence() {
		return sequence;
	}

	/**
	 * @param sequence the sequence to set
	 */
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

}
