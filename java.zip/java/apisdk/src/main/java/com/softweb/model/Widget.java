package com.softweb.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.softweb.temp.model.DashboardProperties;
import com.softweb.temp.model.WidgetProperties;

/**
 * @author shreya.hedau
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Widget {

	private String guid;
	private String name;
	private String type;
	private DashboardProperties properties;
	private WidgetProperties widgetProperty;

	/**
	 * 
	 */
	public Widget() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the properties
	 */
	public DashboardProperties getProperties() {
		return properties;
	}

	/**
	 * @param properties the properties to set
	 */
	public void setProperties(DashboardProperties properties) {
		this.properties = properties;
	}

	/**
	 * @return the widgetProperty
	 */
	public WidgetProperties getWidgetProperty() {
		return widgetProperty;
	}

	/**
	 * @param widgetProperty the widgetProperty to set
	 */
	public void setWidgetProperty(WidgetProperties widgetProperty) {
		this.widgetProperty = widgetProperty;
	}

}
