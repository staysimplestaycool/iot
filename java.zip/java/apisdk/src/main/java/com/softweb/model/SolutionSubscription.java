package com.softweb.model;

import java.sql.Date;

/**
 * @author shreya.hedau
 *
 */
public class SolutionSubscription {

	private String guid;
//	private String solutionGuid;
//	private String companyGuid;
//	private String subscriptionPlanGuid;
//	private Date createdDate;
//	private User createdBy;
//	private Date updatedDate;
//	private User updatedBy;
//	private Date lastSubscriptionDate;

	private String name;
	private String type;
	private String solutionSubscriptionGuid;
	private String solutionGuid;
	private String subscriptionEndDate;
	private String subscription;
	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}
	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the solutionSubscriptionGuid
	 */
	public String getSolutionSubscriptionGuid() {
		return solutionSubscriptionGuid;
	}
	/**
	 * @param solutionSubscriptionGuid the solutionSubscriptionGuid to set
	 */
	public void setSolutionSubscriptionGuid(String solutionSubscriptionGuid) {
		this.solutionSubscriptionGuid = solutionSubscriptionGuid;
	}
	/**
	 * @return the solutionGuid
	 */
	public String getSolutionGuid() {
		return solutionGuid;
	}
	/**
	 * @param solutionGuid the solutionGuid to set
	 */
	public void setSolutionGuid(String solutionGuid) {
		this.solutionGuid = solutionGuid;
	}
	/**
	 * @return the subscriptionEndDate
	 */
	public String getSubscriptionEndDate() {
		return subscriptionEndDate;
	}
	/**
	 * @param subscriptionEndDate the subscriptionEndDate to set
	 */
	public void setSubscriptionEndDate(String subscriptionEndDate) {
		this.subscriptionEndDate = subscriptionEndDate;
	}
	/**
	 * @return the subscription
	 */
	public String getSubscription() {
		return subscription;
	}
	/**
	 * @param subscription the subscription to set
	 */
	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}
	
	

}
