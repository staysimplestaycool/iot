package com.softweb.model;

import java.sql.Date;

/**
 * @author shreya.hedau
 *
 */
public class DeviceOwner {

	private String guid;
	private Device deviceguid;
	private User userguid;
	private String roleguid;
	private Boolean isdeleted;
	private Date createddate;
	private User createdby;
	private Date updateddate;
	private User updatedby;

	
	/**
	 * 
	 */
	public DeviceOwner() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the deviceguid
	 */
	public Device getDeviceguid() {
		return deviceguid;
	}

	/**
	 * @param deviceguid the deviceguid to set
	 */
	public void setDeviceguid(Device deviceguid) {
		this.deviceguid = deviceguid;
	}

	/**
	 * @return the userguid
	 */
	public User getUserguid() {
		return userguid;
	}

	/**
	 * @param userguid the userguid to set
	 */
	public void setUserguid(User userguid) {
		this.userguid = userguid;
	}

	/**
	 * @return the role
	 */
	public String getRoleguid() {
		return roleguid;
	}

	/**
	 * @param roleguid the roleguid to set
	 */
	public void setRoleguid(String roleguid) {
		this.roleguid = roleguid;
	}

	/**
	 * @return the isdeleted
	 */
	public Boolean getIsdeleted() {
		return isdeleted;
	}

	/**
	 * @param isdeleted the isedeleted to set
	 */
	public void setIsdeleted(Boolean isdeleted) {
		this.isdeleted = isdeleted;
	}

	/**
	 * @return the createddate
	 */
	public Date getCreateddate() {
		return createddate;
	}

	/**
	 * @param createddate the createddate to set
	 */
	public void setCreateddate(Date createddate) {
		this.createddate = createddate;
	}

	/**
	 * @return the createdby
	 */
	public User getCreatedby() {
		return createdby;
	}

	/**
	 * @param createdby the createdby to set
	 */
	public void setCreatedby(User createdby) {
		this.createdby = createdby;
	}

	/**
	 * @return the updateddate
	 */
	public Date getUpdateddate() {
		return updateddate;
	}

	/**
	 * @param updateddate the updateddate to set
	 */
	public void setUpdateddate(Date updateddate) {
		this.updateddate = updateddate;
	}

	/**
	 * @return the updatedby
	 */
	public User getUpdatedby() {
		return updatedby;
	}

	/**
	 * @param updatedby the updatedby to set
	 */
	public void setUpdatedby(User updatedby) {
		this.updatedby = updatedby;
	}
}
