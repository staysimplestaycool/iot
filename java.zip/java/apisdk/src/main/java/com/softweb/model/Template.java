 package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class Template {

}
