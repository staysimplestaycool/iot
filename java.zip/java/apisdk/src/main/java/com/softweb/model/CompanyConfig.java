package com.softweb.model;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonAlias;

/**
 * @author shreya.hedau
 *
 */
public class CompanyConfig {

	private String guid;
	private String companyGuid;
	private String configurationGuid;
	@JsonAlias({ "value", "configValue" })
	private String value;
	private Boolean isDeleted;
	private Date createdDate;
	private User createdBy;
	private Date updatedDate;
	private User updatedBy;

	private String configKey;
	private String companyConfigGuid;

	/**
	 * 
	 */
	public CompanyConfig() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the companyGuid
	 */
	public String getCompanyGuid() {
		return companyGuid;
	}

	/**
	 * @param companyGuid the companyGuid to set
	 */
	public void setCompanyGuid(String companyGuid) {
		this.companyGuid = companyGuid;
	}

	/**
	 * @return the configurationGuid
	 */
	public String getConfigurationGuid() {
		return configurationGuid;
	}

	/**
	 * @param configurationGuid the configurationGuid to set
	 */
	public void setConfigurationGuid(String configurationGuid) {
		this.configurationGuid = configurationGuid;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the configKey
	 */
	public String getConfigKey() {
		return configKey;
	}

	/**
	 * @param configKey the configKey to set
	 */
	public void setConfigKey(String configKey) {
		this.configKey = configKey;
	}

	/**
	 * @return the companyConfigGuid
	 */
	public String getCompanyConfigGuid() {
		return companyConfigGuid;
	}

	/**
	 * @param companyConfigGuid the companyConfigGuid to set
	 */
	public void setCompanyConfigGuid(String companyConfigGuid) {
		this.companyConfigGuid = companyConfigGuid;
	}

}
