package com.softweb.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.softweb.model.ApiResponse;
import com.softweb.model.Company;
import com.softweb.model.Solution;
import com.softweb.model.SolutionSubscription;
import com.softweb.model.User;
import com.softweb.temp.model.AddEntity;
import com.softweb.temp.model.ApiCountList;
import com.softweb.temp.model.CompanyStatisticData;

/**
 * @author shreya.hedau
 *
 */
public interface CompanyService {
	
	// Get company statistic like apiCount,userCount and entityCount
	ApiResponse<CompanyStatisticData> companyStatistic(Map<String, String> headers,Integer apiCount, Integer userCount, String entityCount)
			throws IOException;
	
	// Get api count list using daysCount
	ApiResponse<ArrayList<ApiCountList>> apiCount(Map<String, String> headers, Integer daysCount) throws IOException;
	
	// Get company by companyGuid
	ApiResponse<ArrayList<Company>> companyDetail(Map<String, String> headers, String companyGuid) throws IOException;
	
	// Update company status by companyGuid
	ApiResponse<Void> updateCompanyStatus(Map<String, String> headers, String companyGuid, Boolean status) throws IOException;
	
	// Get company list
	ApiResponse<ArrayList<Company>> getCompanyList(Map<String, String> headers, Integer pageNumber, Integer pageSize, String searchText, String sortBy) throws IOException;
	
	// Get users by companyGuid
	ApiResponse<ArrayList<User>> getCompanyUserList(Map<String, String> headers, String companyGuid, Integer pageNumber, Integer pageSize, String searchText, String sortBy) throws IOException;
	
	// Add new company
	ApiResponse<ArrayList<Map<String, String>>> addCompany(Map<String, String> headers, String name, String cpid, String address, String city, String stateGuid, String countryGuid, String timezoneGuid, String contactNo, String firstName, String lastName, String userId, String fax) throws IOException;
	
	// Update Company
	ApiResponse<Void> updateCompany(Map<String, String> headers, String companyGuid, String name, String address, String city, String stateGuid, String countryGuid, String timezoneGuid, String contactNo, String fax) throws IOException;
	
	// Delete Company
	ApiResponse<Void> deleteCompany(Map<String, String> headers, String companyGuid) throws IOException;
	
	// Update Company Image
	ApiResponse<ArrayList<Map<String, String>>> updateCompanyImage(Map<String, String> headers, String companyGuid, File file) throws IOException;
	
	// Solution
	ApiResponse<ArrayList<SolutionSubscription>> getSubscribedSolutionsByLoginCompany(Map<String, String> headers) throws IOException;
	
	// Get solution accessKey
	ApiResponse<String> getUniqueSolutionKey(Map<String, String> headers) throws IOException;
	
	// Solution subscription list by companyGuid
	ApiResponse<ArrayList<SolutionSubscription>> solutionSubscriptionListByCompanyGuid(Map<String, String> headers, String companyGuid) throws IOException;
	
	// Get solution details by solutionGuid
	ApiResponse<ArrayList<Solution>> getSolutionDetails(Map<String, String> headers, String solutionGuid, Boolean status) throws IOException;
	
	// Get solution list
	ApiResponse<ArrayList<Solution>> getSolutionList(Map<String, String> headers, Integer pageNumber, Integer pageSize, String searchText, String sortBy) throws IOException;
	
	// Add solution subscription 
	ApiResponse<Void> addSolutionSubscription(Map<String, String> headers, String companyGuid, String solutionGuid) throws IOException;
	
	// Add solution
	ApiResponse<ArrayList<AddEntity>> addSolution(Map<String, String> headers, String name, String type, String ipRange, String URL, String accessKey, Boolean isSync, String syncType, String hostName, String port, String vhost, String securityType, String userName, String topic, String modules, String password) throws IOException;
	
	// Update Solution
	ApiResponse<Void> updateSolution(Map<String, String> headers,String solutionGuid,String name, String type, String ipRange, String URL,
			String accessKey, Boolean isSync, String syncType, String hostName, String port, String vhost,
			String securityType, String userName, String topic, String modules, String password)  throws IOException;
	
	// Update Solution Status
	ApiResponse<Void> updateSolutionStatus(Map<String, String> headers, String solutionGuid, Boolean isActive) throws IOException;
	
	// Update Solution Image
	ApiResponse<ArrayList<Map<String,String>>> updateSolutionImage(Map<String, String> headers, String solutionGuid, File file) throws IOException;
	
	// Delete Solution
	ApiResponse<Void> deleteSolution(Map<String, String> headers, String solutionGuid) throws IOException;

}
