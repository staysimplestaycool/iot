package com.softweb.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.softweb.model.ApiResponse;
import com.softweb.model.CompanyConfig;
import com.softweb.model.Configuration;
import com.softweb.temp.model.AddEntity;
import com.softweb.temp.model.StompReader;

/**
 * @author shreya.hedau
 *
 */
public interface ConfigService {	
	
	// Get stomp reader information
	ApiResponse<StompReader> getStompReader(Map<String, String> headers)throws IOException;

	// Get Configuration by Key
	Object getConfigByKey(Map<String, String> headers, String key)throws IOException;
	
	// Get Configuration List
	ApiResponse<ArrayList<Configuration>> getConfigurationList(Map<String, String> headers)throws IOException;
	
	// Get Company Configuration List
	ApiResponse<ArrayList<CompanyConfig>> getCompanyConfigList(Map<String, String> headers, String companyGuid)throws IOException;
	
	// Add Company Configuration
	ApiResponse<ArrayList<AddEntity>> addCompanyConfiguration(Map<String, String> headers, String configKey, String configValue, String companyConfigGuid, String configurationGuid, String companyGuid)throws IOException;
	
	// Update Configuration Data
	ApiResponse<Void> updateConfigurationData(Map<String, String> headers, String configurationGuid, String value)throws IOException;
	
	// Delete Company Configuration
	ApiResponse<Void> deleteCompanyConfig(Map<String, String> headers, String companyConfigGuid)throws IOException;
	
	// Clear cache Configuration
	ApiResponse<Void> clearConfigurationCache(Map<String, String> headers, String companyGuid)throws IOException; 

}
