/**
 * 
 */
package com.softweb.serviceImpl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.softweb.common.Page;
import com.softweb.common.HttpUtil;
import com.softweb.model.ApiResponse;
import com.softweb.model.Company;
import com.softweb.model.IoTConnect;
import com.softweb.model.Solution;
import com.softweb.model.SolutionSubscription;
import com.softweb.model.User;
import com.softweb.service.CompanyService;
import com.softweb.temp.model.AddEntity;
import com.softweb.temp.model.ApiCountList;
import com.softweb.temp.model.CompanyStatisticData;

/**
 * @author shreya.hedau
 *
 */
public class CompanyServiceImpl implements CompanyService {

	private IoTConnect ioTConnect;

	/**
	 * 
	 */
	public CompanyServiceImpl() {
		super();
		ioTConnect = IoTConnect.getInstance();
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#companyStatistic(java.util.Map, java.lang.Integer, java.lang.Integer, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<CompanyStatisticData> companyStatistic(Map<String, String> headers, Integer apiCount,
			Integer userCount, String entityCount)
			throws IOException {
		return (ApiResponse<CompanyStatisticData>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.COMPANY_BASE_URL + "/company/statistic", null, headers, CompanyStatisticData.class, true,
				false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#apiCount(java.util.Map, java.lang.Integer)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<ApiCountList>> apiCount(Map<String, String> headers, Integer daysCount)
			throws IOException {
		return (ApiResponse<ArrayList<ApiCountList>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.COMPANY_BASE_URL + "/company/api-count-list/" + daysCount, null, headers, ApiCountList.class,
				true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#companyDetail(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Company>> companyDetail(Map<String, String> headers, String companyGuid)
			throws IOException {
		return (ApiResponse<ArrayList<Company>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.COMPANY_BASE_URL + "/company/" + companyGuid, null, headers, Company.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#updateCompanyStatus(java.util.Map, java.lang.String, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateCompanyStatus(Map<String, String> headers, String companyGuid, Boolean status)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("isActive", status);
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.COMPANY_BASE_URL + "/company/" + companyGuid + "/status", data, headers, ApiResponse.class,
				false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#getCompanyList(java.util.Map, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Company>> getCompanyList(Map<String, String> headers, Integer pageNumber,
			Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(Page.PAGENUMBER.getValue(), pageNumber);
		data.put(Page.PAGESIZE.getValue(), pageSize);
		data.put(Page.SEARCHTEXT.getValue(), searchText);
		data.put(Page.SORTBY.getValue(), sortBy);

		return (ApiResponse<ArrayList<Company>>) HttpUtil.getHttpUtil().doGet(ioTConnect.COMPANY_BASE_URL + "/company/",
				null, headers, Company.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#getCompanyUserList(java.util.Map, java.lang.String, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<User>> getCompanyUserList(Map<String, String> headers, String companyGuid,
			Integer pageNumber, Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(Page.PAGENUMBER.getValue(), pageNumber);
		data.put(Page.PAGESIZE.getValue(), pageSize);
		data.put(Page.SEARCHTEXT.getValue(), searchText);
		data.put(Page.SORTBY.getValue(), sortBy);
		return (ApiResponse<ArrayList<User>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.COMPANY_BASE_URL + "/company/" + companyGuid + "/user", data, headers, User.class, true,
				true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#addCompany(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> addCompany(Map<String, String> headers, String name, String cpid,
			String address, String city, String stateGuid, String countryGuid, String timezoneGuid, String contactNo,
			String firstName, String lastName, String userId, String fax)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("cpid", cpid);
		data.put("address", address);
		data.put("city", city);
		data.put("stateGuid", stateGuid);
		data.put("countryGuid", countryGuid);
		data.put("timezoneGuid", timezoneGuid);
		data.put("contactNo", contactNo);
		data.put("firstName", firstName);
		data.put("lastName", lastName);
		data.put("userId", userId);
		data.put("fax", fax);

		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil()
				.doPost(ioTConnect.COMPANY_BASE_URL + "/company", data, headers, Map.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#updateCompany(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateCompany(Map<String, String> headers, String companyGuid, String name, String address,
			String city, String stateGuid, String countryGuid, String timezoneGuid, String contactNo, String fax)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("address", address);
		data.put("city", city);
		data.put("stateGuid", stateGuid);
		data.put("countryGuid", countryGuid);
		data.put("timezoneGuid", timezoneGuid);
		data.put("contactNo", contactNo);
		data.put("fax", fax);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(ioTConnect.COMPANY_BASE_URL + "/company/" + companyGuid,
				data, headers, ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#deleteCompany(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteCompany(Map<String, String> headers, String companyGuid)
			throws IOException {
		 return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(ioTConnect.COMPANY_BASE_URL + "/company/" + companyGuid, null,
					headers, ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#updateCompanyImage(java.util.Map, java.lang.String, java.io.File)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> updateCompanyImage(Map<String, String> headers,
			String companyGuid, File file) throws IOException {
		
		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil().doPutFile(
				ioTConnect.COMPANY_BASE_URL + "/company/" + companyGuid + "/image", null, headers, Map.class, true, true,
				file, "companyLogoFile");
	}

	// Solution
	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#getSubscribedSolutionsByLoginCompany(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<SolutionSubscription>> getSubscribedSolutionsByLoginCompany(Map<String, String> headers)  throws IOException {
				
		return (ApiResponse<ArrayList<SolutionSubscription>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.SOLUTION_BASE_URL + "/solution/subscribed", null, headers, SolutionSubscription.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#getUniqueSolutionKey(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<String> getUniqueSolutionKey(Map<String, String> headers)  throws IOException {
		return (ApiResponse<String>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.SOLUTION_BASE_URL + "/solution/accessKey", null, headers, ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#solutionSubscriptionListByCompanyGuid(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<SolutionSubscription>> solutionSubscriptionListByCompanyGuid(Map<String, String> headers, String companyGuid)  throws IOException {
		return (ApiResponse<ArrayList<SolutionSubscription>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.SOLUTION_BASE_URL + "/company/"+ companyGuid +"/subscription", null, headers, SolutionSubscription.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#getSolutionDetails(java.util.Map, java.lang.String, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Solution>> getSolutionDetails(Map<String, String> headers, String solutionGuid, Boolean status)  throws IOException {
		return (ApiResponse<ArrayList<Solution>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.SOLUTION_BASE_URL + "/solution/" + solutionGuid, null, headers, Solution.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#getSolutionList(java.util.Map, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Solution>> getSolutionList(Map<String, String> headers, Integer pageNumber, Integer pageSize,
			String searchText, String sortBy)  throws IOException {
		
		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(Page.PAGENUMBER.getValue(), pageNumber);
		data.put(Page.PAGESIZE.getValue(), pageSize);
		data.put(Page.SEARCHTEXT.getValue(), searchText);
		data.put(Page.SORTBY.getValue(), sortBy);
		
		return (ApiResponse<ArrayList<Solution>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.SOLUTION_BASE_URL + "/solution", data, headers, Solution.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#addSolutionSubscription(java.util.Map, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> addSolutionSubscription(Map<String, String> headers, String companyGuid, String solutionGuid)  throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("companyGuid", companyGuid);
		data.put("solutionGuid", solutionGuid);
		
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPost(ioTConnect.SOLUTION_BASE_URL + "/solution/subscription", data, headers, ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#addSolution(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<AddEntity>> addSolution(Map<String, String> headers, String name, String type, String ipRange, String URL,
			String accessKey, Boolean isSync, String syncType, String hostName, String port, String vhost,
			String securityType, String userName, String topic, String modules, String password)  throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("type", type);
		data.put("ipRange", ipRange);
		data.put("URL", URL);
		data.put("accessKey", accessKey);
		data.put("isSync", isSync);
		data.put("syncType", syncType);
		data.put("hostName", hostName);
		data.put("port", port);
		data.put("vhost", vhost);
		data.put("securityType", securityType);
		data.put("userName", userName);
		data.put("topic", topic);
		data.put("modules", modules);
		data.put("password", password);
		
		return (ApiResponse<ArrayList<AddEntity>>) HttpUtil.getHttpUtil().doPost(ioTConnect.SOLUTION_BASE_URL + "/solution", data, headers, AddEntity.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#updateSolution(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateSolution(Map<String, String> headers, String solutionGuid,String name, String type, String ipRange, String URL,
			String accessKey, Boolean isSync, String syncType, String hostName, String port, String vhost,
			String securityType, String userName, String topic, String modules, String password)   throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("type", type);
		data.put("ipRange", ipRange);
		data.put("URL", URL);
		data.put("accessKey", accessKey);
		data.put("isSync", isSync);
		data.put("syncType", syncType);
		data.put("hostName", hostName);
		data.put("port", port);
		data.put("vhost", vhost);
		data.put("securityType", securityType);
		data.put("userName", userName);
		data.put("topic", topic);
		data.put("modules", modules);
		data.put("password", password);
		
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(ioTConnect.SOLUTION_BASE_URL + "/solution/" + solutionGuid, data, headers, ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#updateSolutionStatus(java.util.Map, java.lang.String, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateSolutionStatus(Map<String, String> headers, String solutionGuid, Boolean isActive)  throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("isActive", isActive);
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.SOLUTION_BASE_URL + "/solution/" + solutionGuid + "/status", data, headers, ApiResponse.class,
				false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#updateSolutionImage(java.util.Map, java.lang.String, java.io.File)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String,String>>> updateSolutionImage(Map<String, String> headers, String solutionGuid, File file)  throws IOException {
		return (ApiResponse<ArrayList<Map<String,String>>>) HttpUtil.getHttpUtil().doPutFile(
				ioTConnect.SOLUTION_BASE_URL + "/solution/" + solutionGuid + "/image", null, headers, Map.class,
				true, true,file, "solutionImageFile");
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.CompanyService#deleteSolution(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteSolution(Map<String, String> headers, String solutionGuid)  throws IOException {

		 return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(ioTConnect.SOLUTION_BASE_URL + "/solution/" + solutionGuid, null,
					headers, ApiResponse.class, false, false);
	}

}
