package com.softweb.service;

import java.io.IOException;
import java.util.Map;

import com.softweb.model.ApiResponse;
import com.softweb.model.Tokens;

/**
 * @author shreya.hedau
 *
 */
public interface AuthService {

	// get basic token
	String getToken() throws IOException;
	
	// user login
	ApiResponse<Tokens> signIn(Map<String,String> headers, String username,String password) throws IOException;
	
	// Get new bearer token from refreshtoken
	ApiResponse<Tokens> getRefreshToken(Map<String,String> headers,String refreshToken) throws IOException;
}
