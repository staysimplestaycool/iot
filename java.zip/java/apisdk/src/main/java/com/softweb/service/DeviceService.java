package com.softweb.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.softweb.model.ApiResponse;
import com.softweb.model.Device;
import com.softweb.model.ImportBatch;
import com.softweb.model.Property;
import com.softweb.temp.model.AddEntity;

/**
 * @author shreya.hedau
 *
 */
public interface DeviceService {

	// Get User List
	ApiResponse<List<Device>> getUserDeviceList(Map<String, String> headers, Integer pageNumber, Integer pageSize, String searchText) throws IOException;

	// Get Device Count
	ApiResponse<List<Map<String,Integer>>> getDeviceCount(Map<String, String> headers, String companyguid, String status) throws IOException;
 
	// Get Device Information
	ApiResponse<List<Device>> getDeviceInfo(Map<String, String> headers, String uniqueId) throws IOException;

	// Get Device Info by Device Template
	ApiResponse<List<Device>> getDeviceInfoByDeviceTemplate(Map<String, String> headers, String deviceTemplateGuid) throws IOException;

	// Get Device List
	ApiResponse<List<Device>> getDeviceList(Map<String, String> headers, Integer pageNumber, Integer pageSize, String searchText,String sortBy) throws IOException;

	// Get Company Device List
	ApiResponse<List<Device>> getCompanyDeviceList(Map<String, String> headers, String companyGuid, Integer pageNumber, Integer pageSize,String searchText, String sortBy) throws IOException;

	// Get Device Lookup
	ApiResponse<List<Device>> getDeviceLookup(Map<String, String> headers, String deviceTemplateGuid) throws IOException;
	
	// Get Broker Connection Status
	ApiResponse<List<Device>> getBrokerConnectionStatus(Map<String, String> headers, String deviceGuid, String uniqueId) throws IOException;
	
	// Get Acquire Device Count
	ApiResponse<List<Map<String,String>>> getAcquireDeviceCount(Map<String, String> headers,Integer count) throws IOException;

	// Get Acquire Device List
	ApiResponse<List<Device>> getAcquireDeviceList(Map<String, String> headers, Integer count, Boolean isConnected, Boolean isAcquired,Boolean isActive, Boolean isOtaupdate) throws IOException;
	
	// Get Device List By Entity Guid
	ApiResponse<List<Device>> getDeviceListByEntityGuid(Map<String, String> headers, String entityGuid, Integer pageNumber, Integer pageSize,String searchText, String sortBy) throws IOException;

	// Get Device List by Template Guid
	ApiResponse<List<Device>> getDeviceListByTemplateGuid(Map<String, String> headers, String templateGuid, Integer pageNumber,Integer pageSize, String searchText, String sortBy) throws IOException;
	
	
	// Update Device
	ApiResponse<Void> updateDevice(Map<String, String> headers, String deviceGuid, String displayName, String note,ArrayList<Property> properties) throws IOException;

	// Update Device Last Activity
	ApiResponse<Void> updateDeviceLastActivity(Map<String, String> headers, String deviceGuid, String lastActivityDate) throws IOException;

	// Delete Device
	ApiResponse<Void> deleteDevice(Map<String, String> headers, String deviceGuid) throws IOException;

	// Update Device Status
	ApiResponse<Void> updateDeviceStatus(Map<String, String> headers, String deviceGuid, Boolean isActive) throws IOException;
	
	// List of Import Batch
	ApiResponse<List<ImportBatch>> listOfImportBatch(Map<String, String> headers, Integer pageNumber, Integer pageSize, String sortBy) throws IOException;

	// Get Pending Device With property Info
	ApiResponse<List<ImportBatch>> getPendingDeviceWithPropertyInfo(Map<String, String> headers, String importBatchGuid, Integer pageNumber,Integer pageSize, String sortBy, String searchText) throws IOException;

	// Import Device Information
	ApiResponse<Void> importDeviceInformation(Map<String, String> headers, String entityGuid, File file) throws IOException;

	// Create Single Device
	ApiResponse<ArrayList<AddEntity>> createSingleDevice(Map<String, String> headers, String displayName, String uniqueId,
			String firmwareUpgradeGuid, String entityGuid, String deviceTemplateGuid, String note,ArrayList<Property> properties) throws IOException;

	// Update Device Properties
	ApiResponse<Void> updateDeviceProperties(Map<String, String> headers, String deviceGuid, ArrayList<Property> properties) throws IOException;

	// Delete Device Property
	ApiResponse<Void> deleteDeviceProperty(Map<String, String> headers, String deviceGuid, String devicePropertyGuid) throws IOException;

	// Update Device Image
	ApiResponse<ArrayList<Map<String, String>>> updateDeviceImage(Map<String, String> headers, String deviceGuid, File file) throws IOException;

	// Device Acquire
	ApiResponse<Void> deviceAcquire(Map<String, String> headers, String uniqueId) throws IOException;

	// Device Release
	ApiResponse<Void> deviceRelease(Map<String, String> headers, String uniqueId) throws IOException;

}
