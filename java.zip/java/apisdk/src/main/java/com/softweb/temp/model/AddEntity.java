package com.softweb.temp.model;

import com.fasterxml.jackson.annotation.JsonAlias;

/**
 * @author shreya.hedau
 *
 */
public class AddEntity {
	
	@JsonAlias({"newid","newId"})
	private String newId;

	/**
	 * @return the newId
	 */
	public String getNewId() {
		return newId;
	}

	/**
	 * @param newId the newId to set
	 */
	public void setNewId(String newId) {
		this.newId = newId;
	}
	
	

}
