/**
 * 
 */
package com.softweb.model;

import java.util.Date;

/**
 * @author mayuri.mojidra
 *
 */
public class SettingValue {
	
	private String guid;
	private TemplateSetting templateSetting;
	private String device; //device
	private Company company;
	private Date createdDate;
	private String settingValue;
	private Date sdkUpdatedDate;
	private Date gatewayUpdatedDate;
	private Date deviceUpdatedDate;
	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}
	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}
	/**
	 * @return the templateSetting
	 */
	public TemplateSetting getTemplateSetting() {
		return templateSetting;
	}
	/**
	 * @param templateSetting the templateSetting to set
	 */
	public void setTemplateSetting(TemplateSetting templateSetting) {
		this.templateSetting = templateSetting;
	}
	/**
	 * @return the device
	 */
	public String getDevice() {
		return device;
	}
	/**
	 * @param device the device to set
	 */
	public void setDevice(String device) {
		this.device = device;
	}
	/**
	 * @return the company
	 */
	public Company getCompany() {
		return company;
	}
	/**
	 * @param company the company to set
	 */
	public void setCompany(Company company) {
		this.company = company;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the settingValue
	 */
	public String getSettingValue() {
		return settingValue;
	}
	/**
	 * @param settingValue the settingValue to set
	 */
	public void setSettingValue(String settingValue) {
		this.settingValue = settingValue;
	}
	/**
	 * @return the sdkUpdatedDate
	 */
	public Date getSdkUpdatedDate() {
		return sdkUpdatedDate;
	}
	/**
	 * @param sdkUpdatedDate the sdkUpdatedDate to set
	 */
	public void setSdkUpdatedDate(Date sdkUpdatedDate) {
		this.sdkUpdatedDate = sdkUpdatedDate;
	}
	/**
	 * @return the gatewayUpdatedDate
	 */
	public Date getGatewayUpdatedDate() {
		return gatewayUpdatedDate;
	}
	/**
	 * @param gatewayUpdatedDate the gatewayUpdatedDate to set
	 */
	public void setGatewayUpdatedDate(Date gatewayUpdatedDate) {
		this.gatewayUpdatedDate = gatewayUpdatedDate;
	}
	/**
	 * @return the deviceUpdatedDate
	 */
	public Date getDeviceUpdatedDate() {
		return deviceUpdatedDate;
	}
	/**
	 * @param deviceUpdatedDate the deviceUpdatedDate to set
	 */
	public void setDeviceUpdatedDate(Date deviceUpdatedDate) {
		this.deviceUpdatedDate = deviceUpdatedDate;
	}
	
	


}
