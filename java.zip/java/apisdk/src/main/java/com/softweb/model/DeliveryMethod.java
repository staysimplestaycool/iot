package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class DeliveryMethod {

	private String guid;
	private String name;
	private Boolean isPrivate;
	private Boolean audienceRequired;
	private Integer bitValue;
	private Boolean isActive;

	/**
	 * 
	 */
	public DeliveryMethod() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the isPrivate
	 */
	public Boolean getIsPrivate() {
		return isPrivate;
	}

	/**
	 * @param isPrivate the isPrivate to set
	 */
	public void setIsPrivate(Boolean isPrivate) {
		this.isPrivate = isPrivate;
	}

	/**
	 * @return the audienceRequired
	 */
	public Boolean getAudienceRequired() {
		return audienceRequired;
	}

	/**
	 * @param audienceRequired the audienceRequired to set
	 */
	public void setAudienceRequired(Boolean audienceRequired) {
		this.audienceRequired = audienceRequired;
	}

	/**
	 * @return the bitValue
	 */
	public Integer getBitValue() {
		return bitValue;
	}

	/**
	 * @param bitValue the bitValue to set
	 */
	public void setBitValue(Integer bitValue) {
		this.bitValue = bitValue;
	}

	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

}
