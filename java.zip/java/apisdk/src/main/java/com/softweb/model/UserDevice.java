package com.softweb.model;

public class UserDevice {

}
