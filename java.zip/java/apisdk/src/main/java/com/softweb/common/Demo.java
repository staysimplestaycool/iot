
package com.softweb.common;

import java.util.HashMap;
import java.util.Map;

import com.softweb.model.ApiResponse;
import com.softweb.model.Tokens;
import com.softweb.service.AuthService;
import com.softweb.serviceImpl.AuthServiceImpl;

public class Demo {

	public static void main(String args[]) throws Exception {

		AuthService auth = new AuthServiceImpl();
		String basicToken = auth.getToken();
		System.out.println("basicToken:" + basicToken);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", "Basic " + basicToken);
		String username = "boschadmin@mailinator.com";
//		String username = "robotdesoza+3@gmail.com";
		String password = "1234";
		String solutionKey = "QkExQ0EzQzYtNUU5My00NEU1LUIwRDAtMUFGQTkxMkM5NjY5LWFjY2Vzc0tFWS1senJyN2txNXNy";
		headers.put("solution-key", solutionKey);
		ApiResponse<Tokens> authApiResponse = auth.signIn(headers, username, password);
		headers = new HashMap<String, String>();
		headers.put("Authorization", "Bearer " + authApiResponse.getData().getAccessToken());
		System.out.println("Bearer " + authApiResponse.getData().getAccessToken());
		
	}
}
