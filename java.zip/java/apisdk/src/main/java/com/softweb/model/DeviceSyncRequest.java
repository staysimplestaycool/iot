package com.softweb.model;

import java.sql.Date;

/**
 * @author shreya.hedau
 *
 */
public class DeviceSyncRequest {

	private String guid;
	private FlexcoUser syncBy;
	private Date syncDate;
	private String importBatchGuid;
	private Boolean isPending;
	private Boolean isSuccess;

	/**
	 * 
	 */
	public DeviceSyncRequest() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the syncBy
	 */
	public FlexcoUser getSyncBy() {
		return syncBy;
	}

	/**
	 * @param syncBy the syncBy to set
	 */
	public void setSyncBy(FlexcoUser syncBy) {
		this.syncBy = syncBy;
	}

	/**
	 * @return the syncDate
	 */
	public Date getSyncDate() {
		return syncDate;
	}

	/**
	 * @param syncDate the syncDate to set
	 */
	public void setSyncDate(Date syncDate) {
		this.syncDate = syncDate;
	}

	/**
	 * @return the importBatchGuid
	 */
	public String getImportBatchGuid() {
		return importBatchGuid;
	}

	/**
	 * @param importBatchGuid the importBatchGuid to set
	 */
	public void setImportBatchGuid(String importBatchGuid) {
		this.importBatchGuid = importBatchGuid;
	}

	/**
	 * @return the isPending
	 */
	public Boolean getIsPending() {
		return isPending;
	}

	/**
	 * @param isPending the isPending to set
	 */
	public void setIsPending(Boolean isPending) {
		this.isPending = isPending;
	}

	/**
	 * @return the isSuccess
	 */
	public Boolean getIsSuccess() {
		return isSuccess;
	}

	/**
	 * @param isSuccess the isSuccess to set
	 */
	public void setIsSuccess(Boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

}
