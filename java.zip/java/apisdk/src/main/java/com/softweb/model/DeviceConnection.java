package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class DeviceConnection {

	private String flexcoDeviceGuid;
	private UserDevice userMobileDeviceguid;
	private String connectedDate;

	/**
	 * 
	 */
	public DeviceConnection() {
		super();
	}

	/**
	 * @return the flexcoDeviceGuid
	 */
	public String getFlexcoDeviceGuid() {
		return flexcoDeviceGuid;
	}

	/**
	 * @param flexcoDeviceGuid the flexcoDeviceGuid to set
	 */
	public void setFlexcoDeviceGuid(String flexcoDeviceGuid) {
		this.flexcoDeviceGuid = flexcoDeviceGuid;
	}

	/**
	 * @return the userMobileDeviceguid
	 */
	public UserDevice getUserMobileDeviceguid() {
		return userMobileDeviceguid;
	}

	/**
	 * @param userMobileDeviceguid the userMobileDeviceguid to set
	 */
	public void setUserMobileDeviceguid(UserDevice userMobileDeviceguid) {
		this.userMobileDeviceguid = userMobileDeviceguid;
	}

	/**
	 * @return the connectedDate
	 */
	public String getConnectedDate() {
		return connectedDate;
	}

	/**
	 * @param connectedDate the connectedDate to set
	 */
	public void setConnectedDate(String connectedDate) {
		this.connectedDate = connectedDate;
	}

}
