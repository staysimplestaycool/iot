package com.softweb.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author shreya.hedau
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Tokens {

	private String tokenType;
	private String accessToken;
	private String refreshToken;
	private String expiresIn;
	
	
	/**
	 * 
	 */
	public Tokens() {
		super();
	}

	/**
	 * @return the tokenType
	 */
	@JsonProperty("token_type")
	public String getTokenType() {
		return tokenType;
	}

	/**
	 * @param tokenType the tokenType to set
	 */
	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}

	/**
	 * @return the accessToken
	 */
	@JsonProperty("access_token")
	public String getAccessToken() {
		return accessToken;
	}

	/**
	 * @param accessToken the accessToken to set
	 */
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	/**
	 * @return the refreshToken
	 */
	@JsonProperty("refresh_token")
	public String getRefreshToken() {
		return refreshToken;
	}

	/**
	 * @param refreshToken the refreshToken to set
	 */
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	/**
	 * @return the expiresIn
	 */
	@JsonProperty("expires_in")
	public String getExpiresIn() {
		return expiresIn;
	}

	/**
	 * @param expiresIn the expireIn to set
	 */
	public void setExpiresIn(String expiresIn) {
		this.expiresIn = expiresIn;
	}
	
}
