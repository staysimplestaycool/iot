package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class UserMobileDevice {

	private String guid;
	private FlexcoUser flexcoUserGuid;
	private String osName;
	private String osVersion;
	private String deviceToken;
	private String uuid;

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the flexcoUserGuid
	 */
	public FlexcoUser getFlexcoUserGuid() {
		return flexcoUserGuid;
	}

	/**
	 * @param flexcoUserGuid the flexcoUserGuid to set
	 */
	public void setFlexcoUserGuid(FlexcoUser flexcoUserGuid) {
		this.flexcoUserGuid = flexcoUserGuid;
	}

	/**
	 * @return the osName
	 */
	public String getOsName() {
		return osName;
	}

	/**
	 * @param osName the osName to set
	 */
	public void setOsName(String osName) {
		this.osName = osName;
	}

	/**
	 * @return the osVersion
	 */
	public String getOsVersion() {
		return osVersion;
	}

	/**
	 * @param osVersion the osVersion to set
	 */
	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}

	/**
	 * @return the deviceToken
	 */
	public String getDeviceToken() {
		return deviceToken;
	}

	/**
	 * @param deviceToken the deviceToken to set
	 */
	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	/**
	 * @return the uuid
	 */
	public String getUuid() {
		return uuid;
	}

	/**
	 * @param uuid the uuid to set
	 */
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

}
