package com.softweb.serviceImpl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.softweb.common.Page;
import com.softweb.common.HttpUtil;
import com.softweb.model.ApiResponse;
import com.softweb.model.Entity;
import com.softweb.model.IoTConnect;
import com.softweb.model.Role;
import com.softweb.model.User;
import com.softweb.model.UserInfo;
import com.softweb.model.UserPreferences;
import com.softweb.service.UserService;
import com.softweb.temp.model.AddEntity;
import com.softweb.temp.model.BearerToken;
import com.softweb.temp.model.UserProperty;


/**
 * @author shreya.hedau
 *
 */
public class UserServiceImpl implements UserService {

	private IoTConnect ioTConnect;

	public final String EMAIL = "email";

	/**
	 * 
	 */
	public UserServiceImpl() {
		super();
		ioTConnect = IoTConnect.getInstance();
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#forgotPassword(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<User>> forgotPassword(Map<String, String> headers, String email)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(EMAIL, email);

		return (ApiResponse<ArrayList<User>>) HttpUtil.getHttpUtil().doPost(ioTConnect.USER_BASE_URL + "/user/forgot-password",
				data, headers, User.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getBearerTokenFromCompanyGuid(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<BearerToken> getBearerTokenFromCompanyGuid(String companyGuid)
			throws IOException {

		return (ApiResponse<BearerToken>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.USER_BASE_URL + "/company/" + companyGuid + "/service-account", null, null, BearerToken.class, true,
				false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#resetPassword(java.util.Map, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> resetPassword(Map<String, String> headers, String email, String invitationGuid,
			String newPassword) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(EMAIL, email);
		data.put("invitationguid", invitationGuid);
		data.put("newpassword", newPassword);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPost(ioTConnect.USER_BASE_URL + "/user/reset-password",
				data, headers, ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#createPassword(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<User>> createPassword(Map<String, String> headers, String email)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(EMAIL, email);

		return (ApiResponse<ArrayList<User>>) HttpUtil.getHttpUtil().doPost(ioTConnect.USER_BASE_URL + "/user/forgot-password",
				data, headers, User.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#userChangePassword(java.util.Map, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> userChangePassword(Map<String, String> headers, String email, String oldPassword,
			String newPassword) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(EMAIL, email);
		data.put("oldPassword", oldPassword);
		data.put("newPassword", newPassword);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPost(ioTConnect.USER_BASE_URL + "/user/change-password",
				data, headers, ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getUserList(java.util.Map, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<User>> getUserList(Map<String, String> headers, Integer pageNumber, Integer pageSize,
			String searchText, String sortBy) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(Page.PAGENUMBER.getValue(), pageNumber);
		data.put(Page.PAGESIZE.getValue(), pageSize);
		data.put(Page.SEARCHTEXT.getValue(), searchText);
		data.put(Page.SORTBY.getValue(), sortBy);

		return (ApiResponse<ArrayList<User>>) HttpUtil.getHttpUtil().doGet(ioTConnect.USER_BASE_URL + "/user", data,
				headers, User.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#addUser(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.String, java.util.ArrayList, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Map<String, String>>> addUser(Map<String, String> headers, String timezoneGuid,
			String roleGuid, String firstName, String lastName, String contactNo, Boolean isActive, String userId,
			ArrayList<UserProperty> properties, String entityGuid)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();

		data.put("timezoneGuid", timezoneGuid);
		data.put("roleGuid", roleGuid);
		data.put("firstName", firstName);
		data.put("lastName", lastName);
		data.put("contactNo", contactNo);
		data.put("isActive", isActive);
		data.put("userId", userId);
		data.putPOJO("properties", ioTConnect.objectMapper.writeValueAsString(properties));
		data.put("entityGuid", entityGuid);

		return (ApiResponse<ArrayList<Map<String, String>>>) HttpUtil.getHttpUtil()
				.doPost(ioTConnect.USER_BASE_URL + "/user", data, headers, Map.class, true, true);

	}
	
	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getUserByGuid(java.util.Map, java.lang.String, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<User>> getUserByGuid(Map<String, String> headers, String userGuid, Boolean userInfoFlag)
			throws IOException {

		return (ApiResponse<ArrayList<User>>) HttpUtil.getHttpUtil().doGet(ioTConnect.USER_BASE_URL + "/user/" + userGuid + "?" + userInfoFlag, null,
				headers, User.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#updateUser(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.String, java.util.ArrayList, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateUser(Map<String, String> headers, String userGuid, String timezoneGuid,
			String roleGuid, String firstName, String lastName, String contactNo, Boolean isActive, String userId,
			ArrayList<UserProperty> properties, String entityGuid)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();

		data.put("timezoneGuid", timezoneGuid);
		data.put("roleGuid", roleGuid);
		data.put("firstName", firstName);
		data.put("lastName", lastName);
		data.put("contactNo", contactNo);
		data.put("isActive", isActive);
		data.put("userId", userId);
		data.putPOJO("properties", ioTConnect.objectMapper.writeValueAsString(properties));
		data.put("entityGuid", entityGuid);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(ioTConnect.USER_BASE_URL + "/user/" + userGuid,
				data, headers, ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getUserPreferenceByGuid(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<UserPreferences>> getUserPreferenceByGuid(Map<String, String> headers, String userGuid)
			throws IOException {

		return (ApiResponse<ArrayList<UserPreferences>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.USER_BASE_URL + "/user/preferences/" + userGuid, null, headers, UserPreferences.class, true,
				true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#deleteUser(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteUser(Map<String, String> headers, String userGuid)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(ioTConnect.ROLE_BASE_URL + "/user/" + userGuid, null,
				headers, ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#updateUserStatus(java.util.Map, java.lang.String, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateUserStatus(Map<String, String> headers, String userGuid, Boolean isActive)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("isActive", isActive);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.USER_BASE_URL + "/user/" + userGuid + "/status", data, headers, ApiResponse.class,
				false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#updateUserPreference(java.util.Map, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.Integer, java.lang.String, java.lang.Boolean, java.lang.Boolean, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateUserPreference(Map<String, String> headers, String userGuid, String timezoneGuid,
			Boolean emailNotification, Integer emailNotifyOn, String alternateEmailId, Boolean smsNotification,
			Boolean pushNotification, Integer pageSize, String userInfo, String alternateEmailIdField)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("timeZoneGuid", timezoneGuid);
		data.put("emailNotification", emailNotification);
		data.put("emailNotifyOn", emailNotifyOn);
		data.put("alternateEmailID", alternateEmailId);
		data.put("smsNotification", smsNotification);
		data.put("pushNotification", pushNotification);
		data.put("pageSize", pageSize);
		data.put("userInfo", userInfo);
		data.put("alternateEmailIDField", alternateEmailIdField);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.USER_BASE_URL + "/user/preferences/" + userGuid, data, headers, ApiResponse.class,
				false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getUserProperty(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<User>> getUserProperty(Map<String, String> headers)
			throws IOException {

		return (ApiResponse<ArrayList<User>>) HttpUtil.getHttpUtil().doGet(ioTConnect.USER_BASE_URL + "/user/property",
				null, headers, User.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#userSearch(java.util.Map, java.util.List, java.util.ArrayList, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.Boolean, java.lang.Boolean, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<User>> userSearch(Map<String, String> headers, List<Object> userGuids,
			ArrayList<Object> roleguids, Integer pageNumber, Integer pageSize, String searchText, Boolean property,
			Boolean status, String sortBy) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.putPOJO("userGuids", ioTConnect.objectMapper.writeValueAsString(userGuids));
		data.putPOJO("roleguids", ioTConnect.objectMapper.writeValueAsString(roleguids));
		data.put(Page.PAGENUMBER.getValue(), pageNumber);
		data.put(Page.PAGESIZE.getValue(), pageSize);
		data.put(Page.SEARCHTEXT.getValue(), searchText);
		data.put(Page.SORTBY.getValue(), sortBy);
		data.put("property", property);
		data.put("status", status);
		return (ApiResponse<ArrayList<User>>) HttpUtil.getHttpUtil().doPost(ioTConnect.USER_BASE_URL + "/user/search",
				data, headers, User.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getUserLookup(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<User>> getUserLookup(Map<String, String> headers)
			throws IOException {

		return (ApiResponse<ArrayList<User>>) HttpUtil.getHttpUtil().doGet(ioTConnect.USER_BASE_URL + "/user/lookup/",
				null, headers, User.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#sendVerification(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> sendVerification(Map<String, String> headers, String email)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(EMAIL, email);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPost(
				ioTConnect.USER_BASE_URL + "/user/reset-password/resend", data, headers, ApiResponse.class, false,
				false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#updateUserProperties(java.util.Map, java.lang.String, java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateUserProperties(Map<String, String> headers, String userGuid,
			ArrayList<UserProperty> properties)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.putPOJO("properties", ioTConnect.objectMapper.writeValueAsString(properties));

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.USER_BASE_URL + "/user/" + userGuid + "/properties", data, headers,
				ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#deleteUserProperty(java.util.Map, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteUserProperty(Map<String, String> headers, String userGuid, String userPropertyGuid)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(
				ioTConnect.USER_BASE_URL + "/user/" + userGuid + "/property/" + userPropertyGuid, null, headers,
				ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#updateUserProfileImage(java.util.Map, java.lang.String, java.io.File)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateUserProfileImage(Map<String, String> headers, String userGuid, File file)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPutFile(
				ioTConnect.USER_BASE_URL + "/user/" + userGuid + "/profile-image", null, headers, ApiResponse.class,
				false, false,file,"picture");

	}


	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#bulkUploadUserUsingCSVfile(java.util.Map, java.lang.String, java.io.File)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> bulkUploadUserUsingCSVfile(Map<String, String> headers, String entityGuid, File file)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPost(
				ioTConnect.USER_BASE_URL + "/user/bulkUpload/" + entityGuid, data, headers, ApiResponse.class, false,
				false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getUserListByEntity(java.util.Map, java.lang.String, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<User>> getUserListByEntity(Map<String, String> headers, String entityGuid,
			Integer pageNumber, Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(Page.PAGENUMBER.getValue(), pageNumber);
		data.put(Page.PAGESIZE.getValue(), pageSize);
		data.put(Page.SEARCHTEXT.getValue(), searchText);
		data.put(Page.SORTBY.getValue(), sortBy);
		return (ApiResponse<ArrayList<User>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.USER_BASE_URL + "/entity/" + entityGuid + "/user", data, headers, User.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getUserListByRole(java.util.Map, java.lang.String, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<User>> getUserListByRole(Map<String, String> headers, String roleGuid,
			Integer pageNumber, Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(Page.PAGENUMBER.getValue(), pageNumber);
		data.put(Page.PAGESIZE.getValue(), pageSize);
		data.put(Page.SEARCHTEXT.getValue(), searchText);
		data.put(Page.SORTBY.getValue(), sortBy);

		return (ApiResponse<ArrayList<User>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.USER_BASE_URL + "/role/" + roleGuid + "/user", data, headers, User.class, true, true);

	}

	// role
	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getRoleList(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Role>> getRoleList(Map<String, String> headers)
			throws IOException {
		return (ApiResponse<ArrayList<Role>>) HttpUtil.getHttpUtil().doGet(ioTConnect.ROLE_BASE_URL + "/role/lookup",
				null, headers, Role.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getRoleByGuid(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Role>> getRoleByGuid(Map<String, String> headers, String roleGuid)
			throws IOException {
		return (ApiResponse<ArrayList<Role>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.ROLE_BASE_URL + "/role/" + roleGuid, null, headers, Role.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getRoleListWithUserCount(java.util.Map, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Role>> getRoleListWithUserCount(Map<String, String> headers, Integer pageNumber,
			Integer pageSize, String searchText, String sortBy)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put(Page.PAGENUMBER.getValue(), pageNumber);
		data.put(Page.PAGESIZE.getValue(), pageSize);
		data.put(Page.SEARCHTEXT.getValue(), searchText);
		data.put(Page.SORTBY.getValue(), sortBy);

		return (ApiResponse<ArrayList<Role>>) HttpUtil.getHttpUtil().doGet(ioTConnect.ROLE_BASE_URL + "/role/role-user",
				data, headers, Role.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#addRole(java.util.Map, java.lang.String, java.lang.String, java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<AddEntity>> addRole(Map<String, String> headers, String name,
			String description, ArrayList<String> solutions)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("description", description);
		data.putPOJO("solutions",ioTConnect.objectMapper.writeValueAsString(solutions));
		
		return (ApiResponse<ArrayList<AddEntity>>) HttpUtil.getHttpUtil()
				.doPost(ioTConnect.ROLE_BASE_URL + "/role", data, headers, AddEntity.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#updateRole(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateRole(Map<String, String> headers, String roleGuid, String name, String description,
			ArrayList<String> solutions) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("description", description);
		data.putPOJO("solutions", ioTConnect.objectMapper.writeValueAsString(solutions));
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(ioTConnect.ROLE_BASE_URL + "/role/" + roleGuid,
				data, headers, ApiResponse.class, false, false);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#updateRoleStatus(java.util.Map, java.lang.String, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateRoleStatus(Map<String, String> headers, String roleGuid, Boolean isActive)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("isActive", isActive);
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.ROLE_BASE_URL + "/role/" + roleGuid + "/status", data, headers, ApiResponse.class,
				false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#deleteRole(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteRole(Map<String, String> headers, String roleGuid)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(ioTConnect.ROLE_BASE_URL + "/role/" + roleGuid, null,
				headers, ApiResponse.class, false, false);

	}

	// entity
	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getEntityLookupList(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Entity>> getEntityLookupList(Map<String, String> headers)
			throws IOException {

		return (ApiResponse<ArrayList<Entity>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.ENTITY_BASE_URL + "/entity/lookup", null, headers, Entity.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getEntityList(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Entity>> getEntityList(Map<String, String> headers)
			throws IOException {

		return (ApiResponse<ArrayList<Entity>>) HttpUtil.getHttpUtil().doGet(ioTConnect.ENTITY_BASE_URL + "/entity",
				null, headers, Entity.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#deleteEntity(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteEntity(Map<String, String> headers, String entityGuid)
			throws IOException {
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(ioTConnect.ENTITY_BASE_URL + "/entity/" + entityGuid,
				null, headers, ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#updateEntityProperties(java.util.Map, java.lang.String, java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateEntityProperties(Map<String, String> headers, String entityGuid,
			ArrayList<Object> properties) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.putPOJO("properties", ioTConnect.objectMapper.writeValueAsString(properties));

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(ioTConnect.ENTITY_BASE_URL + "/user/change-password",
				data, headers, ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#deleteEntityProperties(java.util.Map, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteEntityProperties(Map<String, String> headers, String entity,
			String entityPropertyGuid) throws IOException {
		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doDelete(
				ioTConnect.ROLE_BASE_URL + "/entity/" + entity + "/" + entityPropertyGuid, null, headers,
				ApiResponse.class, false, false);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#getEntityById(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Entity>> getEntityById(Map<String, String> headers, String entityGuid)
			throws IOException {

		return (ApiResponse<ArrayList<Entity>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.ENTITY_BASE_URL + "/entity/" + entityGuid, null, headers, Entity.class, true, true);

	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#addEntity(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, com.softweb.model.UserInfo)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<AddEntity>> addEntity(Map<String, String> headers,
			String parentEntityGuidFromQS, String name, String description, String parentEntityGuid, String address,
			String city, String stateGuid, String countryGuid, UserInfo userInfo)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();

		data.put("name", name);
		data.put("description", description);
		data.put("parentEntityGuid", parentEntityGuid);
		data.put("address", address);
		data.put("city", city);
		data.put("stateGuid", stateGuid);
		data.put("countryGuid", countryGuid);
//		data.put("userInfo", ioTConnect.objectMapper.writeValueAsString(userInfo));

		return (ApiResponse<ArrayList<AddEntity>>) HttpUtil.getHttpUtil()
				.doPost(ioTConnect.ENTITY_BASE_URL + "/entity", data, headers, AddEntity.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.UserService#updateEntity(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, com.softweb.model.UserInfo)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateEntity(Map<String, String> headers, String entityGuid, String name,
			String description, String parentEntityGuid, String childEntityLabel, String stateGuid, String countryGuid,
			String timezoneGuid, String city, String address, UserInfo userInfo)
			throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("name", name);
		data.put("description", description);
		data.put("parentEntityGuid", parentEntityGuid);
		data.put("childEntityLable", childEntityLabel);
		data.put("stateGuid", stateGuid);
		data.put("countryGuid", countryGuid);
		data.put("timezoneGuid", timezoneGuid);
		data.put("city", city);
		data.put("address", address);
		data.putPOJO("userInfo", ioTConnect.objectMapper.writeValueAsString(userInfo));

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(ioTConnect.ENTITY_BASE_URL + "/entity/" + entityGuid,
				data, headers, ApiResponse.class, false, false);

	}


}
