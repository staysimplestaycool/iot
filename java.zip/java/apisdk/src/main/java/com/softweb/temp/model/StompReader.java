package com.softweb.temp.model;

/**
 * @author shreya.hedau
 *
 */
public class StompReader {

	private String host;
	private String vhost;
	private String user;
	private String password;
	private Integer port;
	private Integer isSecure;

	/**
	 * @return the host
	 */
	public String getHost() {
		return host;
	}

	/**
	 * @param host the host to set
	 */
	public void setHost(String host) {
		this.host = host;
	}

	/**
	 * @return the vhost
	 */
	public String getVhost() {
		return vhost;
	}

	/**
	 * @param vhost the vhost to set
	 */
	public void setVhost(String vhost) {
		this.vhost = vhost;
	}

	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the port
	 */
	public Integer getPort() {
		return port;
	}

	/**
	 * @param port the port to set
	 */
	public void setPort(Integer port) {
		this.port = port;
	}

	/**
	 * @return the isSecure
	 */
	public Integer getIsSecure() {
		return isSecure;
	}

	/**
	 * @param isSecure the isSecure to set
	 */
	public void setIsSecure(Integer isSecure) {
		this.isSecure = isSecure;
	}

}
