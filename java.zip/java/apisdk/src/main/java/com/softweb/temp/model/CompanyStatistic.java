package com.softweb.temp.model;

/**
 * @author shreya.hedau
 *
 */
public class CompanyStatistic {

	private ApiCount apiCount;
	private UserCount userCount;
	private EntityCount entityCount;

	/**
	 * @return the apiCount
	 */
	public ApiCount getApiCount() {
		return apiCount;
	}

	/**
	 * @param apiCount the apiCount to set
	 */
	public void setApiCount(ApiCount apiCount) {
		this.apiCount = apiCount;
	}

	/**
	 * @return the userCount
	 */
	public UserCount getUserCount() {
		return userCount;
	}

	/**
	 * @param userCount the userCount to set
	 */
	public void setUserCount(UserCount userCount) {
		this.userCount = userCount;
	}

	/**
	 * @return the entityCount
	 */
	public EntityCount getEntityCount() {
		return entityCount;
	}

	/**
	 * @param entityCount the entityCount to set
	 */
	public void setEntityCount(EntityCount entityCount) {
		this.entityCount = entityCount;
	}

}
