/**
 * 
 */
package com.softweb.serviceImpl;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.softweb.common.HttpUtil;
import com.softweb.model.ApiResponse;
import com.softweb.model.Firmware;
import com.softweb.model.FirmwareUpgrade;
import com.softweb.model.IoTConnect;
import com.softweb.model.OTAUpdate;
import com.softweb.model.OTAUpdateItem;
import com.softweb.service.FirmwareService;
import com.softweb.temp.model.AddEntity;

/**
 * @author Uttam Kachhad
 *
 *
 */
public class FirmwareServiceImpl implements FirmwareService {

	private IoTConnect ioTConnect;

	public FirmwareServiceImpl() {
		super();
		ioTConnect = IoTConnect.getInstance();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#getFirmwareList(java.util.Map,
	 * java.lang.Double, java.lang.Double, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Firmware>> getFirmwareList(Map<String, String> headers, Integer pageNumber,
			Integer pageSize, String searchText, String sortBy) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("searchText", searchText);
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);
		data.put("sortBy", sortBy);

		return (ApiResponse<List<Firmware>>) HttpUtil.getHttpUtil().doGet(ioTConnect.FIRMWARE_BASE_URL + "/firmware",
				data, headers, Firmware.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#getFirmwareDetail(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Firmware>> getFirmwareDetail(Map<String, String> headers, String firmwareGuid)
			throws IOException {

		return (ApiResponse<List<Firmware>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.FIRMWARE_BASE_URL + "/firmware/" + firmwareGuid, null, headers, Firmware.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#addFirmware(java.util.Map,
	 * java.io.File, java.lang.Boolean, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<AddEntity>> addFirmware(Map<String, String> headers, File file, String firmwareName,
			String firmwareDescription, String software, String hardware) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("firmwareName", firmwareName);
		data.put("firmwareDescription", firmwareDescription);
		data.put("software", software);
		data.put("hardware", hardware);
		return (ApiResponse<ArrayList<AddEntity>>) HttpUtil.getHttpUtil().doPostFile(
				ioTConnect.FIRMWARE_BASE_URL + "/firmware", data, headers, AddEntity.class, true, true, file,
				"firmwarefile");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#updateFirmware(java.util.Map,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateFirmware(Map<String, String> headers, String firmwareGuid, String firmwareName,
			String hardware, String status) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("firmwareName", firmwareName);
		data.put("hardware", hardware);
		data.put("status", status);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.FIRMWARE_BASE_URL + "/firmware/" + firmwareGuid, data, headers, ApiResponse.class, true,
				true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#addFirmwareValidate(java.util.Map,
	 * java.util.ArrayList)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<AddEntity>> addFirmwareValidate(Map<String, String> headers,
			ArrayList<Firmware> firmware) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("firmware", ioTConnect.objectMapper.writeValueAsString(firmware));

		return (ApiResponse<ArrayList<AddEntity>>) HttpUtil.getHttpUtil().doPost(
				ioTConnect.FIRMWARE_BASE_URL + "/firmware-validate", data, headers, AddEntity.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.softweb.service.FirmwareService#getMinorFirmwareDetail(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<FirmwareUpgrade>> getMinorFirmwareDetail(Map<String, String> headers, String firmwareGuid)
			throws IOException {

		return (ApiResponse<List<FirmwareUpgrade>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.FIRMWARE_UPGRADE_BASE_URL + "/firmware-upgrade/lookup/" + firmwareGuid, null, headers,
				FirmwareUpgrade.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#updateFirmwareUpgrade(java.util.Map,
	 * java.io.File, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> updateFirmwareUpgrade(Map<String, String> headers, File file, String firmwareUpgradeGuid,
			String firmwareGuid, String firmwareDescription, String software) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("firmwarefile", ioTConnect.objectMapper.writeValueAsString(file));
		data.put("firmwareGuid", firmwareGuid);
		data.put("firmwareDescription", firmwareDescription);
		data.put("software", software);

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.FIRMWARE_UPGRADE_BASE_URL + "/firmware-upgrade/" + firmwareUpgradeGuid, data, headers,
				ApiResponse.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#addFirmwareUpgrade(java.util.Map,
	 * java.io.File, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<AddEntity>> addFirmwareUpgrade(Map<String, String> headers, File file,
			String firmwareDescription, String firmwareGuid, String software) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("description", firmwareDescription);
		data.put("firmwareGuid", firmwareGuid);
		data.put("software", software);

		return (ApiResponse<ArrayList<AddEntity>>) HttpUtil.getHttpUtil().doPostFile(
				ioTConnect.FIRMWARE_UPGRADE_BASE_URL + "/firmware-upgrade", data, headers, AddEntity.class, true, true,
				file, "firmwarefile");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#firmwareUpgradeList(java.util.Map,
	 * java.lang.String, java.lang.String, java.lang.Double, java.lang.Double,
	 * java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<FirmwareUpgrade>> firmwareUpgradeList(Map<String, String> headers, String firmwareGuid,
			String type, Integer pageNumber, Integer pageSize, String searchText, String sortBy) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("firmwareGuid", firmwareGuid);
		data.put("type", type);
		data.put("searchText", searchText);
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);
		data.put("sortBy", sortBy);

		return (ApiResponse<List<FirmwareUpgrade>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.FIRMWARE_UPGRADE_BASE_URL + "/firmware-upgrade", data, headers, FirmwareUpgrade.class, true,
				true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#lookupFirmware(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Firmware>> lookupFirmware(Map<String, String> headers, String firmwareGuid)
			throws IOException {

		return (ApiResponse<List<Firmware>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.FIRMWARE_BASE_URL + "/firmware/" + firmwareGuid + "/lookup", null, headers, Firmware.class,
				true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#publishFirmware(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<FirmwareUpgrade>> publishFirmware(Map<String, String> headers, String firmwareUpgradeGuid)
			throws IOException {

		return (ApiResponse<List<FirmwareUpgrade>>) HttpUtil.getHttpUtil().doPut(
				ioTConnect.FIRMWARE_UPGRADE_BASE_URL + "/firmware-upgrade/" + firmwareUpgradeGuid + "/publish", "null",
				headers, FirmwareUpgrade.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#lookupFirmware(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<Firmware>> lookupFirmware(Map<String, String> headers) throws IOException {

		return (ApiResponse<List<Firmware>>) HttpUtil.getHttpUtil()
				.doGet(ioTConnect.FIRMWARE_BASE_URL + "/firmware/lookup", null, headers, Firmware.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#deleteFirmwareUpgrade(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> deleteFirmwareUpgrade(Map<String, String> headers, String firmwareUpgradeGuid)
			throws IOException {

		return (ApiResponse<Void>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.FIRMWARE_UPGRADE_BASE_URL + "/firmware-upgrade/" + firmwareUpgradeGuid, null, headers,
				ApiResponse.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#getOTAUpdate(java.util.Map,
	 * java.lang.Double, java.lang.Double, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<OTAUpdate>> getOTAUpdate(Map<String, String> headers, Integer pageNumber, Integer pageSize,
			String searchText, String sortBy) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);
		data.put("searchText", searchText);
		data.put("sortBy", sortBy);

		return (ApiResponse<List<OTAUpdate>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.FIRMWARE_OTA_UPDATE_BASE_URL + "/ota-update", data, headers, OTAUpdate.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.softweb.service.FirmwareService#getOTAUpdateByDeviceGuid(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<OTAUpdate>> getOTAUpdateByDeviceGuid(Map<String, String> headers, String deviceGuid)
			throws IOException {

		return (ApiResponse<List<OTAUpdate>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.FIRMWARE_OTA_UPDATE_BASE_URL + "/ota-update/device/" + deviceGuid, null, headers,
				OTAUpdate.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#sendOTAUpdate(java.util.Map,
	 * java.lang.String, java.lang.Integer, java.lang.String, java.lang.String,
	 * java.lang.Integer)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<OTAUpdateItem> sendOTAUpdate(Map<String, String> headers, String firmwareUpgradeGuid,
			Integer isForceUpdate, String entityGuid, String scheduledOn, Integer isRecursive) throws IOException {

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
		Date date = new Date(scheduledOn);
		String scheduledOnFormated = simpleDateFormat.format(date);

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("firmwareUpgradeGuid", firmwareUpgradeGuid);
		data.put("isForceUpdate", isForceUpdate);
		data.put("entityGuid", entityGuid);
		data.put("scheduledOn", scheduledOnFormated);
		data.put("isRecursive", isRecursive);

		return (ApiResponse<OTAUpdateItem>) HttpUtil.getHttpUtil().doPost(
				ioTConnect.FIRMWARE_OTA_UPDATE_BASE_URL + "/ota-update", data, headers, OTAUpdateItem.class, true,
				true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.FirmwareService#getOTAUpdateDetails(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<OTAUpdate>> getOTAUpdateDetails(Map<String, String> headers, String otaUpdateGuid)
			throws IOException {

		return (ApiResponse<List<OTAUpdate>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.FIRMWARE_OTA_UPDATE_BASE_URL + "/ota-update/" + otaUpdateGuid, null, headers,
				OTAUpdate.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.softweb.service.FirmwareService#getOTAUpdateStatusList(java.util.Map,
	 * java.lang.String, java.lang.String, java.lang.Double, java.lang.Double,
	 * java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<OTAUpdate>> getOTAUpdateStatusList(Map<String, String> headers, String id, String status,
			Integer pageNumber, Integer pageSize, String searchText, String sortBy) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("pageNumber", pageNumber);
		data.put("pageSize", pageSize);
		data.put("searchText", searchText);
		data.put("sortBy", sortBy);

		return (ApiResponse<List<OTAUpdate>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.FIRMWARE_OTA_UPDATE_BASE_URL + "/ota-update/" + id + "/status/" + status, data, headers,
				OTAUpdate.class, true, true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.softweb.service.FirmwareService#getRecentOTAUpdateStatistics(java.util.
	 * Map, java.lang.Double, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<OTAUpdate>> getRecentOTAUpdateStatistics(Map<String, String> headers, Integer count,
			String status) throws IOException {

		ObjectNode data = ioTConnect.objectMapper.createObjectNode();
		data.put("count", count);
		data.put("status", status);

		return (ApiResponse<List<OTAUpdate>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.FIRMWARE_OTA_UPDATE_BASE_URL + "/ota-update/recent-activity", data, headers, OTAUpdate.class,
				true, true);
	}

}
