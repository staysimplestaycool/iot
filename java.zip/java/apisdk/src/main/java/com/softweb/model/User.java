package com.softweb.model;

import java.sql.Date;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonAlias;

/**
 * @author shreya.hedau
 *
 */
//@JsonIgnoreProperties(ignoreUnknown = true)

public class User {

	@JsonAlias({ "guid", "userGuid" })
	private String guid;
	private String userId;
	private String companyGuid;
	private String entityGuid;
	private String password;
	private String firstName;
	private String lastName;
	private String timezoneGuid;
	private String imageName;
	private String contactNo;
	private String lastPasswordUpdatedDate;
	private Boolean isActive;
	private Boolean isDeleted;
	private Date createdDate;
	private String createdBy;
	private Date updatedDate;
	private String updatedBy;

	private String updatedByName;
	private String roleName;
	private String roleGuid;
	private String entityName;
	private ArrayList<UserInfo> userInfo;
	private String updateByName;
	private String parentEntityGuid;
	private byte[] companyLogo;
	private String companyName;
	private String companyCpid;
	private Integer timezoneOffset;
	private String companyLogoUrl;
	private String imageUrl;
	private String dms_version;
	@JsonAlias({ "invitationguid", "invitationGuid" })
	private String invitationguid;

	private String name;
	private Boolean isVerified;

	public User() {
		super();
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the isVerified
	 */
	public Boolean getIsVerified() {
		return isVerified;
	}

	/**
	 * @param isVerified the isVerified to set
	 */
	public void setIsVerified(Boolean isVerified) {
		this.isVerified = isVerified;
	}

	/**
	 * @return the updatedByName
	 */
	public String getUpdatedByName() {
		return updatedByName;
	}

	/**
	 * @param updatedByName the updatedByName to set
	 */
	public void setUpdatedByName(String updatedByName) {
		this.updatedByName = updatedByName;
	}

	/**
	 * @return the entityName
	 */
	public String getEntityName() {
		return entityName;
	}

	/**
	 * @param entityName the entityName to set
	 */
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	/**
	 * @return the userInfo
	 */
	public ArrayList<UserInfo> getUserInfo() {
		return userInfo;
	}

	/**
	 * @param userInfo the userInfo to set
	 */
	public void setUserInfo(ArrayList<UserInfo> userInfo) {
		this.userInfo = userInfo;
	}

	/**
	 * @return the updateByName
	 */
	public String getUpdateByName() {
		return updateByName;
	}

	/**
	 * @param updateByName the updateByName to set
	 */
	public void setUpdateByName(String updateByName) {
		this.updateByName = updateByName;
	}

	/**
	 * @return the parentEntityGuid
	 */
	public String getParentEntityGuid() {
		return parentEntityGuid;
	}

	/**
	 * @param parentEntityGuid the parentEntityGuid to set
	 */
	public void setParentEntityGuid(String parentEntityGuid) {
		this.parentEntityGuid = parentEntityGuid;
	}

	/**
	 * @return the companyLogo
	 */
	public byte[] getCompanyLogo() {
		return companyLogo;
	}

	/**
	 * @param companyLogo the companyLogo to set
	 */
	public void setCompanyLogo(byte[] companyLogo) {
		this.companyLogo = companyLogo;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * @return the companyCpid
	 */
	public String getCompanyCpid() {
		return companyCpid;
	}

	/**
	 * @param companyCpid the companyCpid to set
	 */
	public void setCompanyCpid(String companyCpid) {
		this.companyCpid = companyCpid;
	}

	/**
	 * @return the timezoneOffset
	 */
	public Integer getTimezoneOffset() {
		return timezoneOffset;
	}

	/**
	 * @param timezoneOffset the timezoneOffset to set
	 */
	public void setTimezoneOffset(Integer timezoneOffset) {
		this.timezoneOffset = timezoneOffset;
	}

	/**
	 * @return the companyLogoUrl
	 */
	public String getCompanyLogoUrl() {
		return companyLogoUrl;
	}

	/**
	 * @param companyLogoUrl the companyLogoUrl to set
	 */
	public void setCompanyLogoUrl(String companyLogoUrl) {
		this.companyLogoUrl = companyLogoUrl;
	}

	/**
	 * @return the imageUrl
	 */
	public String getImageUrl() {
		return imageUrl;
	}

	/**
	 * @param imageUrl the imageUrl to set
	 */
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	/**
	 * @return the dms_version
	 */
	public String getDms_version() {
		return dms_version;
	}

	/**
	 * @param dms_version the dms_version to set
	 */
	public void setDms_version(String dms_version) {
		this.dms_version = dms_version;
	}

	/**
	 * @return the roleGuid
	 */
	public String getRoleGuid() {
		return roleGuid;
	}

	/**
	 * @param roleGuid the roleGuid to set
	 */
	public void setRoleGuid(String roleGuid) {
		this.roleGuid = roleGuid;
	}

	/**
	 * @return the roleName
	 */
	public String getRoleName() {
		return roleName;
	}

	/**
	 * @param roleName the roleName to set
	 */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	/**
	 * @return guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the companyGuid
	 */
	public String getCompanyGuid() {
		return companyGuid;
	}

	/**
	 * @param companyGuid the companyGuid to set
	 */
	public void setCompanyGuid(String companyGuid) {
		this.companyGuid = companyGuid;
	}

	/**
	 * @return the entityGuid
	 */
	public String getEntityGuid() {
		return entityGuid;
	}

	/**
	 * @param entityGuid the enityGuid to set
	 */
	public void setEntityGuid(String entityGuid) {
		this.entityGuid = entityGuid;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the firstname
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstname to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastname
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastname to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the timezoneGuid
	 */
	public String getTimezoneGuid() {
		return timezoneGuid;
	}

	/**
	 * @param timezoneGuid the timezoneGuid to set
	 */
	public void setTimezoneGuid(String timezoneGuid) {
		this.timezoneGuid = timezoneGuid;
	}

	/**
	 * @return the imageName
	 */
	public String getImageName() {
		return imageName;
	}

	/**
	 * @param imageName the imageName to set
	 */
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	/**
	 * @return the contactNo
	 */
	public String getContactNo() {
		return contactNo;
	}

	/**
	 * @param contactNo the contactNo to set
	 */
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	/**
	 * @return the lastPasswordUpdatedDate
	 */
	public String getLastPasswordUpdatedDate() {
		return lastPasswordUpdatedDate;
	}

	/**
	 * @param lastPasswordUpdatedDate the lastPasswordUpdatedDate to set
	 */
	public void setLastPasswordUpdatedDate(String lastPasswordUpdatedDate) {
		this.lastPasswordUpdatedDate = lastPasswordUpdatedDate;
	}

	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the invitationguid
	 */
	public String getInvitationguid() {
		return invitationguid;
	}

	/**
	 * @param invitationguid the invitationguid to set
	 */
	public void setInvitationguid(String invitationguid) {
		this.invitationguid = invitationguid;
	}

}
