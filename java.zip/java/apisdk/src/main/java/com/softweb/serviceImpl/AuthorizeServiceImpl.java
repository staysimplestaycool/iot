package com.softweb.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.softweb.common.HttpUtil;
import com.softweb.model.ApiResponse;
import com.softweb.model.IoTConnect;
import com.softweb.model.Module;
import com.softweb.model.Role;
import com.softweb.service.AuthorizeService;

/**
 * @author shreya.hedau
 *
 */
public class AuthorizeServiceImpl implements AuthorizeService {

	private IoTConnect ioTConnect;

	/**
	 * 
	 */
	public AuthorizeServiceImpl() {
		super();
		ioTConnect = IoTConnect.getInstance();
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.AuthorizeService#getModuleList(java.util.Map, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Module>> getModuleList(Map<String, String> headers, Boolean isPermission) throws IOException{
		return (ApiResponse<ArrayList<Module>>) HttpUtil.getHttpUtil().doGet(
					ioTConnect.AUTHORIZE_BASE_URL + "/authorize/module", null, headers, Module.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.AuthorizeService#getRolePermission(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Role> getRolePermission(Map<String, String> headers, String roleGuid) throws IOException {
			return (ApiResponse<Role>) HttpUtil.getHttpUtil().doGet(
					ioTConnect.AUTHORIZE_BASE_URL + "/authorize/role/" + roleGuid + "/permission", null, headers,
					Role.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.AuthorizeService#getUserRoleModulePermission(java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<Role>> getUserRoleModulePermission(Map<String, String> headers) throws IOException {
			return (ApiResponse<ArrayList<Role>>) HttpUtil.getHttpUtil().doGet(
					ioTConnect.AUTHORIZE_BASE_URL + "/authorize/user", null, headers,
					Role.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.AuthorizeService#assignRoleModulePermission(java.util.Map, java.lang.String, java.lang.String, java.lang.String, com.fasterxml.jackson.databind.node.ArrayNode)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Void> assignRoleModulePermission(Map<String, String> headers, String roleGuid,
			String roleName, String roleDescription, ArrayNode modules) throws IOException {
			ObjectNode data = ioTConnect.objectMapper.createObjectNode();
			data.put("roleGuid", roleGuid);
			data.put("roleName", roleName);
			data.put("roleDescription", roleDescription);
			data.putPOJO("modules", ioTConnect.objectMapper.writeValueAsString(modules));
			return  (ApiResponse<Void>) HttpUtil.getHttpUtil().doPost(
					ioTConnect.AUTHORIZE_BASE_URL + "/authorize/role-permission", data, headers,
					ApiResponse.class, false, false);
			
	}

}
