package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class RuleDevice {

	private String guid;
	private String roleGuid;
	private String deviceGuid;

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the roleGuid
	 */
	public String getRoleGuid() {
		return roleGuid;
	}

	/**
	 * @param roleGuid the roleGuid to set
	 */
	public void setRoleGuid(String roleGuid) {
		this.roleGuid = roleGuid;
	}

	/**
	 * @return the deviceGuid
	 */
	public String getDeviceGuid() {
		return deviceGuid;
	}

	/**
	 * @param deviceGuid the deviceGuid to set
	 */
	public void setDeviceGuid(String deviceGuid) {
		this.deviceGuid = deviceGuid;
	}

}
