package com.softweb.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.softweb.model.ApiResponse;
import com.softweb.model.Country;
import com.softweb.model.Dashboard;
import com.softweb.model.FAQ;
import com.softweb.model.Property;
import com.softweb.model.PropertyFieldType;
import com.softweb.model.PropertyType;
import com.softweb.model.State;
import com.softweb.model.Timezone;
import com.softweb.model.Widget;
import com.softweb.temp.model.DashboardProperties;
import com.softweb.temp.model.WidgetProperties;


/**
 * @author shreya.hedau
 *
 */
public interface MasterService {
	
	// Get Country
	ApiResponse<ArrayList<Country>> getCountry() throws IOException;

	// Get State
	ApiResponse<ArrayList<State>> getState(String countryGuid) throws IOException;

	// Get TimeZone
	ApiResponse<ArrayList<Timezone>> getTimezone() throws IOException;

	// FAQ
	// Get FAQ List
	ApiResponse<ArrayList<FAQ>> getFAQList(Map<String, String> headers, Integer pageNumber, Integer pageSize, String searchText, String sortBy) throws IOException;

	// Get FAQ by Guid
	ApiResponse<FAQ> getFAQbyGuid(Map<String, String> headers, String faqGuid) throws IOException;

	// Add FAQ
	ApiResponse<ArrayList<Map<String,String>>> addFAQ(Map<String, String> headers, String question, String answer, Integer sequence) throws IOException;

	// Update FAQ
	ApiResponse<Void> updateFAQ(Map<String, String> headers, String faqGuid, String question, String answer, Integer sequence) throws IOException;

	// Delete FAQ
	ApiResponse<Void> deleteFAQ(Map<String, String> headers, String faqGuid) throws IOException;

	// Update FAQ Sequence
	ApiResponse<Void> updateFAQSequence(Map<String, String> headers, Integer newSequence, String faqGuid) throws IOException;

	// Property

	// Get Property Type
	ApiResponse<ArrayList<PropertyType>> getPropertyType(Map<String, String> headers) throws IOException;

	// Get Property Data Type
	ApiResponse<ArrayList<PropertyFieldType>> getPropertyDataType(Map<String, String> headers) throws IOException;

	// Get Property By Property Type
	ApiResponse<ArrayList<Property>> getPropertyByPropertyType(Map<String, String> headers, String propertyTypeGuid) throws IOException;

	// Get Property Detail
	ApiResponse<Property> getPropertyDetail(Map<String, String> headers, String propertyGuid, String propertyTypeGuid) throws IOException;

	// Add Property
	ApiResponse<ArrayList<Map<String,String>>> addProperty(Map<String, String> headers, String propertyTypeGuid, String name,String fieldType, String options) throws IOException;

	// Update Property
	ApiResponse<Void> updateProperty(Map<String, String> headers, String propertyGuid, String propertyTypeGuid, String name,String fieldType, String options) throws IOException;

	// Delete Property
	ApiResponse<Void> deleteProperty(Map<String, String> headers, String propertyGuid, String propertyTypeGuid) throws IOException;

	// Dashboard

	// Get Dashboard List
	ApiResponse<ArrayList<Dashboard>> getDashboardList(Map<String, String> headers) throws IOException;

	// Get Dashboard Widget
	ApiResponse<ArrayList<Widget>> getDashboardWidget(Map<String, String> headers) throws IOException;

	// Get DashBoard By Guid
	ApiResponse<Dashboard> getDashboardByGuid(Map<String, String> headers, String dashboardGuid) throws IOException;

	// Add DashBoard
	ApiResponse<ArrayList<Map<String,String>>> addDashboard(Map<String, String> headers, String dashboardName) throws IOException;

	// Add DashBoard Widget
	ApiResponse<ArrayList<Map<String,String>>> addDashboardWidget(Map<String, String> headers, String widgetGuid, String dashboardGuid, DashboardProperties properties, WidgetProperties widgetProperties, String dashboardWidgetGuid) throws IOException;

	// Update Dashboard Widget
	ApiResponse<Void> updateDashboardWidget(Map<String, String> headers, String dashboardGuid, String dashboardWidgetGuid, String widgetGuid, WidgetProperties widgetProperties) throws IOException;

	// Update Dashboard Widget Position
	ApiResponse<Void> updateDashboardWidgetPosition(Map<String, String> headers,ArrayNode postData)
			throws IOException;

	// Update Dashboard
	ApiResponse<Void> updateDashboard(Map<String, String> headers, String dashboardGuid, Integer isDefault, String name) throws IOException;

	// Delete Dashboard
	ApiResponse<Void> deleteDashboard(Map<String, String> headers, String dashboardGuid) throws IOException;

	// Delete Dashboard Widget
	ApiResponse<Void> deleteDashboardWidget(Map<String, String> headers, String dashboardWidgetGuid) throws IOException;

}