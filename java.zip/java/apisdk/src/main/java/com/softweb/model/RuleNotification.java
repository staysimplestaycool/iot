package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class RuleNotification {

	private String guid;
	private Role roleGuid;
	private String notificationTypeGuid;
	private String notificationText;

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the roleGuid
	 */
	public Role getRoleGuid() {
		return roleGuid;
	}

	/**
	 * @param roleGuid the roleGuid to et
	 */
	public void setRoleGuid(Role roleGuid) {
		this.roleGuid = roleGuid;
	}

	/**
	 * @return the notificationTypeGuid
	 */
	public String getNotificationTypeGuid() {
		return notificationTypeGuid;
	}

	/**
	 * @param notificationTypeGuid the notificationTypeGuid to set
	 */
	public void setNotificationTypeGuid(String notificationTypeGuid) {
		this.notificationTypeGuid = notificationTypeGuid;
	}

	/**
	 * @return the notificationText
	 */
	public String getNotificationText() {
		return notificationText;
	}

	/**
	 * @param notificationText the notificationText to set
	 */
	public void setNotificationText(String notificationText) {
		this.notificationText = notificationText;
	}

}
