package com.softweb.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.softweb.model.ApiResponse;

/**
 * @author shreya.hedau
 *
 */
public interface DiscoveryService {

	// Get SDK Import Item List
	ApiResponse<ArrayList<Map<String,String>>> getSdkImportItemList(Map<String,String> headers,String cpid,String lang,String version,String env) throws IOException;
	
	// Get Product Import Item List
	ApiResponse<ArrayList<String>> getProductImportItemList(Map<String,String> headers,String cpid,String lang,String version,String env) throws IOException;


}
