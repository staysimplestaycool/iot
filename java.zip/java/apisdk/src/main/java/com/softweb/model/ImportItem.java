/**
 * 
 */
package com.softweb.model;

import java.util.Date;

/**
 * @author mayuri.mojidra
 *
 */
public class ImportItem {
	
	private String guid;
	private ImportBatch importBatch;
	private String jsonData;
	private DeviceTemplate deviceTemplate;
	private Boolean isValid;
	private Device device;
	private String importLog;
	private Boolean isDeleted;
	private Date createdDate;
	private User createdBy;
	private Date updatedDate;
	private User updatedBy;
	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}
	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}
	/**
	 * @return the importBatch
	 */
	public ImportBatch getImportBatch() {
		return importBatch;
	}
	/**
	 * @param importBatch the importBatch to set
	 */
	public void setImportBatch(ImportBatch importBatch) {
		this.importBatch = importBatch;
	}
	/**
	 * @return the jsonData
	 */
	public String getJsonData() {
		return jsonData;
	}
	/**
	 * @param jsonData the jsonData to set
	 */
	public void setJsonData(String jsonData) {
		this.jsonData = jsonData;
	}
	/**
	 * @return the deviceTemplate
	 */
	public DeviceTemplate getDeviceTemplate() {
		return deviceTemplate;
	}
	/**
	 * @param deviceTemplate the deviceTemplate to set
	 */
	public void setDeviceTemplate(DeviceTemplate deviceTemplate) {
		this.deviceTemplate = deviceTemplate;
	}
	/**
	 * @return the isValid
	 */
	public Boolean getIsValid() {
		return isValid;
	}
	/**
	 * @param isValid the isValid to set
	 */
	public void setIsValid(Boolean isValid) {
		this.isValid = isValid;
	}
	/**
	 * @return the device
	 */
	public Device getDevice() {
		return device;
	}
	/**
	 * @param device the device to set
	 */
	public void setDevice(Device device) {
		this.device = device;
	}
	/**
	 * @return the importLog
	 */
	public String getImportLog() {
		return importLog;
	}
	/**
	 * @param importLog the importLog to set
	 */
	public void setImportLog(String importLog) {
		this.importLog = importLog;
	}
	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}
	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}
	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}
	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	


}
