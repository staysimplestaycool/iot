package com.softweb.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.softweb.common.HttpUtil;
import com.softweb.model.ApiResponse;
import com.softweb.model.AttributeValue;
import com.softweb.model.IoTConnect;
import com.softweb.service.TelematryService;
import com.softweb.temp.model.TelemetryResponse;

/**
 * @author Uttam Kachhad
 *
 *
 */
public class TelematryServiceImpl implements TelematryService {
	
	
	private IoTConnect ioTConnect;

	public TelematryServiceImpl() {
		super();
		ioTConnect = IoTConnect.getInstance();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.softweb.service.TelematryService#getDeviceSensors(java.util.Map,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<List<AttributeValue>> getDeviceSensors(Map<String, String> headers,String deviceGuid) throws IOException {
		
		 return (ApiResponse<List<AttributeValue>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TELEMATRY_BASE_URL + "/telemetry/device/" + deviceGuid,null, headers, AttributeValue.class, true, true);
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see	
	 * com.softweb.service.TelematryService#getDeviceAttributeHistoricalData
	 * (java.util.Map, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<TelemetryResponse>> getDeviceAttributeHistoricalDataByuniqueId(Map<String, String> headers,String uniqueId, String fromDate, String toDate)
			throws IOException {
		
		return (ApiResponse<ArrayList<TelemetryResponse>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TELEMATRY_BASE_URL + "/telemetry/attribute-history/device/"+uniqueId +"/from/"+fromDate+"/to/"+toDate,null, headers, TelemetryResponse.class, true, true);
	}
	
	
	/* (non-Javadoc)
	 * @see com.softweb.service.TelematryService#getDeviceAttributeHistoricalDataByAttribute(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<TelemetryResponse>> getDeviceAttributeHistoricalDataByAttribute(Map<String, String> headers,String attributeId,String uniqueId, String fromDate, String toDate)
			throws IOException {
		
		return (ApiResponse<ArrayList<TelemetryResponse>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TELEMATRY_BASE_URL + "/telemetry/attribute-history/attribute/"+attributeId+"/device/"+uniqueId+"/from/"+fromDate+"/to/"+toDate,null, headers, TelemetryResponse.class, true, true);
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.TelematryService#getDeviceAttributeHistoricalDataByattributeGuid(java.util.Map, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<ArrayList<TelemetryResponse>> getDeviceAttributeHistoricalDataByattributeGuid(Map<String, String> headers, String attributeId, String uniqueId,
			String fromDate, String toDate) throws IOException {
		
		return (ApiResponse<ArrayList<TelemetryResponse>>) HttpUtil.getHttpUtil().doGet(
				ioTConnect.TELEMATRY_BASE_URL + "/telemetry/attribute-history/attributeGuid/"+attributeId+"/device/"+uniqueId+"/from/"+fromDate+"/to/"+toDate,null, headers, TelemetryResponse.class, true, true);
	}

}
