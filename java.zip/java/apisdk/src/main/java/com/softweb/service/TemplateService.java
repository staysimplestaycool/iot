package com.softweb.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.softweb.model.ApiResponse;
import com.softweb.model.CommandHistory;
import com.softweb.model.DataType;
import com.softweb.model.Rule;
import com.softweb.model.TemplateAttribute;
import com.softweb.model.TemplateCommand;
import com.softweb.model.TemplateSetting;
import com.softweb.temp.model.Attributes;
import com.softweb.temp.model.RuleList;
import com.softweb.temp.model.Template;

/**
 * @author shreya.hedau
 *
 */
public interface TemplateService {
	
	//
	ApiResponse<ArrayList<DataType>> lookupTemplate(Map<String, String> headers, Boolean hasAttribute)throws IOException;
	
	//
	ApiResponse<ArrayList<DataType>> dataType(Map<String, String> headers)throws IOException;
	
	//
	ApiResponse<ArrayList<Template>> templateDetail(Map<String, String> headers, String templateGuid)throws IOException;
	
	//
	ApiResponse<ArrayList<Object>> templateJsonView(Map<String, String> headers, String templateGuid)throws IOException;
	
	//
	ApiResponse<ArrayList<Template>> templateList(Map<String, String> headers, Integer pageNumber, Integer pageSize, String searchText, String sortBy)throws IOException;

	//
	ApiResponse<ArrayList<Map<String, String>>> addTemplate(Map<String, String> headers, String code, String name, String firmwareGuid, String description)throws IOException;
	
	//
	ApiResponse<Void> updateTemplate(Map<String, String> headers, String templateGuid, String name, String firmwareGuid, String description)throws IOException;
	
	//
	ApiResponse<Void> deleteTemplate(Map<String, String> headers, String templateGuid)throws IOException;
	
	// SETTING
	
	//
	ApiResponse<ArrayList<TemplateSetting>> lookupSetting(Map<String, String> headers, String deviceTemplateGuid)throws IOException;
	
	//
	ApiResponse<ArrayList<TemplateSetting>> settingList(Map<String, String> headers, String deviceTemplateGuid, Integer pageNumber, Integer pageSize, String searchText, String sortBy)throws IOException;
	
	//
	ApiResponse<ArrayList<Map<String, String>>> addSetting(Map<String, String> headers, String name, String dataTypeGuid, String deviceTemplateGuid, String localName, String defaultValue, String dataValidation) throws IOException;
	
	//
	ApiResponse<Void> updateSetting(Map<String, String> headers,  String settingGuid, String name, String dataTypeGuid, String deviceTemplateGuid, String localName, String defaultValue, String dataValidation)throws IOException;
	
	//
	ApiResponse<Void> deleteSetting(Map<String, String> headers, String templateGuid)throws IOException;
	
	// ATTRIBUTE
	
	//
	ApiResponse<ArrayList<TemplateAttribute>> lookupAttribute(Map<String, String> headers, String deviceTemplateGuid)throws IOException;
	
	//
	ApiResponse<ArrayList<TemplateAttribute>> attributeList(Map<String, String> headers, String deviceTemplateGuid, Integer pageNumber, Integer pageSize, String searchText, String sortBy)throws IOException;

	//
	ApiResponse<ArrayList<Map<String, String>>> addAttribute(Map<String, String> headers, String localName,
			String description, String deviceTemplateGuid, String dataTypeGuid, String dataValidation, String unit,
			ArrayList<Attributes> attributes) throws IOException;
	
	//
	ApiResponse<Void> updateAttribute(Map<String, String> headers,String attributeGuid, String localName,
			String description, String deviceTemplateGuid, String dataTypeGuid, String dataValidation, String unit,
			ArrayList<Attributes> attributes) throws IOException;
	
	//
	ApiResponse<Void> deleteAttribute(Map<String, String> headers, String attributeGuid)throws IOException;
	
	// Command
	
	//
	ApiResponse<ArrayList<TemplateCommand>> commandLookup(Map<String, String> headers, String deviceTemplateGuid)throws IOException;
	
	//
	ApiResponse<ArrayList<TemplateCommand>> templateCommandList(Map<String, String> headers, String deviceTemplateGuid, Integer pageNumber, Integer pageSize, String searchText, String sortBy)throws IOException;
	
	//
	ApiResponse<ArrayList<Map<String, String>>> addTemplateCommand(Map<String, String> headers, String name, String command, String deviceTemplateGuid, Boolean requiredParam, Boolean requiredAck)throws IOException;
	
	//
	ApiResponse<Void> updateTemplateCommand(Map<String, String> headers, String commandGuid,  String name, String command, String deviceTemplateGuid, Boolean requiredParam, Boolean requiredAck)throws IOException;
	
	//
	ApiResponse<Void> deleteTemplateCommand(Map<String, String> headers, String commandGuid)throws IOException;
	
	//
	ApiResponse<ArrayList<Map<String, String>>> executeCommandOnMultiDevice(Map<String, String> headers, String commandGuid, Integer applyTo, String entityGuid, Boolean isRecursive, ArrayList<String> devices, String parameterValue)throws IOException;
	
	//
	ApiResponse<ArrayList<Map<String, String>>> executeCommandOnSingleDevice(Map<String, String> headers, String deviceGuid, String commandGuid, String parameterValue)throws IOException;
	
	//
	ApiResponse<ArrayList<CommandHistory>> getCommandHistory(Map<String, String> headers, Integer pageNumber, Integer pageSize, String searchText, String sortBy, String deviceGuid)throws IOException;
	
	// RULE 
	
	//
	ApiResponse<ArrayList<Map<String, Integer>>> ruleCountService(Map<String, String> headers)throws IOException;

	//
	ApiResponse<ArrayList<RuleList>> ruleListService(Map<String, String> headers, Integer pageNumber, Integer pageSize, String searchText, String sortBy)throws IOException;
	
	//
	ApiResponse<Void> addRuleService(Map<String, String> headers, String templateGuid, Integer ruleType, String name, String conditionText, Boolean ignorePreference, String entityGuid, Integer applyTo, ArrayList<String> devices, ArrayList<String> roles, ArrayList<String> users, ArrayList<String> deliveryMethod)throws IOException;
	
	//
	ApiResponse<Void> updateRuleService(Map<String, String> headers, String ruleGuid, String templateGuid, Integer ruleType, String name, String conditionText, Boolean ignorePreference, String entityGuid, Integer applyTo,Boolean isActive,  ArrayList<String> devices, ArrayList<String> roles, ArrayList<String> users, ArrayList<String> deliveryMethod)throws IOException;
	
	//
	ApiResponse<Void> deleteRuleService(Map<String, String> headers, String ruleGuid)throws IOException;
	
	//
	ApiResponse<Rule> ruleDetailService(Map<String, String> headers, String ruleGuid)throws IOException;
	
	//
	ApiResponse<Void> updateRuleStatusService(Map<String, String> headers, String ruleGuid, Boolean isActive)throws IOException;
	
	//
	ApiResponse<Map<String, Object>> verifyRuleService(Map<String, String> headers, String deviceTemplateGuid, String expression)throws IOException;

}
