package com.softweb.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.softweb.model.ApiResponse;
import com.softweb.model.DeliveryMethod;

/**
 * @author shreya.hedau
 *
 */
public interface EventService {

	// Send Email
	ApiResponse<Void> sendEmail(Map<String,String> headers,String from,String to,String subject,String message) throws IOException;
	
	// Get Notification Delivery Methods
	ApiResponse<ArrayList<DeliveryMethod>> getNotificationDeliveryMethods(Map<String,String> headers,String eventGuid) throws IOException;
}
