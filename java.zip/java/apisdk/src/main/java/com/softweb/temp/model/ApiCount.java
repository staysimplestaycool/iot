package com.softweb.temp.model;

/**
 * @author shreya.hedau
 *
 */
public class ApiCount {

	private Integer currentWeek;
    private Integer currentMonth;
    private Integer currentYear;
	/**
	 * @return the currentWeek
	 */
	public Integer getCurrentWeek() {
		return currentWeek;
	}
	/**
	 * @param currentWeek the currentWeek to set
	 */
	public void setCurrentWeek(Integer currentWeek) {
		this.currentWeek = currentWeek;
	}
	/**
	 * @return the currentMonth
	 */
	public Integer getCurrentMonth() {
		return currentMonth;
	}
	/**
	 * @param currentMonth the currentMonth to set
	 */
	public void setCurrentMonth(Integer currentMonth) {
		this.currentMonth = currentMonth;
	}
	/**
	 * @return the currentYear
	 */
	public Integer getCurrentYear() {
		return currentYear;
	}
	/**
	 * @param currentYear the currentYear to set
	 */
	public void setCurrentYear(Integer currentYear) {
		this.currentYear = currentYear;
	}
    
    
}
