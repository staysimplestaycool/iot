package com.softweb.temp.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonAlias;

/**
 * @author shreya.hedau
 *
 */
public class TelemetryResponse {

	@JsonAlias({"attributeName","name"})
	private String attributeName;
	
	@JsonAlias({"data","attributeData"})
	private ArrayList<TelemetryAttributeData> attributeData;

	/**
	 * @return the attributeName
	 */
	public String getAttributeName() {
		return attributeName;
	}

	/**
	 * @param attributeName the attributeName to set
	 */
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	/**
	 * @return the attributeData
	 */
	public ArrayList<TelemetryAttributeData> getAttributeData() {
		return attributeData;
	}

	/**
	 * @param attributeData the attributeData to set
	 */
	public void setAttributeData(ArrayList<TelemetryAttributeData> attributeData) {
		this.attributeData = attributeData;
	}

}
