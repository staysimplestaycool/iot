package com.softweb.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.softweb.model.ApiResponse;
import com.softweb.model.Entity;
import com.softweb.model.Role;
import com.softweb.model.User;
import com.softweb.model.UserInfo;
import com.softweb.model.UserPreferences;
import com.softweb.temp.model.AddEntity;
import com.softweb.temp.model.BearerToken;
import com.softweb.temp.model.UserProperty;

/**
 * @author shreya.hedau
 *
 */
public interface UserService {

	// user
	// Forgot Password
	ApiResponse<ArrayList<User>> forgotPassword(Map<String,String> headers, String email)throws IOException;

	// Get Bearer Token From Company Guid
	ApiResponse<BearerToken> getBearerTokenFromCompanyGuid(String companyGuid)throws IOException;

	// Reset Password
	ApiResponse<Void> resetPassword(Map<String,String> headers, String email, String invitationGuid, String newPassword)throws IOException;

	// Create Passoword
	ApiResponse<ArrayList<User>> createPassword(Map<String,String> headers, String email)throws IOException;

	// User Change Password
	ApiResponse<Void> userChangePassword(Map<String,String> headers, String email, String oldPassword, String newPassword)throws IOException;

	// Get User List
	ApiResponse<ArrayList<User>> getUserList(Map<String,String> headers, Integer pageNumber, Integer pageSize, String searchText, String sortBy)throws IOException;

	// Add User
	ApiResponse<ArrayList<Map<String,String>>> addUser(Map<String,String> headers, String timezoneGuid, String roleGuid, String firstName, String lastName,
			String contactNo, Boolean isActive, String userId, ArrayList<UserProperty> properties, String entityGuid)throws IOException;
	
	// Update User
	ApiResponse<Void> updateUser(Map<String,String> headers, String userGuid, String timezoneGuid, String roleGuid,
			String firstName, String lastName, String contactNo, Boolean isActive, String userId,
			ArrayList<UserProperty> properties, String entityGuid)throws IOException;
	
	// Get User By Guid
	ApiResponse<ArrayList<User>> getUserByGuid(Map<String,String> headers,String userGuid,Boolean userInfoFlag)throws IOException;

	// User Preference By Guid
	ApiResponse<ArrayList<UserPreferences>> getUserPreferenceByGuid(Map<String,String> headers, String userGuid)throws IOException;

	// Delete User
	ApiResponse<Void> deleteUser(Map<String,String> headers, String userGuid)throws IOException;

	// Update User Status
	ApiResponse<Void> updateUserStatus(Map<String,String> headers, String userGuid, Boolean isActive)throws IOException;

	// Update User Preference
	ApiResponse<Void> updateUserPreference(Map<String,String> headers, String userGuid, String timezoneGuid,
			Boolean emailNotification, Integer emailNotifyOn, String alternateEmailId, Boolean smsNotification,
			Boolean pushNotification, Integer pageSize, String userInfo, String alternateEmailIdField)throws IOException;

	// User Property
	ApiResponse<ArrayList<User>> getUserProperty(Map<String,String> headers)throws IOException;

	// User Search
	ApiResponse<ArrayList<User>> userSearch(Map<String,String> headers, List<Object> userGuids, ArrayList<Object> roleguids, Integer pageNumber, Integer pageSize,
			String searchText, Boolean property, Boolean status, String sortBy)throws IOException;

	// Get User lookup
	ApiResponse<ArrayList<User>> getUserLookup(Map<String,String> headers)throws IOException;

	// Send Verification
	ApiResponse<Void> sendVerification(Map<String,String> headers, String email)throws IOException;

	// Update User Properties
	ApiResponse<Void> updateUserProperties(Map<String,String> headers,String userGuid, ArrayList<UserProperty> properties)throws IOException;

	// Delete User Property
	ApiResponse<Void> deleteUserProperty(Map<String,String> headers, String userGuid, String userPropertyGuid)throws IOException;

	// Update User Profile Image
	ApiResponse<Void>  updateUserProfileImage(Map<String,String> headers, String userGuid, File file)throws IOException;

	// Bulk Upload User CSV file
	ApiResponse<Void> bulkUploadUserUsingCSVfile(Map<String,String> headers, String entityGuid, File file)throws IOException;

	// Get User List By Entity
	ApiResponse<ArrayList<User>> getUserListByEntity(Map<String,String> headers, String entityGuid, Integer pageNumber, Integer pageSize,
			String searchText, String sortBy)throws IOException;
	
	// Get User List By Role
	ApiResponse<ArrayList<User>> getUserListByRole(Map<String,String> headers, String roleGuid, Integer pageNumber, Integer pageSize,
			String searchText, String sortBy)throws IOException;

	// role
	// Get Role List
	ApiResponse<ArrayList<Role>> getRoleList(Map<String,String> headers)throws IOException;

	// Get Role By Guid
	ApiResponse<ArrayList<Role>> getRoleByGuid(Map<String,String> headers, String roleGuid)throws IOException;

	// Get Role List with user count
	ApiResponse<ArrayList<Role>> getRoleListWithUserCount(Map<String,String> headers, Integer pageNumber, Integer pageSize, String searchText,
			String sortBy)throws IOException;

	// Add role
	ApiResponse<ArrayList<AddEntity>> addRole(Map<String,String> headers, String name, String description, ArrayList<String> solutions)throws IOException;

	// Update Role
	ApiResponse<Void> updateRole(Map<String,String> headers, String roleGuid, String name, String description,
			ArrayList<String> solutions)throws IOException;

	// Update Role Status
	ApiResponse<Void> updateRoleStatus(Map<String,String> headers, String roleGuid, Boolean isActive)throws IOException;

	// Delete Role
	ApiResponse<Void> deleteRole(Map<String,String> headers, String roleGuid)throws IOException;

	// entity	
	// Get Entity Lookup List
	ApiResponse<ArrayList<Entity>> getEntityLookupList(Map<String,String> headers)throws IOException;

	// Get Entity List
	ApiResponse<ArrayList<Entity>> getEntityList(Map<String,String> headers)throws IOException;

	// Delete Entity
	ApiResponse<Void> deleteEntity(Map<String,String> headers, String entityGuid)throws IOException;

	// Update Entity Properties
	ApiResponse<Void> updateEntityProperties(Map<String,String> headers, String entityGuid,ArrayList<Object> properties)throws IOException;

	// Delete Entity Properties
	ApiResponse<Void> deleteEntityProperties(Map<String,String> headers, String entityGuid,String entityPropertyGuid)throws IOException;

	// Get Entity By Id
	ApiResponse<ArrayList<Entity>> getEntityById(Map<String,String> headers, String entityGuid)throws IOException;

	// Add Entity
	ApiResponse<ArrayList<AddEntity>> addEntity(Map<String,String> headers,String parentEntityGuidFromQS, String name,String description,String parentEntityGuid,String address,String city,String stateGuid,String countryGuid,UserInfo userInfo)throws IOException;

	// Update Entity
	ApiResponse<Void> updateEntity(Map<String,String> headers, String entityGuid, String name,String description,String parentEntityGuid,String childEntityLable,String stateGuid,String countryGuid
	        ,String timezoneGuid,String city,String address,UserInfo userInfo)throws IOException;
	
}
