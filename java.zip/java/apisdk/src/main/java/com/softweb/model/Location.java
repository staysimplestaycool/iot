package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class Location {

	private String guid;
	private String parentguid;
	private String name;
	private String description;
	private String status;
	private Company companyguid;
	private Boolean isindoor;
	private Boolean isdeleted;
	private String createddate;
	private User createdby;
	private String updateddate;
	private User updatedby;

	/**
	 * @param guid
	 * @param parentguid
	 * @param name
	 * @param description
	 * @param status
	 * @param companyguid
	 * @param isindoor
	 * @param isdeleted
	 * @param createddate
	 * @param createdby
	 * @param updateddate
	 * @param updatedby
	 */
	public Location(String guid, String parentguid, String name, String description, String status, Company companyguid,
			Boolean isindoor, Boolean isdeleted, String createddate, User createdby, String updateddate,
			User updatedby) {
		super();
		this.guid = guid;
		this.parentguid = parentguid;
		this.name = name;
		this.description = description;
		this.status = status;
		this.companyguid = companyguid;
		this.isindoor = isindoor;
		this.isdeleted = isdeleted;
		this.createddate = createddate;
		this.createdby = createdby;
		this.updateddate = updateddate;
		this.updatedby = updatedby;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the parentguid
	 */
	public String getParentguid() {
		return parentguid;
	}

	/**
	 * @param parentguid the parentguid to set
	 */
	public void setParentguid(String parentguid) {
		this.parentguid = parentguid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the companyguid
	 */
	public Company getCompanyguid() {
		return companyguid;
	}

	/**
	 * @param companyguid the companyguid to set
	 */
	public void setCompanyguid(Company companyguid) {
		this.companyguid = companyguid;
	}

	/**
	 * @return the isindoor
	 */
	public Boolean getIsindoor() {
		return isindoor;
	}

	/**
	 * @param isindoor the isindoor to set
	 */
	public void setIsindoor(Boolean isindoor) {
		this.isindoor = isindoor;
	}

	/**
	 * @return the isdeleted
	 */
	public Boolean getIsdeleted() {
		return isdeleted;
	}

	/**
	 * @param isdeleted the isdeleted to set
	 */
	public void setIsdeleted(Boolean isdeleted) {
		this.isdeleted = isdeleted;
	}

	/**
	 * @return the createddate
	 */
	public String getCreateddate() {
		return createddate;
	}

	/**
	 * @param createddate the createddate to set
	 */
	public void setCreateddate(String createddate) {
		this.createddate = createddate;
	}

	/**
	 * @return the createdby
	 */
	public User getCreatedby() {
		return createdby;
	}

	/**
	 * @param createdby the createdby to set
	 */
	public void setCreatedby(User createdby) {
		this.createdby = createdby;
	}

	/**
	 * @return the updateddate
	 */
	public String getUpdateddate() {
		return updateddate;
	}

	/**
	 * @param updateddate the updateddate to set
	 */
	public void setUpdateddate(String updateddate) {
		this.updateddate = updateddate;
	}

	/**
	 * @return the updatedby
	 */
	public User getUpdatedby() {
		return updatedby;
	}

	/**
	 * @param updatedby the updatedby to set
	 */
	public void setUpdatedby(User updatedby) {
		this.updatedby = updatedby;
	}

}
