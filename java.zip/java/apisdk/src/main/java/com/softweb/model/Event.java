package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class Event {

	private String guid;
	private Integer eventId;
	private String name;
	private String eventTopicGuid;
	private String deliveryMethod;
	private Boolean autoSubscribed;

	/**
	 * 
	 */
	public Event() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the eventId
	 */
	public Integer getEventId() {
		return eventId;
	}

	/**
	 * @param eventId the eventId to set
	 */
	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the eventTopicGuid
	 */
	public String getEventTopicGuid() {
		return eventTopicGuid;
	}

	/**
	 * @param eventTopicGuid the eventTopicGuid to set
	 */
	public void setEventTopicGuid(String eventTopicGuid) {
		this.eventTopicGuid = eventTopicGuid;
	}

	/**
	 * @return the deliveryMethod
	 */
	public String getDeliveryMethod() {
		return deliveryMethod;
	}

	/**
	 * @param deliveryMethod the deliveryMethod to set
	 */
	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	/**
	 * @return the autoSubscribed
	 */
	public Boolean getAutoSubscribed() {
		return autoSubscribed;
	}

	/**
	 * @param autoSubscribed the autoSubscribed to set
	 */
	public void setAutoSubscribed(Boolean autoSubscribed) {
		this.autoSubscribed = autoSubscribed;
	}

}
