package com.softweb.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.StringBody;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.softweb.model.ApiResponse;
import com.softweb.model.IoTConnect;

/**
 * @author virendra.mistry
 *
 */
public class HttpUtil<E> {

	private static String baseURL;
	static {
		try {
			TrustManager[] trustAllCerts = { new X509TrustManager() {
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(X509Certificate[] certs, String authType) {
				}
			} };
			SSLContext sc = SSLContext.getInstance("SSL");

			HostnameVerifier hv = new HostnameVerifier() {
				public boolean verify(String arg0, SSLSession arg1) {
					return true;
				}
			};
			sc.init(null, trustAllCerts, new SecureRandom());

			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			HttpsURLConnection.setDefaultHostnameVerifier(hv);

			baseURL = SdkUtil.getProperty("iotConnectHostIp");
		} catch (Exception localException) {
		}
	}

	private static HttpUtil httpUtil;

	/**
	 * 
	 */
	private HttpUtil() {
		super();
	}

	public static HttpUtil getHttpUtil() {
		if (httpUtil == null)
			httpUtil = new HttpUtil();

		return httpUtil;
	}

	public <T> T doGet(String url, ObjectNode data, Map<String, String> headers, Class<?> type, boolean isApiRes,
			boolean isList) throws IOException {

		if (data != null) {
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> result = mapper.convertValue(data, Map.class);

			url = url + "?";
			int index = 0;
			for (Map.Entry<String, Object> entry : result.entrySet()) {
				if (index != 0) {
					url = url + "&";
				}
				url = url + entry.getKey() + "=" + entry.getValue();
				index++;
			}

		}

		return doExecute(url, null, "GET", headers, type, isApiRes, isList, null, null);
	}

	public <T> T doPost(String url, ObjectNode data, Map<String, String> headers, Class<?> type, boolean isApiRes,
			boolean isList) throws IOException {
		return doExecute(url, String.valueOf(data), "POST", headers, type, isApiRes, isList, null, null);
	}

	public <T> T doPut(String url, String data, Map<String, String> headers, Class<?> type, boolean isApiRes,
			boolean isList) throws IOException {
		return doExecute(url, String.valueOf(data), "PUT", headers, type, isApiRes, isList, null, null);
	}

	public <T> T doPut(String url, ObjectNode data, Map<String, String> headers, Class<?> type, boolean isApiRes,
			boolean isList) throws IOException {
		return doExecute(url, String.valueOf(data), "PUT", headers, type, isApiRes, isList, null, null);
	}

	public <T> T doDelete(String url, ObjectNode data, Map<String, String> headers, Class<?> type, boolean isApiRes,
			boolean isList) throws IOException {
		return doExecute(url, String.valueOf(data), "DELETE", headers, type, isApiRes, isList, null, null);
	}

	public <T> T doExecute(String url, ObjectNode data, String method, Map<String, String> headers, Class<?> type,
			boolean isApiRes, boolean isList) throws IOException {
		return doExecute(url, String.valueOf(data), method, headers, type, isApiRes, isList, null, null);
	}

	public <T> T doPutFile(String url, ObjectNode data, Map<String, String> headers, Class<?> type, boolean isApiRes,
			boolean isList, File file, String fileKey) throws IOException {
		return doExecute(url, String.valueOf(data), "PUT", headers, type, isApiRes, isList, file, fileKey);
	}

	public <T> T doPostFile(String url, ObjectNode data, Map<String, String> headers, Class<?> type, boolean isApiRes,
			boolean isList, File file, String fileKey) throws IOException {
		return doExecute(url, String.valueOf(data), "POST", headers, type, isApiRes, isList, file, fileKey);
	}

	public <T> T doExecute(String url, String data, String method, Map<String, String> headers, Class<?> type,
			boolean isApiRes, boolean isList, File file, String fileKey) throws IOException {

		System.out.println("url ====>" + url);
		URL urlObj = new URL(url);
		HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod(method);
		if (headers != null) {
			for (Map.Entry<String, String> entry : headers.entrySet()) {
				conn.addRequestProperty(entry.getKey(), entry.getValue());
			}
		}

		if (file != null) {

			byte[] fileContent = Files.readAllBytes(file.toPath());
			ContentBody contentPart = new ByteArrayBody(fileContent, file.getName());

			MultipartEntity reqEntity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
			reqEntity.addPart(fileKey, contentPart);
					
			conn.setRequestProperty("Connection", "Keep-Alive");
			conn.addRequestProperty("Content-length", reqEntity.getContentLength() + "");
			conn.setRequestProperty(reqEntity.getContentType().getName(), reqEntity.getContentType().getValue());

			if (data != null && !data.equals("null")) {
				JsonNode node = IoTConnect.objectMapper.readValue(data, ObjectNode.class);
				{
					Iterator<String> itr = node.fieldNames();
					while (itr.hasNext()) { // to get the key fields
						String key_field = itr.next();
						reqEntity.addPart(key_field,
								new StringBody(node.get(key_field).toString().replaceAll("\"", "")));

					}
				}
			}
			reqEntity.writeTo(conn.getOutputStream());

		}

		if (data != null && !data.equals("null") && file == null) {
			conn.setRequestProperty("Content-Type", "application/json");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(data);
			writer.flush();
			writer.close();

		}

		String line;
		StringBuffer buffer = new StringBuffer();
		BufferedReader reader = null;
		ObjectMapper mapper = new ObjectMapper();
		JavaType type0 = null;
		JavaType type1 = null;

		if (conn.getResponseCode() != 200) {
			reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
			while ((line = reader.readLine()) != null) {
				buffer.append(line);
			}

		} else {
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			while ((line = reader.readLine()) != null) {
				buffer.append(line);
			}

		}

		reader.close();
		conn.disconnect();

		if (isList) {
			type0 = mapper.getTypeFactory().constructCollectionType(ArrayList.class, type);
			if (isApiRes) {
				type1 = mapper.getTypeFactory().constructParametricType(ApiResponse.class, type0);
			} else {
				type1 = type0;
			}
		} else if (isApiRes) {
			type1 = mapper.getTypeFactory().constructParametricType(ApiResponse.class, type);
		} else {
			type1 = mapper.getTypeFactory().constructType(type);
		}

		return mapper.readValue(buffer.toString(), type1);

	}

	public String doGet(String url) throws IOException {

		// configure the SSLContext with a TrustManager

		URL urlObj = new URL(url);
		HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
		conn.setDoOutput(true);

		String line;
		StringBuffer buffer = new StringBuffer();
		BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		while ((line = reader.readLine()) != null) {
			buffer.append(line);
		}
		reader.close();
		conn.disconnect();

		return buffer.toString();
	}

	public static void main(String[] args) {
		try {
			HttpUtil.getHttpUtil().doGet("url");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}