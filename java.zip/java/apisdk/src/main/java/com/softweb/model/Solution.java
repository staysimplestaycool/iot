package com.softweb.model;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonAutoDetect;

/**
 * @author shreya.hedau
 *
 */
public class Solution {

	private String guid;
	private String name;
	private String type;
	private String image;
	private String ipRange;

	@JsonAlias({ "URL", "url" })
	private String url;
	private String accesskey;
	private Boolean isActive;
	private Boolean isDeleted;
	@JsonAlias({ "createddate", "createdDate" })
	private Date createdDate;
	@JsonAlias({ "createdby", "createdBy" })
	private String createdBy;
	@JsonAlias({ "updateddate", "updatedDate" })
	private Date updatedDate;
	@JsonAlias({ "updatedby", "updatedBy" })
	private String updatedBy;
	private String subscribers;
	private String brokerInfo;
	private String fileUrl;

	private Boolean isSoftwebSolution;

	public Solution() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the ipRange
	 */
	public String getIpRange() {
		return ipRange;
	}

	/**
	 * @param ipRange the ipRange to set
	 */
	public void setIpRange(String ipRange) {
		this.ipRange = ipRange;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the accesskey
	 */
	public String getAccesskey() {
		return accesskey;
	}

	/**
	 * @param accesskey the accesskey to set
	 */
	public void setAccesskey(String accesskey) {
		this.accesskey = accesskey;
	}

	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the subscribers
	 */
	public String getSubscribers() {
		return subscribers;
	}

	/**
	 * @param subscribers the subscribers to set
	 */
	public void setSubscribers(String subscribers) {
		this.subscribers = subscribers;
	}

	/**
	 * @return the brokerInfo
	 */
	public String getBrokerInfo() {
		return brokerInfo;
	}

	/**
	 * @param brokerInfo the brokerInfo to set
	 */
	public void setBrokerInfo(String brokerInfo) {
		this.brokerInfo = brokerInfo;
	}

	/**
	 * @return the fileUrl
	 */
	public String getFileUrl() {
		return fileUrl;
	}

	/**
	 * @param fileUrl the fileUrl to set
	 */
	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}

	/**
	 * @return the isSoftwebSolution
	 */
	public Boolean getIsSoftwebSolution() {
		return isSoftwebSolution;
	}

	/**
	 * @param isSoftwebSolution the isSoftwebSolution to set
	 */
	public void setIsSoftwebSolution(Boolean isSoftwebSolution) {
		this.isSoftwebSolution = isSoftwebSolution;
	}

	/**
	 * @return the image
	 */
	public String getImage() {
		return image;
	}

	/**
	 * @param image the image to set
	 */
	public void setImage(String image) {
		this.image = image;
	}
	
	

}
