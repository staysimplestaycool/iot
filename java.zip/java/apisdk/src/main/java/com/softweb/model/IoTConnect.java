package com.softweb.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.softweb.common.SdkUtil;

public class IoTConnect {

	private static IoTConnect iotConnect = null;
	
	public String AUTH_BASE_URL;
	
	public String COMPANY_BASE_URL;
	public String SOLUTION_BASE_URL;
	
	public String USER_BASE_URL;
	public String ROLE_BASE_URL;
	public String ENTITY_BASE_URL;
	
	public String MASTER_BASE_URL;
	public String FAQ_BASE_URL;
	public String PROPERTY_BASE_URL;
	public String DASHBOARD_BASE_URL;
	
	public String DEVICE_BASE_URL;
	public String DPS_BASE_URL;
	
	public String TEMPLATE_BASE_URL;
	public String TEMPLATE_SETTING_BASE_URL;
	public String TEMPLATE_ATTRIBUTE_BASE_URL;
	public String TEMPLATE_COMMAND_BASE_URL;
	public String TEMPLATE_RULE_BASE_URL;
	
	public String AUTHORIZE_BASE_URL;	
	public String CONFIG_BASE_URL;
	public String EVENT_BASE_URL;
	
	public String FIRMWARE_BASE_URL;
	public String FIRMWARE_OTA_UPDATE_BASE_URL;
	public String FIRMWARE_UPGRADE_BASE_URL;
	
	public String TELEMATRY_BASE_URL;
	public String RULE_BASE_URL;
	
	public static ObjectMapper objectMapper = new ObjectMapper();
	
	//to restrict from creating Instance
	private IoTConnect(){
		initialize();
	}
	
	public static IoTConnect getInstance(){
		if(iotConnect==null){
			iotConnect = new IoTConnect();
			iotConnect.initialize();
		}
		return iotConnect;
	}
	
	private void initialize(){
		final String iotConnectHostIp = SdkUtil.getProperty("iotConnectHostIp");
		final String iotConnectApiVerson = SdkUtil.getProperty("iotConnectApiVerson");
		
		StringBuilder sb = new StringBuilder();
		sb.append("http://");
		sb.append(iotConnectHostIp);
		sb.append(":");
		sb.append(SdkUtil.getProperty("iotConnectAuthPort"));
		sb.append("/api/");
		sb.append(iotConnectApiVerson);
		this.AUTH_BASE_URL = sb.toString();
		
		sb.setLength(0);//Clean
		sb.append("http://");
		sb.append(iotConnectHostIp);
		sb.append(":");
		sb.append(SdkUtil.getProperty("iotConnectCompanyPort"));
		sb.append("/api/");
		sb.append(iotConnectApiVerson);
		this.COMPANY_BASE_URL = sb.toString();
		this.SOLUTION_BASE_URL = sb.toString();
		
		sb.setLength(0);//Clean
		sb.append("http://");
		sb.append(iotConnectHostIp);
		sb.append(":");
		sb.append(SdkUtil.getProperty("iotConnectUserPort"));
		sb.append("/api/");
		sb.append(iotConnectApiVerson);
		this.USER_BASE_URL = sb.toString();
		this.ROLE_BASE_URL = sb.toString();
		this.ENTITY_BASE_URL = sb.toString();
		
		sb.setLength(0);//Clean
		sb.append("http://");
		sb.append(iotConnectHostIp);
		sb.append(":");
		sb.append(SdkUtil.getProperty("iotConnectMasterPort"));
		sb.append("/api/");
		sb.append(iotConnectApiVerson);
		this.MASTER_BASE_URL = sb.toString();
		this.FAQ_BASE_URL = sb.toString();
		this.PROPERTY_BASE_URL = sb.toString();
		this.DASHBOARD_BASE_URL = sb.toString();
				
		sb.setLength(0);//Clean
		sb.append("http://");
		sb.append(iotConnectHostIp);
		sb.append(":");
		sb.append(SdkUtil.getProperty("iotConnectDevicePort"));
		sb.append("/api/");
		sb.append(iotConnectApiVerson);
		this.DEVICE_BASE_URL = sb.toString();
		this.DPS_BASE_URL = sb.toString();
		
		sb.setLength(0);//Clean
		sb.append("http://");
		sb.append(iotConnectHostIp);
		sb.append(":");
		sb.append(SdkUtil.getProperty("iotConnectTemplatePort"));
		sb.append("/api/");
		sb.append(iotConnectApiVerson);
		this.TEMPLATE_BASE_URL = sb.toString();
		this.TEMPLATE_SETTING_BASE_URL = sb.toString();
		this.TEMPLATE_ATTRIBUTE_BASE_URL = sb.toString();
		this.TEMPLATE_COMMAND_BASE_URL = sb.toString();
		this.TEMPLATE_RULE_BASE_URL = sb.toString();
		
		sb.setLength(0);//Clean
		sb.append("http://");
		sb.append(iotConnectHostIp);
		sb.append(":");
		sb.append(SdkUtil.getProperty("iotConnectFirmwarePort"));
		sb.append("/api/");
		sb.append(iotConnectApiVerson);
		this.FIRMWARE_BASE_URL = sb.toString();
		this.FIRMWARE_OTA_UPDATE_BASE_URL = sb.toString();
		this.FIRMWARE_UPGRADE_BASE_URL = sb.toString();
		
		sb.setLength(0);//Clean
		sb.append("http://");
		sb.append(iotConnectHostIp);
		sb.append(":");
		sb.append(SdkUtil.getProperty("iotConnectAuthorizePort"));
		sb.append("/api/");
		sb.append(iotConnectApiVerson);
		this.AUTHORIZE_BASE_URL = sb.toString();
		
		sb.setLength(0);//Clean
		sb.append("http://");
		sb.append(iotConnectHostIp);
		sb.append(":");
		sb.append(SdkUtil.getProperty("iotConnectConfigPort"));
		sb.append("/api/");
		sb.append(iotConnectApiVerson);
		this.CONFIG_BASE_URL = sb.toString();
		
		sb.setLength(0);//Clean
		sb.append("http://");
		sb.append(iotConnectHostIp);
		sb.append(":");
		sb.append(SdkUtil.getProperty("iotConnectEventPort"));
		sb.append("/api/");
		sb.append(iotConnectApiVerson);
		this.EVENT_BASE_URL = sb.toString();
		
		sb.setLength(0);//Clean
		sb.append("http://");
		sb.append(iotConnectHostIp);
		sb.append(":");
		sb.append(SdkUtil.getProperty("iotConnectTelemetryPort"));
		sb.append("/api/");
		sb.append(iotConnectApiVerson);
		this.TELEMATRY_BASE_URL = sb.toString();
		this.RULE_BASE_URL = sb.toString();
	}
}
