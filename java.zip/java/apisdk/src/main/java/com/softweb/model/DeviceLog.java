package com.softweb.model;

/**
 * @author shreya.hedau
 *
 */
public class DeviceLog {

	private String guid;
	private String fileName;
	private String logType;
	private String pressVersion;
	private Integer cycleCount;
	private String uploadDate;
	private String uploadBy;

	/**
	 * 
	 */
	public DeviceLog() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the logType
	 */
	public String getLogType() {
		return logType;
	}

	/**
	 * @param logType the logType to set
	 */
	public void setLogType(String logType) {
		this.logType = logType;
	}

	/**
	 * @return the pressVersion
	 */
	public String getPressVersion() {
		return pressVersion;
	}

	/**
	 * @param pressVersion the pressVersion to set
	 */
	public void setPressVersion(String pressVersion) {
		this.pressVersion = pressVersion;
	}

	/**
	 * @return the cycleCount
	 */
	public Integer getCycleCount() {
		return cycleCount;
	}

	/**
	 * @param cycleCount the cycleCount to set
	 */
	public void setCycleCount(Integer cycleCount) {
		this.cycleCount = cycleCount;
	}

	/**
	 * @return the uploadDate
	 */
	public String getUploadDate() {
		return uploadDate;
	}

	/**
	 * @param uploadDate the uploadDate to set
	 */
	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}

	/**
	 * @return the uploadBy
	 */
	public String getUploadBy() {
		return uploadBy;
	}

	/**
	 * @param uploadBy the uploadBy to set
	 */
	public void setUploadBy(String uploadBy) {
		this.uploadBy = uploadBy;
	}

}
