package com.softweb.serviceImpl;

import java.io.IOException;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.softweb.common.HttpUtil;
import com.softweb.model.ApiResponse;
import com.softweb.model.IoTConnect;
import com.softweb.model.Tokens;
import com.softweb.service.AuthService;

/**
 * @author shreya.hedau
 *
 */
public class AuthServiceImpl implements AuthService {

	
	private IoTConnect ioTConnect;
	/**
	 * 
	 */
	public AuthServiceImpl() {
		super();
		ioTConnect = IoTConnect.getInstance();
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.AuthInterface#getBasicToken()
	 */
	@SuppressWarnings("unchecked")
	public String getToken() throws IOException {
		ApiResponse<String> apiResponse =  IoTConnect.objectMapper.readValue(HttpUtil.getHttpUtil().doGet(ioTConnect.AUTH_BASE_URL+"/auth/basic-token"),ApiResponse.class);
		return apiResponse.getData();		
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.AuthInterface#signIn(java.util.Map, java.lang.String, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Tokens> signIn(Map<String, String> headers, String username, String password) throws IOException {
		//headers.put("solution-key", solutionKey);		
		ObjectNode loginInfo = ioTConnect.objectMapper.createObjectNode();
		loginInfo.put("username", username);
		loginInfo.put("password", password);
		Tokens token = (Tokens)HttpUtil.getHttpUtil().doPost(ioTConnect.AUTH_BASE_URL+"/auth/login", loginInfo, headers,Tokens.class,false,false);
		ApiResponse<Tokens> apiResponse = new ApiResponse<Tokens>();
		apiResponse.setData(token);
		return apiResponse;		
	}

	/* (non-Javadoc)
	 * @see com.softweb.service.AuthInterface#getRefreshToken(java.util.Map, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public ApiResponse<Tokens> getRefreshToken(Map<String, String> headers, String refreshToken) throws IOException {
		ObjectNode tokenInfo = ioTConnect.objectMapper.createObjectNode();
		tokenInfo.put("refreshtoken", refreshToken);		
		//ApiResponse<Tokens> apiResponse = HttpUtil.getHttpUtil().doPost(ioTConnect.AUTH_BASE_URL+"/auth/refresh-token", tokenInfo, headers,Tokens.class);
		Tokens token = (Tokens)HttpUtil.getHttpUtil().doPost(ioTConnect.AUTH_BASE_URL+"/auth/refresh-token", tokenInfo, headers,Tokens.class,false,false);
		ApiResponse<Tokens> apiResponse = new ApiResponse<Tokens>();
		apiResponse.setData(token);
		return apiResponse;
	}

}
