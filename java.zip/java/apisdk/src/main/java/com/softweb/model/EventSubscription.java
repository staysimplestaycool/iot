package com.softweb.model;

import java.sql.Date;
import java.util.ArrayList;

/**
 * @author shreya.hedau
 *
 */
public class EventSubscription {

	private String guid;
	private String eventGuid;
	private Integer deliveryMethod;
	private String companyGuid;
	private String solutionGuid;
	private String refGuid;
	private String dataXml;
	private String isDeleted;
	private Date createdDate;
	private User createdBy;
	private Date updatedDate;
	private User updatedBy;
	
	private ArrayList<DeliveryMethod> deliveryMethodData;

	/**
	 * 
	 */
	public EventSubscription() {
		super();
	}

	/**
	 * @return the deliveryMethodData
	 */
	public ArrayList<DeliveryMethod> getDeliveryMethodData() {
		return deliveryMethodData;
	}

	/**
	 * @param deliveryMethodData the deliveryMethodData to set
	 */
	public void setDeliveryMethodData(ArrayList<DeliveryMethod> deliveryMethodData) {
		this.deliveryMethodData = deliveryMethodData;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the eventGuid
	 */
	public String getEventGuid() {
		return eventGuid;
	}

	/**
	 * @param eventGuid the eventGuid to set
	 */
	public void setEventGuid(String eventGuid) {
		this.eventGuid = eventGuid;
	}

	/**
	 * @return the deliveryMethod
	 */
	public Integer getDeliveryMethod() {
		return deliveryMethod;
	}

	/**
	 * @param deliveryMethod the deliveryMethod to set
	 */
	public void setDeliveryMethod(Integer deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	/**
	 * @return the companyGuid
	 */
	public String getCompanyGuid() {
		return companyGuid;
	}

	/**
	 * @param companyGuid the companyGuid to set
	 */
	public void setCompanyGuid(String companyGuid) {
		this.companyGuid = companyGuid;
	}

	/**
	 * @return the solutionGuid
	 */
	public String getSolutionGuid() {
		return solutionGuid;
	}

	/**
	 * @param solutionGuid the solutionGuid to set
	 */
	public void setSolutionGuid(String solutionGuid) {
		this.solutionGuid = solutionGuid;
	}

	/**
	 * @return the refGuid
	 */
	public String getRefGuid() {
		return refGuid;
	}

	/**
	 * @param refGuid the refGuid to set
	 */
	public void setRefGuid(String refGuid) {
		this.refGuid = refGuid;
	}

	/**
	 * @return the dataXml
	 */
	public String getDataXml() {
		return dataXml;
	}

	/**
	 * @param dataXml the dataXml to set
	 */
	public void setDataXml(String dataXml) {
		this.dataXml = dataXml;
	}

	/**
	 * @return the isDeleted
	 */
	public String getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

}
