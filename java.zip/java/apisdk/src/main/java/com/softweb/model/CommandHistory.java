package com.softweb.model;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.databind.annotation.JsonAppend;

/**
 * @author shreya.hedau
 *
 */
public class CommandHistory {

	@JsonAlias({ "commandHistoryGuid", "guid" })
	private String guid;
	private Rule batchGuid;
	private String commandGuid;
	private String cmdText;
	private String deviceGuid;
	private String companyGuid;
	private String status;
	private Boolean isInternal;
	private String transitDate;
	private String deliveryDate;
	private Boolean requireRcpt;
	private Date ackDate;
	private String statusText;
	private String createdBy;
	private Date createdDate;
	private String attempts;

	private String uniqueId;
	private String statusDate;
	private String createdByName;

	/**
	 * 
	 */
	public CommandHistory() {
		super();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the batchGuid
	 */
	public Rule getBatchGuid() {
		return batchGuid;
	}

	/**
	 * @param batchGuid the batchGuid to set
	 */
	public void setBatchGuid(Rule batchGuid) {
		this.batchGuid = batchGuid;
	}

	/**
	 * @return the commandGuid
	 */
	public String getCommandGuid() {
		return commandGuid;
	}

	/**
	 * @param commandGuid the commandGuid to set
	 */
	public void setCommandGuid(String commandGuid) {
		this.commandGuid = commandGuid;
	}

	/**
	 * @return the cmdText
	 */
	public String getCmdText() {
		return cmdText;
	}

	/**
	 * @param cmdText the cmdText to set
	 */
	public void setCmdText(String cmdText) {
		this.cmdText = cmdText;
	}

	/**
	 * @return the deviceGuid
	 */
	public String getDeviceGuid() {
		return deviceGuid;
	}

	/**
	 * @param deviceGuid the deviceGuid to set
	 */
	public void setDeviceGuid(String deviceGuid) {
		this.deviceGuid = deviceGuid;
	}

	/**
	 * @return the companyGuid
	 */
	public String getCompanyGuid() {
		return companyGuid;
	}

	/**
	 * @param companyGuid the companyGuid to set
	 */
	public void setCompanyGuid(String companyGuid) {
		this.companyGuid = companyGuid;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the isInternal
	 */
	public Boolean getIsInternal() {
		return isInternal;
	}

	/**
	 * @param isInternal the isInternal to set
	 */
	public void setIsInternal(Boolean isInternal) {
		this.isInternal = isInternal;
	}

	/**
	 * @return the transitDate
	 */
	public String getTransitDate() {
		return transitDate;
	}

	/**
	 * @param transitDate the transitDate to set
	 */
	public void setTransitDate(String transitDate) {
		this.transitDate = transitDate;
	}

	/**
	 * @return the deliveryDate
	 */
	public String getDeliveryDate() {
		return deliveryDate;
	}

	/**
	 * @param deliveryDate the deliveryDate to set
	 */
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	/**
	 * @return the requireRcpt
	 */
	public Boolean getRequireRcpt() {
		return requireRcpt;
	}

	/**
	 * @param requireRcpt the requireRcpt to set
	 */
	public void setRequireRcpt(Boolean requireRcpt) {
		this.requireRcpt = requireRcpt;
	}

	/**
	 * @return the ackDate
	 */
	public Date getAckDate() {
		return ackDate;
	}

	/**
	 * @param ackDate the ackDate to set
	 */
	public void setAckDate(Date ackDate) {
		this.ackDate = ackDate;
	}

	/**
	 * @return the statusText
	 */
	public String getStatusText() {
		return statusText;
	}

	/**
	 * @param statusText the statusText to set
	 */
	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the attempts
	 */
	public String getAttempts() {
		return attempts;
	}

	/**
	 * @param attempts the attempts to set
	 */
	public void setAttempts(String attempts) {
		this.attempts = attempts;
	}

	/**
	 * @return the uniqueId
	 */
	public String getUniqueId() {
		return uniqueId;
	}

	/**
	 * @param uniqueId the uniqueId to set
	 */
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	/**
	 * @return the statusDate
	 */
	public String getStatusDate() {
		return statusDate;
	}

	/**
	 * @param statusDate the statusDate to set
	 */
	public void setStatusDate(String statusDate) {
		this.statusDate = statusDate;
	}

	/**
	 * @return the createdByName
	 */
	public String getCreatedByName() {
		return createdByName;
	}

	/**
	 * @param createdByName the createdByName to set
	 */
	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}

}
